# [Project name]

_Replace the heading above with the project's name, and this line with one sentence describing what this app does for users._

## Run & Operate

- **`npm start`** (or `node start.mjs`) — easiest: builds + runs the API (port 5055) and web app (port 5173) together and prints the link → http://localhost:5173. Reuses the pnpm-installed `node_modules`; does NOT install. ⚠️ Never run `npm install` here — the workspace uses pnpm-only `catalog:`/`workspace:*` which npm can't resolve. Install with `COREPACK_INTEGRITY_KEYS=0 corepack pnpm@9.15.4 install`.
- `pnpm --filter @workspace/api-server run dev` — run the API server (defaults to port 5000)
- `pnpm --filter @workspace/enable-bharat run dev` — run the web app (defaults to port 5173, proxies `/api` → the API server)
- `pnpm run typecheck` — full typecheck across all packages
- `pnpm run build` — typecheck + build all packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks and Zod schemas from the OpenAPI spec
- `pnpm --filter @workspace/db run push` — push DB schema changes (dev only, Postgres)
- Optional env: `PORT`, `BASE_PATH` (web), `API_URL` (web proxy target), `DATABASE_URL` (only for the Postgres `lib/db`)

### Auth / voice assistant
- Auth API (`artifacts/api-server`): `POST /api/auth/register`, `POST /api/auth/login`, `GET /api/auth/me`, `POST /api/auth/logout`. Passwords bcrypt-hashed; session is an httpOnly cookie (`eb_session`).
- Auth store is a self-contained SQLite file at `artifacts/api-server/data/auth.db` via the built-in `node:sqlite` module (NOT the Postgres `lib/db`, which stays unused for now).
- Demo accounts seeded on startup: `ravi@enablebharat.in` / `ravi1234` (candidate), `employer@enablebharat.in` / `hire1234` (employer).
- Voice assistant (bottom-right, bilingual EN/हिं): spoken navigation, read-page-aloud, and voice login. Say "login" → it asks for email then password by voice and signs in against the real API. Needs Web Speech API (Chrome).

## Stack

- pnpm workspaces, Node.js 24, TypeScript 5.9
- API: Express 5
- DB: PostgreSQL + Drizzle ORM
- Validation: Zod (`zod/v4`), `drizzle-zod`
- API codegen: Orval (from OpenAPI spec)
- Build: esbuild (CJS bundle)

## Where things live

_Populate as you build — short repo map plus pointers to the source-of-truth file for DB schema, API contracts, theme files, etc._

## Architecture decisions

_Populate as you build — non-obvious choices a reader couldn't infer from the code (3-5 bullets)._

## Product

_Describe the high-level user-facing capabilities of this app once they exist._

## User preferences

_Populate as you build — explicit user instructions worth remembering across sessions._

## Gotchas

- **Node 26 + native modules:** `better-sqlite3` will NOT compile on Node 26 (V8 API errors, no prebuild). We use the built-in `node:sqlite` instead. Avoid adding native-compiled deps.
- **macOS port 5000:** AirPlay Receiver binds :5000. Run the API on another port, e.g. `PORT=5055 pnpm --filter @workspace/api-server run dev`, and point the web proxy at it with `API_URL=http://localhost:5055`.
- **corepack signature bug:** on this machine `corepack` can't verify pnpm's signing key. Prefix commands with `COREPACK_INTEGRITY_KEYS=0`, e.g. `COREPACK_INTEGRITY_KEYS=0 corepack pnpm@9.15.4 install`.
- The web app's `PORT`/`BASE_PATH` now default (5173 / `/`) instead of throwing, so `pnpm dev` works without env setup.

## Pointers

- See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details
