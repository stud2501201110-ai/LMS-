// One-command launcher: builds + starts the API server and the web app,
// then prints the local link. Run with `npm start` (or `node start.mjs`).
// Uses only the binaries pnpm already installed — it does NOT run any install,
// so it is safe even though this workspace is pnpm-only (catalog:/workspace:).
import { spawn } from "node:child_process";
import { fileURLToPath } from "node:url";
import path from "node:path";

const root = path.dirname(fileURLToPath(import.meta.url));
const apiDir = path.join(root, "artifacts", "api-server");
const webDir = path.join(root, "artifacts", "enable-bharat");

// Port 5000 is taken by macOS AirPlay, so the API defaults to 5055.
const API_PORT = process.env.API_PORT || "5055";
const WEB_PORT = process.env.PORT || "5173";
const apiUrl = process.env.API_URL || `http://localhost:${API_PORT}`;

const children = [];
function run(cmd, args, opts) {
  const child = spawn(cmd, args, { stdio: "inherit", ...opts });
  children.push(child);
  return child;
}

function shutdown(code = 0) {
  for (const child of children) {
    try { child.kill(); } catch { /* already gone */ }
  }
  process.exit(code);
}
process.on("SIGINT", () => shutdown(0));
process.on("SIGTERM", () => shutdown(0));

console.log("\n▸ Building API server...");
const build = run(process.execPath, ["build.mjs"], { cwd: apiDir });
build.on("exit", (code) => {
  if (code !== 0) {
    console.error("✗ API build failed.");
    shutdown(code ?? 1);
    return;
  }
  startServers();
});

function startServers() {
  const api = run(process.execPath, ["--enable-source-maps", "dist/index.mjs"], {
    cwd: apiDir,
    env: { ...process.env, PORT: API_PORT, NODE_ENV: process.env.NODE_ENV || "development" },
  });

  const viteBin = path.join(webDir, "node_modules", ".bin", "vite");
  const web = run(viteBin, ["--config", "vite.config.ts", "--host", "0.0.0.0"], {
    cwd: webDir,
    env: { ...process.env, PORT: WEB_PORT, BASE_PATH: "/", API_URL: apiUrl },
  });

  api.on("exit", () => shutdown(0));
  web.on("exit", () => shutdown(0));

  setTimeout(() => {
    console.log("\n✅ Enable Bharat is running");
    console.log(`   → Web app : http://localhost:${WEB_PORT}`);
    console.log(`   → API     : ${apiUrl}`);
    console.log("   → Demo login: ravi@enablebharat.in / ravi1234");
    console.log("   Open in Chrome for the voice assistant. Press Ctrl+C to stop.\n");
  }, 4000);
}
