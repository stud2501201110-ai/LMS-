import { Router, type IRouter, type Request, type Response } from "express";
import {
  createSession,
  createUser,
  destroySession,
  getUserByEmail,
  getUserBySession,
  verifyPassword,
  type Role,
} from "../lib/db";

const router: IRouter = Router();

const SESSION_COOKIE = "eb_session";
const VALID_ROLES: Role[] = ["candidate", "employer", "assessor", "admin"];

function setSessionCookie(res: Response, token: string) {
  res.cookie(SESSION_COOKIE, token, {
    httpOnly: true,
    sameSite: "lax",
    secure: process.env.NODE_ENV === "production",
    maxAge: 1000 * 60 * 60 * 24 * 30, // 30 days
    path: "/",
  });
}

function readSessionToken(req: Request): string | undefined {
  return req.cookies?.[SESSION_COOKIE];
}

router.post("/auth/register", (req, res) => {
  const { name, email, password } = req.body ?? {};
  const role: Role = VALID_ROLES.includes(req.body?.role) ? req.body.role : "candidate";

  if (typeof name !== "string" || name.trim().length < 2) {
    return res.status(400).json({ error: "Please provide your name." });
  }
  if (typeof email !== "string" || !email.includes("@")) {
    return res.status(400).json({ error: "Please provide a valid email address." });
  }
  if (typeof password !== "string" || password.length < 4) {
    return res.status(400).json({ error: "Password must be at least 4 characters." });
  }
  if (getUserByEmail(email)) {
    return res.status(409).json({ error: "An account with this email already exists." });
  }

  const user = createUser({ name, email, password, role });
  const token = createSession(user.id);
  setSessionCookie(res, token);
  return res.status(201).json({ user });
});

router.post("/auth/login", (req, res) => {
  const { email, password } = req.body ?? {};
  if (typeof email !== "string" || typeof password !== "string") {
    return res.status(400).json({ error: "Email and password are required." });
  }

  const row = getUserByEmail(email);
  if (!row || !verifyPassword(row, password)) {
    return res.status(401).json({ error: "Incorrect email or password." });
  }

  const token = createSession(row.id);
  setSessionCookie(res, token);
  return res.json({ user: { id: row.id, name: row.name, email: row.email, role: row.role } });
});

router.get("/auth/me", (req, res) => {
  const user = getUserBySession(readSessionToken(req));
  if (!user) return res.status(401).json({ error: "Not authenticated." });
  return res.json({ user });
});

router.post("/auth/logout", (req, res) => {
  destroySession(readSessionToken(req));
  res.clearCookie(SESSION_COOKIE, { path: "/" });
  return res.json({ ok: true });
});

export default router;
