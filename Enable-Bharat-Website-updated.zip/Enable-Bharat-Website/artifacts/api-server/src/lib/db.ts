import path from "node:path";
import fs from "node:fs";
import crypto from "node:crypto";
import { DatabaseSync } from "node:sqlite";
import bcrypt from "bcryptjs";
import { logger } from "./logger";

// Lightweight SQLite store for authentication, using Node's built-in
// `node:sqlite` module — no native dependency to compile, and no database
// server to install. The file lives next to the running package (data/auth.db).
const dataDir = path.resolve(process.cwd(), "data");
fs.mkdirSync(dataDir, { recursive: true });
const dbPath = path.resolve(dataDir, "auth.db");

export const db = new DatabaseSync(dbPath);
db.exec("PRAGMA journal_mode = WAL");

db.exec(`
  CREATE TABLE IF NOT EXISTS users (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    name       TEXT    NOT NULL,
    email      TEXT    NOT NULL UNIQUE,
    password   TEXT    NOT NULL,
    role       TEXT    NOT NULL DEFAULT 'candidate',
    created_at TEXT    NOT NULL DEFAULT (datetime('now'))
  );

  CREATE TABLE IF NOT EXISTS sessions (
    token      TEXT    PRIMARY KEY,
    user_id    INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    created_at TEXT    NOT NULL DEFAULT (datetime('now'))
  );
`);

export type Role = "candidate" | "employer" | "assessor" | "admin";

export type UserRow = {
  id: number;
  name: string;
  email: string;
  password: string;
  role: Role;
  created_at: string;
};

export type PublicUser = {
  id: number;
  name: string;
  email: string;
  role: Role;
};

export function toPublicUser(row: UserRow): PublicUser {
  return { id: row.id, name: row.name, email: row.email, role: row.role };
}

const insertUser = db.prepare(
  "INSERT INTO users (name, email, password, role) VALUES (?, ?, ?, ?)",
);
const findByEmail = db.prepare("SELECT * FROM users WHERE email = ?");
const findById = db.prepare("SELECT * FROM users WHERE id = ?");
const insertSession = db.prepare(
  "INSERT INTO sessions (token, user_id) VALUES (?, ?)",
);
const findSession = db.prepare("SELECT * FROM sessions WHERE token = ?");
const deleteSession = db.prepare("DELETE FROM sessions WHERE token = ?");

export function getUserByEmail(email: string): UserRow | undefined {
  return findByEmail.get(email.trim().toLowerCase()) as UserRow | undefined;
}

export function createUser(input: {
  name: string;
  email: string;
  password: string;
  role: Role;
}): PublicUser {
  const hashed = bcrypt.hashSync(input.password, 10);
  const result = insertUser.run(
    input.name.trim(),
    input.email.trim().toLowerCase(),
    hashed,
    input.role,
  );
  const row = findById.get(Number(result.lastInsertRowid)) as UserRow;
  return toPublicUser(row);
}

export function verifyPassword(row: UserRow, password: string): boolean {
  return bcrypt.compareSync(password, row.password);
}

export function createSession(userId: number): string {
  const token = crypto.randomBytes(32).toString("hex");
  insertSession.run(token, userId);
  return token;
}

export function getUserBySession(token: string | undefined): PublicUser | undefined {
  if (!token) return undefined;
  const session = findSession.get(token) as { user_id: number } | undefined;
  if (!session) return undefined;
  const row = findById.get(session.user_id) as UserRow | undefined;
  return row ? toPublicUser(row) : undefined;
}

export function destroySession(token: string | undefined): void {
  if (token) deleteSession.run(token);
}

// Seed a demo account so voice login works out of the box for a first-time /
// assistive-technology user, without needing to register first.
export function seedDemoUsers(): void {
  const demos: Array<{ name: string; email: string; password: string; role: Role }> = [
    { name: "Ravi Mehta", email: "ravi@enablebharat.in", password: "ravi1234", role: "candidate" },
    { name: "Aarohan Retail", email: "employer@enablebharat.in", password: "hire1234", role: "employer" },
  ];
  for (const demo of demos) {
    if (!getUserByEmail(demo.email)) {
      createUser(demo);
      logger.info({ email: demo.email, role: demo.role }, "Seeded demo user");
    }
  }
}
