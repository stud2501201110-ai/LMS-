import EnableBharatApp from "./enable-bharat-app";
import "./legacy-enable-bharat.css";

export default EnableBharatApp;
