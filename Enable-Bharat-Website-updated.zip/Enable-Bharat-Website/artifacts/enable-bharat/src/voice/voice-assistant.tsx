"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import {
  RECOGNITION_LANG,
  STRINGS,
  VIEW_LABELS,
  matchCommand,
  normalizeSpokenEmail,
  normalizeSpokenPassword,
  type CommandAction,
  type VoiceLang,
} from "./i18n";
import { dashboardForRole, login, logout, type AuthUser } from "../lib/auth";

type Props = {
  go: (view: string) => void;
  user: AuthUser | null;
  onAuthChange: (user: AuthUser | null) => void;
};

function getSpeechRecognition(): any {
  if (typeof window === "undefined") return null;
  const w = window as any;
  return w.SpeechRecognition || w.webkitSpeechRecognition || null;
}

function initialLang(): VoiceLang {
  if (typeof window === "undefined") return "en";
  const stored = window.localStorage.getItem("enable-bharat-language");
  return stored === "hi" ? "hi" : "en";
}

export function VoiceAssistant({ go, user, onAuthChange }: Props) {
  const [lang, setLang] = useState<VoiceLang>(initialLang);
  const [busy, setBusy] = useState(false);
  const [speaking, setSpeaking] = useState(false);
  const [status, setStatus] = useState("");
  const [heard, setHeard] = useState("");
  const [supported] = useState(() => Boolean(getSpeechRecognition()));

  const langRef = useRef(lang);
  const userRef = useRef(user);
  const busyRef = useRef(false);
  const greetedRef = useRef(false);
  langRef.current = lang;
  userRef.current = user;

  // Keep assistant language in sync with the site language selector.
  useEffect(() => {
    const onChange = (event: Event) => {
      const next = (event as CustomEvent<string>).detail;
      if (next === "hi" || next === "en") setLang(next);
    };
    window.addEventListener("enable-bharat-language-change", onChange);
    return () => window.removeEventListener("enable-bharat-language-change", onChange);
  }, []);

  const strings = STRINGS[lang];

  const speak = useCallback((text: string): Promise<void> => {
    return new Promise((resolve) => {
      if (typeof window === "undefined" || !window.speechSynthesis) return resolve();
      window.speechSynthesis.cancel();
      const utterance = new SpeechSynthesisUtterance(text);
      utterance.lang = RECOGNITION_LANG[langRef.current];
      const voices = window.speechSynthesis.getVoices();
      const match = voices.find((v) => v.lang === utterance.lang) || voices.find((v) => v.lang.startsWith(langRef.current));
      if (match) utterance.voice = match;
      setSpeaking(true);
      const done = () => { setSpeaking(false); resolve(); };
      utterance.onend = done;
      utterance.onerror = done;
      window.speechSynthesis.speak(utterance);
    });
  }, []);

  const recognizeOnce = useCallback((): Promise<string> => {
    return new Promise((resolve) => {
      const SpeechRecognition = getSpeechRecognition();
      if (!SpeechRecognition) return resolve("");
      const recognition = new SpeechRecognition();
      recognition.lang = RECOGNITION_LANG[langRef.current];
      recognition.interimResults = false;
      recognition.maxAlternatives = 1;
      let settled = false;
      const finish = (value: string) => {
        if (settled) return;
        settled = true;
        try { recognition.stop(); } catch { /* noop */ }
        resolve(value);
      };
      recognition.onresult = (event: any) => finish(event.results?.[0]?.[0]?.transcript?.trim() || "");
      recognition.onerror = () => finish("");
      recognition.onend = () => finish("");
      setStatus(strings.listening);
      try { recognition.start(); } catch { finish(""); }
      // Safety timeout so we never hang forever.
      window.setTimeout(() => finish(""), 12000);
    });
  }, [strings.listening]);

  const readPage = useCallback(async () => {
    await speak(strings.reading);
    const text = document.querySelector("main")?.textContent?.replace(/\s+/g, " ").trim().slice(0, 4000);
    if (text) await speak(text);
  }, [speak, strings.reading]);

  const runLoginFlow = useCallback(async () => {
    if (userRef.current) {
      await speak(strings.alreadyLoggedIn(userRef.current.name));
      return;
    }
    setStatus(strings.askEmail);
    await speak(strings.askEmail);
    const email = normalizeSpokenEmail(await recognizeOnce());
    setHeard(email);
    if (!email) { await speak(strings.notUnderstood); return; }
    await speak(strings.heardEmail(email));
    const password = normalizeSpokenPassword(await recognizeOnce());
    if (!password) { await speak(strings.notUnderstood); return; }
    setStatus(strings.loggingIn);
    await speak(strings.loggingIn);
    const result = await login(email, password);
    if (result.user) {
      onAuthChange(result.user);
      await speak(strings.loginSuccess(result.user.name));
      go(dashboardForRole(result.user.role));
    } else {
      await speak(strings.loginFailed);
    }
  }, [go, onAuthChange, recognizeOnce, speak, strings]);

  const handleAction = useCallback(async (action: CommandAction) => {
    switch (action.type) {
      case "navigate": {
        let target = action.target;
        // "dashboard" resolves to the signed-in user's workspace, or login.
        if (target === "candidate-dashboard") {
          if (userRef.current) target = dashboardForRole(userRef.current.role);
          else { await runLoginFlow(); return; }
        }
        const label = VIEW_LABELS[langRef.current][target] || target;
        await speak(strings.navigating(label));
        go(target);
        break;
      }
      case "login":
        await runLoginFlow();
        break;
      case "logout":
        if (userRef.current) {
          await logout();
          onAuthChange(null);
          go("home");
          await speak(strings.loggedOut);
        } else {
          await speak(strings.notLoggedIn);
        }
        break;
      case "read":
        await readPage();
        break;
      case "stop":
        if (typeof window !== "undefined") window.speechSynthesis?.cancel();
        setStatus(strings.stopped);
        break;
      case "help":
        await speak(strings.help);
        break;
    }
  }, [go, onAuthChange, readPage, runLoginFlow, speak, strings]);

  const startListening = useCallback(async () => {
    if (busyRef.current) {
      // Second tap acts as "stop".
      if (typeof window !== "undefined") window.speechSynthesis?.cancel();
      return;
    }
    if (!supported) {
      setStatus(strings.notSupported);
      await speak(strings.notSupported);
      return;
    }
    busyRef.current = true;
    setBusy(true);
    try {
      if (!greetedRef.current) {
        greetedRef.current = true;
        await speak(strings.greeting);
      }
      const transcript = await recognizeOnce();
      setHeard(transcript);
      const action = matchCommand(transcript);
      if (!action) {
        setStatus(strings.notUnderstood);
        await speak(strings.notUnderstood);
      } else {
        await handleAction(action);
      }
    } finally {
      busyRef.current = false;
      setBusy(false);
      setStatus("");
    }
  }, [handleAction, recognizeOnce, speak, strings, supported]);

  const toggleLang = () => {
    const next: VoiceLang = lang === "en" ? "hi" : "en";
    setLang(next);
    greetedRef.current = false;
  };

  return (
    <section className="voice-assistant" aria-label={lang === "hi" ? "आवाज़ सहायक" : "Voice assistant"}>
      {(status || heard) && (
        <div className="voice-assistant-status" aria-live="polite">
          {status && <strong>{status}</strong>}
          {heard && <span>“{heard}”</span>}
        </div>
      )}
      <div className="voice-assistant-controls">
        <button
          type="button"
          className="voice-assistant-lang"
          onClick={toggleLang}
          aria-label={lang === "en" ? "Switch voice assistant to Hindi" : "आवाज़ सहायक को अंग्रेज़ी में बदलें"}
        >
          {lang === "en" ? "EN" : "हिं"}
        </button>
        <button
          type="button"
          className={`voice-assistant-button ${busy ? "listening" : ""} ${speaking ? "speaking" : ""}`}
          onClick={startListening}
          aria-label={
            busy
              ? lang === "hi" ? "सुनना बंद करें" : "Stop listening"
              : lang === "hi" ? "आवाज़ सहायक शुरू करें" : "Start voice assistant"
          }
          aria-pressed={busy}
        >
          <svg aria-hidden="true" width={22} height={22} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={1.8} strokeLinecap="round" strokeLinejoin="round">
            <path d="M12 15a3 3 0 0 0 3-3V6a3 3 0 0 0-6 0v6a3 3 0 0 0 3 3ZM5 11a7 7 0 0 0 14 0M12 18v3M8 21h8" />
          </svg>
          <span>{busy ? (lang === "hi" ? "सुन रही हूँ…" : "Listening…") : (lang === "hi" ? "आवाज़ सहायक" : "Voice assistant")}</span>
        </button>
      </div>
    </section>
  );
}
