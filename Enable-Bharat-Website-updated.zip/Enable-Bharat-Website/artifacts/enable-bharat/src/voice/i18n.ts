// Bilingual (English / Hindi) command grammar and spoken strings for the
// voice assistant. Keeping this data-driven makes it easy to add languages
// or commands later.

export type VoiceLang = "en" | "hi";

export const RECOGNITION_LANG: Record<VoiceLang, string> = {
  en: "en-IN",
  hi: "hi-IN",
};

export type CommandAction =
  | { type: "navigate"; target: string }
  | { type: "login" }
  | { type: "logout" }
  | { type: "read" }
  | { type: "stop" }
  | { type: "help" };

type CommandDef = { keywords: string[]; action: CommandAction };

// Order matters: more specific / conflicting phrases are listed first.
const COMMANDS: CommandDef[] = [
  { keywords: ["how it works", "how does it work", "kaise kaam", "कैसे काम"], action: { type: "navigate", target: "how" } },
  { keywords: ["skill gap", "skill", "कौशल", "स्किल"], action: { type: "navigate", target: "skill-gap" } },
  { keywords: ["logout", "log out", "sign out", "लॉगआउट", "लॉग आउट", "साइन आउट", "बाहर निकलो", "बाहर"], action: { type: "logout" } },
  { keywords: ["login", "log in", "sign in", "signin", "लॉगिन", "लॉग इन", "साइन इन", "प्रवेश"], action: { type: "login" } },
  { keywords: ["register", "sign up", "signup", "create account", "पंजीकरण", "रजिस्टर", "खाता बनाओ", "अकाउंट बनाओ"], action: { type: "navigate", target: "register" } },
  { keywords: ["dashboard", "my account", "workspace", "डैशबोर्ड", "मेरा खाता"], action: { type: "navigate", target: "candidate-dashboard" } },
  { keywords: ["read", "read page", "read aloud", "पढ़ो", "पढ़ें", "सुनाओ", "सुनाएं"], action: { type: "read" } },
  { keywords: ["stop", "quiet", "silence", "रुको", "रुकें", "बंद करो", "चुप"], action: { type: "stop" } },
  { keywords: ["help me", "commands", "command", "what can you do", "कमांड", "मदद करो", "क्या कर सकते"], action: { type: "help" } },
  { keywords: ["find job", "jobs", "job", "vacancy", "नौकरी", "रोज़गार", "रोजगार"], action: { type: "navigate", target: "jobs" } },
  { keywords: ["candidate", "उम्मीदवार", "कैंडिडेट"], action: { type: "navigate", target: "candidates" } },
  { keywords: ["employer", "hire", "hiring", "नियोक्ता", "एम्प्लॉयर"], action: { type: "navigate", target: "employers" } },
  { keywords: ["passport", "पासपोर्ट"], action: { type: "navigate", target: "passport" } },
  { keywords: ["proof of work", "proof", "प्रमाण", "प्रूफ"], action: { type: "navigate", target: "proof" } },
  { keywords: ["hubs", "hub", "center", "centre", "केंद्र", "हब"], action: { type: "navigate", target: "hubs" } },
  { keywords: ["impact", "प्रभाव", "इम्पैक्ट"], action: { type: "navigate", target: "impact" } },
  { keywords: ["resources", "resource", "help center", "help centre", "संसाधन", "रिसोर्स"], action: { type: "navigate", target: "resources" } },
  { keywords: ["agla kadam", "videos", "video", "अगला कदम", "वीडियो"], action: { type: "navigate", target: "agla-kadam" } },
  { keywords: ["about", "बारे में", "अबाउट"], action: { type: "navigate", target: "about" } },
  { keywords: ["contact", "support", "संपर्क", "सहायता", "सपोर्ट"], action: { type: "navigate", target: "contact" } },
  { keywords: ["home", "main page", "होम", "मुख्य पृष्ठ", "घर"], action: { type: "navigate", target: "home" } },
];

export function matchCommand(transcript: string): CommandAction | null {
  const text = transcript.trim().toLowerCase();
  if (!text) return null;
  for (const command of COMMANDS) {
    if (command.keywords.some((keyword) => text.includes(keyword))) {
      return command.action;
    }
  }
  return null;
}

// Turn a spoken email ("ravi at enable bharat dot in") into "ravi@enablebharat.in".
export function normalizeSpokenEmail(transcript: string): string {
  return transcript
    .trim()
    .toLowerCase()
    .replace(/\s+at\s+|\s+at the rate\s+/g, "@")
    .replace(/\s+dot\s+|\s+point\s+|\s+डॉट\s+/g, ".")
    .replace(/\s+underscore\s+/g, "_")
    .replace(/\s+dash\s+|\s+hyphen\s+/g, "-")
    .replace(/[\s,]+/g, "");
}

// Passwords are spoken as separate tokens; collapse whitespace but keep symbols.
export function normalizeSpokenPassword(transcript: string): string {
  return transcript.trim().replace(/\s+/g, "");
}

type Strings = {
  greeting: string;
  listening: string;
  notUnderstood: string;
  notSupported: string;
  navigating: (label: string) => string;
  askEmail: string;
  heardEmail: (email: string) => string;
  askPassword: string;
  loggingIn: string;
  loginSuccess: (name: string) => string;
  loginFailed: string;
  alreadyLoggedIn: (name: string) => string;
  loggedOut: string;
  notLoggedIn: string;
  reading: string;
  stopped: string;
  help: string;
};

export const STRINGS: Record<VoiceLang, Strings> = {
  en: {
    greeting: "Hello. I am your Enable Bharat voice assistant. You can say login, find jobs, read page, or help.",
    listening: "Listening.",
    notUnderstood: "Sorry, I did not understand that. Say help to hear what you can ask.",
    notSupported: "Voice recognition is not supported in this browser. Please try Chrome.",
    navigating: (label) => `Opening ${label}.`,
    askEmail: "Please say your email address.",
    heardEmail: (email) => `I heard ${email}. Now please say your password.`,
    askPassword: "Please say your password.",
    loggingIn: "Signing you in, please wait.",
    loginSuccess: (name) => `Welcome back, ${name}. Opening your dashboard.`,
    loginFailed: "Incorrect email or password. Say login to try again.",
    alreadyLoggedIn: (name) => `You are already signed in as ${name}.`,
    loggedOut: "You have been signed out.",
    notLoggedIn: "You are not signed in.",
    reading: "Reading this page.",
    stopped: "Stopped.",
    help: "You can say: login, log out, find jobs, dashboard, read page, contact, or home. To sign in by voice, say login and I will ask for your email and password.",
  },
  hi: {
    greeting: "नमस्ते। मैं आपकी एनेबल भारत आवाज़ सहायक हूँ। आप कह सकते हैं लॉगिन, नौकरी खोजो, पेज पढ़ो, या मदद।",
    listening: "सुन रही हूँ।",
    notUnderstood: "माफ़ कीजिए, मैं समझ नहीं पाई। मदद कहें यह जानने के लिए कि आप क्या पूछ सकते हैं।",
    notSupported: "इस ब्राउज़र में आवाज़ पहचान समर्थित नहीं है। कृपया क्रोम आज़माएँ।",
    navigating: (label) => `${label} खोल रही हूँ।`,
    askEmail: "कृपया अपना ईमेल पता बोलें।",
    heardEmail: (email) => `मैंने सुना ${email}। अब कृपया अपना पासवर्ड बोलें।`,
    askPassword: "कृपया अपना पासवर्ड बोलें।",
    loggingIn: "आपको साइन इन कर रही हूँ, कृपया प्रतीक्षा करें।",
    loginSuccess: (name) => `वापसी पर स्वागत है, ${name}। आपका डैशबोर्ड खोल रही हूँ।`,
    loginFailed: "गलत ईमेल या पासवर्ड। दोबारा कोशिश के लिए लॉगिन कहें।",
    alreadyLoggedIn: (name) => `आप पहले से ${name} के रूप में साइन इन हैं।`,
    loggedOut: "आपको साइन आउट कर दिया गया है।",
    notLoggedIn: "आप साइन इन नहीं हैं।",
    reading: "यह पेज पढ़ रही हूँ।",
    stopped: "रुक गई।",
    help: "आप कह सकते हैं: लॉगिन, लॉग आउट, नौकरी खोजो, डैशबोर्ड, पेज पढ़ो, संपर्क, या होम। आवाज़ से साइन इन के लिए लॉगिन कहें, मैं आपका ईमेल और पासवर्ड पूछूँगी।",
  },
};

// Friendly labels used in "Opening ..." announcements.
export const VIEW_LABELS: Record<VoiceLang, Record<string, string>> = {
  en: {
    home: "home", how: "how it works", jobs: "jobs", candidates: "candidates",
    employers: "employers", "skill-gap": "skill gap", passport: "passport",
    proof: "proof of work", hubs: "hubs", impact: "impact", resources: "resources",
    "agla-kadam": "Agla Kadam", about: "about", contact: "contact", register: "registration",
    "candidate-dashboard": "your dashboard",
  },
  hi: {
    home: "होम", how: "यह कैसे काम करता है", jobs: "नौकरियाँ", candidates: "उम्मीदवार",
    employers: "नियोक्ता", "skill-gap": "कौशल अंतर", passport: "पासपोर्ट",
    proof: "प्रमाण", hubs: "केंद्र", impact: "प्रभाव", resources: "संसाधन",
    "agla-kadam": "अगला कदम", about: "बारे में", contact: "संपर्क", register: "पंजीकरण",
    "candidate-dashboard": "आपका डैशबोर्ड",
  },
};
