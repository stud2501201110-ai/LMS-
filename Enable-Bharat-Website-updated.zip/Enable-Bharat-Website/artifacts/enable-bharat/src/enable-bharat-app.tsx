"use client";

import { useEffect, useMemo, useRef, useState } from "react";
import { VoiceAssistant } from "./voice/voice-assistant";
import { dashboardForRole, fetchCurrentUser, login as apiLogin, type AuthUser } from "./lib/auth";

type View =
  | "home"
  | "how"
  | "jobs"
  | "job-detail"
  | "candidates"
  | "employers"
  | "skill-gap"
  | "passport"
  | "proof"
  | "hubs"
  | "impact"
  | "resources"
  | "agla-kadam"
  | "about"
  | "contact"
  | "login"
  | "register"
  | "candidate-dashboard"
  | "candidate-passport"
  | "candidate-skills"
  | "candidate-learning"
  | "candidate-assessments"
  | "candidate-proof"
  | "candidate-applications"
  | "candidate-settings"
  | "employer-dashboard"
  | "employer-jobs"
  | "employer-candidates"
  | "employer-shortlisted"
  | "employer-interviews"
  | "employer-analytics"
  | "employer-company"
  | "assessor-dashboard"
  | "admin-dashboard";

type IconName =
  | "arrow"
  | "check"
  | "menu"
  | "close"
  | "accessibility"
  | "search"
  | "shield"
  | "spark"
  | "briefcase"
  | "users"
  | "book"
  | "target"
  | "play"
  | "location"
  | "clock"
  | "chevron"
  | "download"
  | "share"
  | "lock"
  | "building"
  | "chart"
  | "settings"
  | "message"
  | "bell"
  | "plus"
  | "filter"
  | "calendar"
  | "file"
  | "layers"
  | "grid"
  | "clipboard"
  | "home"
  | "user"
  | "sliders"
  | "help"
  | "globe"
  | "external"
  | "mic"
  | "pause"
  | "eye"
  | "upload"
  | "send"
  | "heart"
  | "bookmark"
  | "flag";

type GoogleLanguage = {
  code: string;
  label: string;
  nativeLabel: string;
};

const GOOGLE_TRANSLATE_LANGUAGES: GoogleLanguage[] = [
  { code: "en", label: "English", nativeLabel: "English" },
  { code: "hi", label: "Hindi", nativeLabel: "हिन्दी" },
  { code: "gu", label: "Gujarati", nativeLabel: "ગુજરાતી" },
  { code: "mr", label: "Marathi", nativeLabel: "मराठी" },
  { code: "bn", label: "Bengali", nativeLabel: "বাংলা" },
  { code: "ta", label: "Tamil", nativeLabel: "தமிழ்" },
  { code: "te", label: "Telugu", nativeLabel: "తెలుగు" },
  { code: "kn", label: "Kannada", nativeLabel: "ಕನ್ನಡ" },
  { code: "ml", label: "Malayalam", nativeLabel: "മലയാളം" },
  { code: "pa", label: "Punjabi", nativeLabel: "ਪੰਜਾਬੀ" },
  { code: "or", label: "Odia", nativeLabel: "ଓଡ଼ିଆ" },
  { code: "as", label: "Assamese", nativeLabel: "অসমীয়া" },
  { code: "ur", label: "Urdu", nativeLabel: "اردو" },
  { code: "ne", label: "Nepali", nativeLabel: "नेपाली" },
  { code: "sa", label: "Sanskrit", nativeLabel: "संस्कृतम्" },
];

const GOOGLE_LANGUAGE_STORAGE_KEY = "enable-bharat-language";

declare global {
  interface Window {
    google?: {
      translate?: {
        TranslateElement: new (
          options: { pageLanguage: string; includedLanguages: string; autoDisplay: boolean; layout?: unknown },
          elementId: string,
        ) => unknown;
      };
    };
    googleTranslateElementInit?: () => void;
  }
}

function getSelectedLanguage() {
  if (typeof window === "undefined") return "en";
  const cookie = document.cookie.match(/(?:^|;\s*)googtrans=\/en\/([^;]+)/)?.[1];
  const stored = window.localStorage.getItem(GOOGLE_LANGUAGE_STORAGE_KEY);
  return GOOGLE_TRANSLATE_LANGUAGES.some((language) => language.code === cookie) ? cookie! :
    GOOGLE_TRANSLATE_LANGUAGES.some((language) => language.code === stored) ? stored! : "en";
}

function saveSelectedLanguage(language: string) {
  if (typeof window === "undefined") return;
  document.cookie = `googtrans=/en/${language}; path=/; max-age=31536000; SameSite=Lax`;
  window.localStorage.setItem(GOOGLE_LANGUAGE_STORAGE_KEY, language);
  document.documentElement.lang = language;
}

function applyGoogleLanguage(language: string) {
  saveSelectedLanguage(language);
  const googleSelect = document.querySelector<HTMLSelectElement>(".goog-te-combo");
  if (googleSelect) {
    googleSelect.value = language;
    googleSelect.dispatchEvent(new Event("change", { bubbles: true }));
  } else {
    window.location.reload();
  }
  window.dispatchEvent(new CustomEvent("enable-bharat-language-change", { detail: language }));
}

function GoogleTranslate() {
  useEffect(() => {
    let refreshTimer: number | undefined;
    let applying = false;
    let currentLanguage = getSelectedLanguage();
    saveSelectedLanguage(currentLanguage);

    const onLanguageChange = (event: Event) => {
      const nextLanguage = (event as CustomEvent<string>).detail;
      if (typeof nextLanguage === "string") currentLanguage = nextLanguage;
    };
    window.addEventListener("enable-bharat-language-change", onLanguageChange);

    const refreshTranslation = () => {
      if (currentLanguage === "en" || applying) return;
      const googleSelect = document.querySelector<HTMLSelectElement>(".goog-te-combo");
      if (!googleSelect) return;
      applying = true;
      googleSelect.value = currentLanguage;
      googleSelect.dispatchEvent(new Event("change", { bubbles: true }));
      window.setTimeout(() => { applying = false; }, 1800);
    };

    const initializeGoogleTranslate = () => {
      if (!window.google?.translate?.TranslateElement) return;
      if (!document.querySelector("#google_translate_element .goog-te-combo")) {
        new window.google.translate.TranslateElement({
          pageLanguage: "en",
          includedLanguages: GOOGLE_TRANSLATE_LANGUAGES.map((language) => language.code).join(","),
          autoDisplay: false,
          layout: 0,
        }, "google_translate_element");
      }
      window.setTimeout(refreshTranslation, 350);
    };

    window.googleTranslateElementInit = initializeGoogleTranslate;
    const existingScript = document.querySelector<HTMLScriptElement>('script[data-enable-bharat-google-translate]');
    if (window.google?.translate?.TranslateElement) {
      initializeGoogleTranslate();
    } else if (!existingScript) {
      const script = document.createElement("script");
      script.src = "https://translate.google.com/translate_a/element.js?cb=googleTranslateElementInit";
      script.async = true;
      script.dataset.enableBharatGoogleTranslate = "true";
      document.head.appendChild(script);
    }

    const root = document.getElementById("root");
    const observer = new MutationObserver((mutations) => {
      if (currentLanguage === "en" || applying) return;
      const hasNewPageContent = mutations.some((mutation) => Array.from(mutation.addedNodes).some((node) => {
        return node.nodeType === Node.ELEMENT_NODE && !(node as Element).closest("#google_translate_element");
      }));
      if (!hasNewPageContent) return;
      window.clearTimeout(refreshTimer);
      refreshTimer = window.setTimeout(refreshTranslation, 700);
    });
    if (root) observer.observe(root, { childList: true, subtree: true });

    return () => {
      window.clearTimeout(refreshTimer);
      observer.disconnect();
      window.removeEventListener("enable-bharat-language-change", onLanguageChange);
    };
  }, []);

  return <div id="google_translate_element" className="google-translate-widget" aria-hidden="true" />;
}

function LanguageSelector({ mobile = false }: { mobile?: boolean }) {
  const [language, setLanguage] = useState(getSelectedLanguage);

  useEffect(() => {
    const onLanguageChange = (event: Event) => {
      const nextLanguage = (event as CustomEvent<string>).detail;
      if (typeof nextLanguage === "string") setLanguage(nextLanguage);
    };
    window.addEventListener("enable-bharat-language-change", onLanguageChange);
    return () => window.removeEventListener("enable-bharat-language-change", onLanguageChange);
  }, []);

   return <label className={`language-selector ${mobile ? "language-selector-mobile" : ""}`}>
    <Icon name="globe" size={17} />
     <span>Language / भाषा</span>
    <select
      value={language}
      onChange={(event) => {
        const nextLanguage = event.target.value;
        setLanguage(nextLanguage);
        applyGoogleLanguage(nextLanguage);
      }}
      aria-label="🌐 Language / भाषा"
    >
       {GOOGLE_TRANSLATE_LANGUAGES.map((item) => <option value={item.code} key={item.code}>{item.nativeLabel}</option>)}
    </select>
  </label>;
}

const iconPaths: Record<IconName, string> = {
  arrow: "M5 12h14M13 6l6 6-6 6",
  check: "M5 12l4 4L19 6",
  menu: "M4 7h16M4 12h16M4 17h16",
  close: "M6 6l12 12M18 6L6 18",
  accessibility: "M12 5.5a2 2 0 1 0 0-4 2 2 0 0 0 0 4ZM5 7h14M12 7v12M8 21l4-7 4 7M8 10l4 2 4-2",
  search: "m21 21-4.4-4.4M10.8 18a7.2 7.2 0 1 1 0-14.4 7.2 7.2 0 0 1 0 14.4Z",
  shield: "M12 3 20 6v5c0 5-3.4 8.3-8 10-4.6-1.7-8-5-8-10V6l8-3ZM8 12l2.5 2.5L16 9",
  spark: "m12 3 1.5 5.5L19 10l-5.5 1.5L12 17l-1.5-5.5L5 10l5.5-1.5L12 3ZM19 16l.7 2.3L22 19l-2.3.7L19 22l-.7-2.3L16 19l2.3-.7L19 16Z",
  briefcase: "M4 8h16v11H4zM8 8V5h8v3M4 12h16M10 12v2h4v-2",
  users: "M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2M9 11a4 4 0 1 0 0-8 4 4 0 0 0 0 8ZM22 21v-2a4 4 0 0 0-3-3.9M16 3.1a4 4 0 0 1 0 7.8",
  book: "M4 5.5A2.5 2.5 0 0 1 6.5 3H20v16H6.5A2.5 2.5 0 0 0 4 21.5v-16ZM4 19.5A2.5 2.5 0 0 1 6.5 17H20",
  target: "M12 3v3M12 18v3M3 12h3M18 12h3M18.4 5.6l-2.1 2.1M7.7 16.3l-2.1 2.1M18.4 18.4l-2.1-2.1M7.7 7.7 5.6 5.6M16 12a4 4 0 1 1-8 0 4 4 0 0 1 8 0Z",
  play: "M8 5v14l11-7L8 5Z",
  location: "M20 10c0 5-8 11-8 11S4 15 4 10a8 8 0 1 1 16 0Z M12 13a3 3 0 1 0 0-6 3 3 0 0 0 0 6Z",
  clock: "M12 21a9 9 0 1 0 0-18 9 9 0 0 0 0 18ZM12 7v5l3 2",
  chevron: "m9 18 6-6-6-6",
  download: "M12 3v12m0 0 4-4m-4 4-4-4M5 21h14",
  share: "M18 8a3 3 0 1 0-2.8-4 3 3 0 0 0 0 1l-6.4 3.7a3 3 0 1 0 0 6l6.4 3.7a3 3 0 1 0 .8-1.4l-6.4-3.7a3 3 0 0 0 0-1l6.4-3.7c.5.4 1.2.7 2 .7ZM18 21a3 3 0 1 0 0-6 3 3 0 0 0 0 6Z",
  lock: "M6 10V7a6 6 0 0 1 12 0v3M5 10h14v10H5zM12 14v2",
  building: "M3 21h18M5 21V5l7-2v18M12 21V8l7-2v15M8 8h1M8 12h1M8 16h1M15 11h1M15 15h1M15 18h1",
  chart: "M4 19V5M4 19h17M8 16v-4M12 16V8M16 16v-7M20 16V4",
  settings: "M12 15.5a3.5 3.5 0 1 0 0-7 3.5 3.5 0 0 0 0 7ZM19.4 15a1.8 1.8 0 0 0 .4 2l.1.1-1.8 1.8-.1-.1a1.8 1.8 0 0 0-2-.4 1.8 1.8 0 0 0-1.1 1.7V20h-2.6v-.2a1.8 1.8 0 0 0-1.1-1.7 1.8 1.8 0 0 0-2 .4l-.1.1-1.8-1.8.1-.1a1.8 1.8 0 0 0 .4-2A1.8 1.8 0 0 0 6.2 14H6v-2.6h.2a1.8 1.8 0 0 0 1.6-1.1 1.8 1.8 0 0 0-.4-2l-.1-.1 1.8-1.8.1.1a1.8 1.8 0 0 0 2 .4A1.8 1.8 0 0 0 12.3 5V4.8h2.6V5a1.8 1.8 0 0 0 1.1 1.7 1.8 1.8 0 0 0 2-.4l.1-.1 1.8 1.8-.1.1a1.8 1.8 0 0 0-.4 2 1.8 1.8 0 0 0 1.6 1.1h.2v2.6H21a1.8 1.8 0 0 0-1.6 1.1Z",
  message: "M21 11.5a8.5 8.5 0 0 1-9 8.5 9.4 9.4 0 0 1-3.8-.8L3 21l1.8-4A8.2 8.2 0 0 1 3 11.5 8.5 8.5 0 0 1 12 3a8.5 8.5 0 0 1 9 8.5Z",
  bell: "M18 8a6 6 0 0 0-12 0c0 7-3 7-3 9h18c0-2-3-2-3-9ZM10 21h4",
  plus: "M12 5v14M5 12h14",
  filter: "M4 6h16M7 12h10M10 18h4",
  calendar: "M5 4h14v16H5zM8 2v4M16 2v4M5 9h14",
  file: "M6 3h8l4 4v14H6zM14 3v5h5M9 13h6M9 17h6",
  layers: "m12 3 9 5-9 5-9-5 9-5ZM3 12l9 5 9-5M3 16l9 5 9-5",
  grid: "M4 4h6v6H4zM14 4h6v6h-6zM4 14h6v6H4zM14 14h6v6h-6z",
  clipboard: "M9 5h6M9 3h6v4H9zM6 5H4v16h16V5h-2M8 13h8M8 17h5",
  home: "M3 11 12 4l9 7v9H4v-9ZM9 20v-6h6v6",
  user: "M20 21a8 8 0 0 0-16 0M12 12a4 4 0 1 0 0-8 4 4 0 0 0 0 8Z",
  sliders: "M4 6h10M18 6h2M4 12h2M10 12h10M4 18h10M18 18h2M14 4v4M8 10v4M14 16v4",
  help: "M9.1 9a3 3 0 1 1 5.2 2c-1.4 1.1-2.3 1.7-2.3 3M12 18h.01M12 22a10 10 0 1 0 0-20 10 10 0 0 0 0 20Z",
  globe: "M12 21a9 9 0 1 0 0-18 9 9 0 0 0 0 18ZM3 12h18M12 3c2.3 2.5 3.5 5.5 3.5 9s-1.2 6.5-3.5 9c-2.3-2.5-3.5-5.5-3.5-9S9.7 5.5 12 3Z",
  external: "M14 4h6v6M20 4l-9 9M18 13v6H4V5h6",
  mic: "M12 15a3 3 0 0 0 3-3V6a3 3 0 0 0-6 0v6a3 3 0 0 0 3 3ZM5 11a7 7 0 0 0 14 0M12 18v3M8 21h8",
  pause: "M7 4h3v16H7zM14 4h3v16h-3z",
  eye: "M2 12s3.5-6 10-6 10 6 10 6-3.5 6-10 6S2 12 2 12ZM12 15a3 3 0 1 0 0-6 3 3 0 0 0 0 6Z",
  upload: "M12 16V4m0 0 4 4m-4-4L8 8M4 14v5h16v-5",
  send: "m22 2-7 20-4-9-9-4 20-7ZM22 2l-11 11",
  heart: "M20.8 8.8c0 5.3-8.8 10.2-8.8 10.2S3.2 14.1 3.2 8.8A4.8 4.8 0 0 1 12 6.1a4.8 4.8 0 0 1 8.8 2.7Z",
  bookmark: "M6 4h12v17l-6-3-6 3V4Z",
  flag: "M5 21V4m0 0c4-3 7 3 14 0v9c-7 3-10-3-14 0",
};

function Icon({ name, size = 20, strokeWidth = 1.8 }: { name: IconName; size?: number; strokeWidth?: number }) {
  return (
    <svg aria-hidden="true" width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={strokeWidth} strokeLinecap="round" strokeLinejoin="round">
      <path d={iconPaths[name]} />
    </svg>
  );
}

function VoiceTextAssist() {
  const [focused, setFocused] = useState(false);
  const [listening, setListening] = useState(false);
  const [notice, setNotice] = useState("");
  const targetRef = useRef<HTMLInputElement | HTMLTextAreaElement | null>(null);
  const recognitionRef = useRef<any>(null);

  useEffect(() => {
    const onFocus = (event: FocusEvent) => {
      const element = event.target as HTMLInputElement | HTMLTextAreaElement;
      const isTextField = element instanceof HTMLTextAreaElement || (element instanceof HTMLInputElement && ["text", "search", "email", "tel"].includes(element.type));
      if (isTextField) {
        targetRef.current = element;
        setFocused(true);
        setNotice("");
      }
    };
    const onBlur = () => window.setTimeout(() => {
      if (document.activeElement !== targetRef.current) setFocused(false);
    }, 180);
    document.addEventListener("focusin", onFocus);
    document.addEventListener("focusout", onBlur);
    return () => {
      document.removeEventListener("focusin", onFocus);
      document.removeEventListener("focusout", onBlur);
      recognitionRef.current?.abort?.();
    };
  }, []);

  const toggleListening = () => {
    const browserWindow = window as Window & { SpeechRecognition?: any; webkitSpeechRecognition?: any };
    const SpeechRecognition = browserWindow.SpeechRecognition || browserWindow.webkitSpeechRecognition;
    if (!SpeechRecognition) {
      setNotice("Voice input is not supported in this browser. You can still type here.");
      return;
    }
    if (listening) {
      recognitionRef.current?.stop?.();
      setListening(false);
      return;
    }
    const target = targetRef.current;
    if (!target) {
      setNotice("Click or tap a text field first, then try voice input.");
      return;
    }
    const recognition = new SpeechRecognition();
    recognition.lang = "en-IN";
    recognition.interimResults = false;
    recognition.maxAlternatives = 1;
    recognition.onstart = () => { setListening(true); setNotice("Listening… speak clearly."); };
    recognition.onerror = () => { setListening(false); setNotice("We could not hear that. Please try again or type instead."); };
    recognition.onend = () => setListening(false);
    recognition.onresult = (event: any) => {
      const transcript = event.results?.[0]?.[0]?.transcript?.trim();
      if (!transcript || !targetRef.current) return;
      const field = targetRef.current;
      const prefix = field.value && !field.value.endsWith(" ") ? `${field.value} ` : field.value;
      const setter = Object.getOwnPropertyDescriptor(Object.getPrototypeOf(field), "value")?.set;
      setter?.call(field, `${prefix}${transcript}`);
      field.dispatchEvent(new Event("input", { bubbles: true }));
      setNotice("Added to your text field.");
    };
    recognitionRef.current = recognition;
    try { recognition.start(); } catch { setNotice("Voice input is busy. Please try again."); }
  };

  return <aside className={`voice-assist ${focused ? "visible" : ""}`} aria-live="polite">
    <button className={`voice-assist-button ${listening ? "listening" : ""}`} onClick={toggleListening} aria-label={listening ? "Stop voice input" : "Start voice input"}>
      <Icon name={listening ? "pause" : "mic"} size={18} />
      <span>{listening ? "Listening" : "Voice input"}</span>
    </button>
    {notice && <span className="voice-assist-notice">{notice}</span>}
  </aside>;
}

function VoiceField({ value, onChange, placeholder, ariaLabel, multiline = false, id }: { value: string; onChange: (value: string) => void; placeholder: string; ariaLabel: string; multiline?: boolean; id?: string }) {
  return <div className="voice-field">
    {multiline ? <textarea id={id} value={value} onChange={(event) => onChange(event.target.value)} placeholder={placeholder} aria-label={ariaLabel} rows={3} /> : <input id={id} value={value} onChange={(event) => onChange(event.target.value)} placeholder={placeholder} aria-label={ariaLabel} />}
    <span className="voice-field-hint"><Icon name="mic" size={14} /> Voice input available</span>
  </div>;
}

const journey = [
  { no: "01", title: "Verify", text: "Build a trusted foundation with privacy-led identity and profile checks.", icon: "shield" as IconName, tone: "navy" },
  { no: "02", title: "Assess", text: "Understand real capability through human, accessible assessment.", icon: "target" as IconName, tone: "orange" },
  { no: "03", title: "Map role", text: "Translate strengths into roles that fit the way you work best.", icon: "briefcase" as IconName, tone: "green" },
  { no: "04", title: "Find skill gap", text: "Identify only the missing skills between today and a target role.", icon: "search" as IconName, tone: "navy" },
  { no: "05", title: "Learn", text: "Move through accessible, focused micro-learning in your format.", icon: "book" as IconName, tone: "orange" },
  { no: "06", title: "Prove", text: "Demonstrate workplace tasks and earn evidence employers trust.", icon: "clipboard" as IconName, tone: "green" },
  { no: "07", title: "Match", text: "See inclusive opportunities ranked by skill and support fit.", icon: "spark" as IconName, tone: "navy" },
  { no: "08", title: "Hire", text: "Start work with the right context, confidence and support.", icon: "users" as IconName, tone: "orange" },
];

const jobs = [
  { id: "customer-support", company: "Aarohan Retail", title: "Customer Support Executive", location: "Ahmedabad", mode: "Hybrid", salary: "₹18,000 – ₹25,000 / month", match: 92, logo: "AR", color: "#e9f0ff", features: ["Accessible workplace", "Flexible work schedule", "Assistive technology support"], verified: true, type: "Full time" },
  { id: "data-entry", company: "Nirmaan Services", title: "Data Entry Operator", location: "Vadodara", mode: "On-site", salary: "₹16,000 – ₹22,000 / month", match: 87, logo: "NS", color: "#fff3e5", features: ["Structured tasks", "Screen-reader compatible", "Mentor support"], verified: true, type: "Full time" },
  { id: "inventory", company: "Sahyog Logistics", title: "Inventory Assistant", location: "Surat", mode: "On-site", salary: "₹19,000 – ₹27,000 / month", match: 81, logo: "SL", color: "#e9f8ef", features: ["Accessible workstation", "Visual task guides", "Transport support"], verified: true, type: "Full time" },
  { id: "content", company: "Udaan Digital", title: "Content Review Associate", location: "Remote · India", mode: "Remote", salary: "₹20,000 – ₹30,000 / month", match: 76, logo: "UD", color: "#f1ecff", features: ["Remote first", "Flexible hours", "Captioned training"], verified: true, type: "Part time" },
];

const candidates = [
  { name: "Asha Patel", role: "Data Entry Candidate", initials: "AP", match: 89, location: "Ahmedabad", skills: ["Computer basics", "Typing", "Spreadsheet skills"], access: "Screen-reader compatible", proof: "Verified proof-of-work" },
  { name: "Ravi Mehta", role: "Customer Support Associate", initials: "RM", match: 94, location: "Vadodara", skills: ["Communication", "CRM basics", "Customer interaction"], access: "Structured onboarding", proof: "Job-ready · 92%" },
  { name: "Meera Shah", role: "Inventory Assistant", initials: "MS", match: 86, location: "Surat", skills: ["Stock counting", "Digital skills", "Teamwork"], access: "Accessible workplace", proof: "Assessment scheduled" },
];

const hubs = [
  { name: "Enable Lab · Vadodara", city: "Vadodara", distance: "2.4 km", equipment: "12 laptops · POS kit", session: "Sat, 24 Aug · 10:00 AM", features: ["Step-free access", "Screen reader", "Quiet room"], assessor: true },
  { name: "Sahyog Digital Hub", city: "Ahmedabad", distance: "8.1 km", equipment: "20 laptops · Spreadsheet lab", session: "Tue, 27 Aug · 2:00 PM", features: ["Accessible restroom", "Large print guides"], assessor: true },
  { name: "Saksham Skills Lab", city: "Surat", distance: "4.8 km", equipment: "POS kit · Practice store", session: "Thu, 29 Aug · 11:00 AM", features: ["Ramp access", "ISL support"], assessor: false },
];

const modules = [
  { title: "Introduction to POS", duration: "12 min", status: "done" },
  { title: "POS Interface", duration: "18 min", status: "done" },
  { title: "Billing Workflow", duration: "22 min", status: "current" },
  { title: "Refund Process", duration: "15 min", status: "next" },
  { title: "Practical Task", duration: "25 min", status: "next" },
];

const aglaCategories = ["All", "Success stories", "Learn & skills", "Job awareness", "Government updates", "Employer insights", "Accessibility"];
const aglaVideos = [
  { id: "excel", category: "Learn & skills", title: "Three Excel skills needed for Data Entry jobs", creator: "Enable Bharat Learning", creatorType: "Enable Bharat Admin", duration: "00:42", views: "1.8k views", action: "Check Skill Gap", destination: "skill-gap" as View, tone: "orange", initials: "EB", transcript: "Start with clean tables, keyboard shortcuts and a quick data quality check. These three habits make everyday data entry work faster and more accurate.", tags: ["Spreadsheet skills", "Data entry"] },
  { id: "conversation", category: "Learn & skills", title: "A simple way to start a customer conversation", creator: "Enable Bharat Learning", creatorType: "Enable Bharat Admin", duration: "00:39", views: "1.1k views", action: "Learn This Skill", destination: "candidate-learning" as View, tone: "navy", initials: "EB", transcript: "Open with a clear greeting, listen for the customer’s need and close with one confirmed next step. A simple structure helps every conversation feel more manageable.", tags: ["Communication", "Customer support"] },
  { id: "ravi", category: "Success stories", title: "Ravi’s first week as a Customer Support Associate", creator: "Ravi Mehta", creatorType: "Verified Candidate · Proof-of-Work Verified", duration: "00:58", views: "2.4k views", action: "Start Your Journey", destination: "register" as View, tone: "navy", initials: "RM", transcript: "My Passport helped me explain how I work best. The practical task gave the employer a clearer picture than a certificate could.", tags: ["Candidate story", "Workplace confidence"] },
  { id: "retail", category: "Job awareness", title: "What does a Store Associate actually do?", creator: "Aarohan Retail", creatorType: "Verified Employer", duration: "00:35", views: "986 views", action: "View Job", destination: "job-detail" as View, tone: "green", initials: "AR", transcript: "A Store Associate welcomes customers, keeps shelves organised and uses a simple POS workflow. Clear routines and a supportive team make the role easier to learn.", tags: ["Retail", "Customer interaction"] },
  { id: "update", category: "Government updates", title: "A clearer way to follow employment updates", creator: "Enable Bharat Updates", creatorType: "Enable Bharat Admin", duration: "00:47", views: "742 views", action: "Read Update", destination: "resources" as View, tone: "purple", initials: "EB", transcript: "Important updates should be easy to understand and easy to act on. Save this update and check the official source before you apply.", tags: ["Verified information", "Resources"] },
];

function Logo({ compact = false }: { compact?: boolean }) {
  return <span className={`brand-logo-frame ${compact ? "compact" : ""}`}><img className="brand-logo" src="/enable-bharat-logo-transparent.png" alt="Enable Bharat" /></span>;
}

function Button({ children, variant = "primary", onClick, icon, className = "", type = "button" }: { children: React.ReactNode; variant?: "primary" | "orange" | "secondary" | "ghost" | "success"; onClick?: () => void; icon?: IconName; className?: string; type?: "button" | "submit" }) {
  return <button type={type} onClick={onClick} className={`button button-${variant} ${className}`}>{children}{icon && <Icon name={icon} size={17} />}</button>;
}

function Badge({ children, tone = "neutral", icon }: { children: React.ReactNode; tone?: "neutral" | "verified" | "orange" | "navy" | "purple" | "green"; icon?: IconName }) {
  return <span className={`badge badge-${tone}`}>{icon && <Icon name={icon} size={13} />}{children}</span>;
}

function ProgressBar({ value, tone = "orange" }: { value: number; tone?: "orange" | "green" | "navy" }) {
  return <div className="progress-track" aria-label={`${value}% complete`}><span className={`progress-fill progress-${tone}`} style={{ width: `${value}%` }} /></div>;
}

function SectionHeader({ eyebrow, title, description, align = "left" }: { eyebrow?: string; title: string; description?: string; align?: "left" | "center" }) {
  return <div className={`section-header align-${align}`}>{eyebrow && <p className="eyebrow">{eyebrow}</p>}<h2>{title}</h2>{description && <p className="section-description">{description}</p>}</div>;
}

function AccessibilityToolbar({ open, setOpen }: { open: boolean; setOpen: (value: boolean) => void }) {
  const [fontScale, setFontScale] = useState(0);
  const [contrast, setContrast] = useState(false);
  const [reduceMotion, setReduceMotion] = useState(false);
  const [keyboard, setKeyboard] = useState(false);
  const [speaking, setSpeaking] = useState(false);

  useEffect(() => {
    document.documentElement.style.setProperty("--font-scale", `${fontScale * 0.06}rem`);
    document.body.classList.toggle("high-contrast", contrast);
    document.body.classList.toggle("reduce-motion", reduceMotion);
    document.body.classList.toggle("keyboard-mode", keyboard);
    return () => {
      document.documentElement.style.removeProperty("--font-scale");
      document.body.classList.remove("high-contrast", "reduce-motion", "keyboard-mode");
    };
  }, [fontScale, contrast, reduceMotion, keyboard]);

  const readPage = () => {
    if (typeof window === "undefined" || !window.speechSynthesis) return;
    if (speaking) { window.speechSynthesis.cancel(); setSpeaking(false); return; }
    const text = document.querySelector("main")?.textContent?.slice(0, 2800) || "Enable Bharat. Verified inclusive employment ecosystem.";
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.onend = () => setSpeaking(false);
    window.speechSynthesis.speak(utterance);
    setSpeaking(true);
  };

  return <>
    <button className="accessibility-fab" aria-label="Open accessibility settings" onClick={() => setOpen(!open)}><Icon name="accessibility" size={20} /><span>Accessibility</span></button>
    {open && <aside className="accessibility-panel" aria-label="Accessibility toolbar">
      <div className="accessibility-panel-head"><div><p className="eyebrow">ACCESSIBILITY</p><h2>Make this work for you</h2></div><button className="icon-button" aria-label="Close accessibility toolbar" onClick={() => setOpen(false)}><Icon name="close" size={18} /></button></div>
      <p className="panel-copy">Your settings stay active while you explore Enable Bharat.</p>
      <div className="accessibility-actions">
        <button onClick={() => setFontScale(Math.min(2, fontScale + 1))}><span className="action-icon">A+</span><span>Text size +</span></button>
        <button onClick={() => setFontScale(Math.max(-2, fontScale - 1))}><span className="action-icon small">A−</span><span>Text size −</span></button>
        <button className={contrast ? "selected" : ""} onClick={() => setContrast(!contrast)}><Icon name="eye" size={18} /><span>High contrast</span></button>
        <button className={speaking ? "selected" : ""} onClick={readPage}><Icon name={speaking ? "pause" : "mic"} size={18} /><span>{speaking ? "Stop reading" : "Read aloud"}</span></button>
        <button className={keyboard ? "selected" : ""} onClick={() => setKeyboard(!keyboard)}><Icon name="clipboard" size={18} /><span>Keyboard navigation</span></button>
        <button className={reduceMotion ? "selected" : ""} onClick={() => setReduceMotion(!reduceMotion)}><Icon name="pause" size={18} /><span>Reduce motion</span></button>
      </div>
      <div className="panel-note"><Icon name="shield" size={16} /><span>Built for WCAG-oriented access. No preference changes your profile data.</span></div>
    </aside>}
  </>;
}

function Header({ go }: { go: (view: View) => void }) {
  const [menuOpen, setMenuOpen] = useState(false);
  const [moreOpen, setMoreOpen] = useState(false);
  const [accessibilityOpen, setAccessibilityOpen] = useState(false);
  const moreMenuRef = useRef<HTMLDivElement>(null);
  const navItems: { label: string; view: View }[] = [
    { label: "How it works", view: "how" }, { label: "Find jobs", view: "jobs" }, { label: "For candidates", view: "candidates" }, { label: "For employers", view: "employers" },
  ];
  const moreNavItems: { label: string; view: View }[] = [
    { label: "Agla Kadam", view: "agla-kadam" },
    { label: "Skill gap bridge", view: "skill-gap" },
    { label: "Impact", view: "impact" },
  ];
  useEffect(() => {
    const closeMoreMenu = (event: PointerEvent) => {
      if (moreMenuRef.current && !moreMenuRef.current.contains(event.target as Node)) setMoreOpen(false);
    };
    const closeOnEscape = (event: KeyboardEvent) => {
      if (event.key === "Escape") setMoreOpen(false);
    };
    document.addEventListener("pointerdown", closeMoreMenu);
    document.addEventListener("keydown", closeOnEscape);
    return () => {
      document.removeEventListener("pointerdown", closeMoreMenu);
      document.removeEventListener("keydown", closeOnEscape);
    };
  }, []);
  const navigate = (view: View) => { setMenuOpen(false); setMoreOpen(false); go(view); };
  return <>
    <a className="skip-link" href="#main-content">Skip to main content</a>
    <div className="trust-strip"><div className="container trust-strip-inner"><span><Icon name="shield" size={14} /> Privacy-led. Capability-first.</span><span className="trust-strip-right">English <span className="dot-separator">·</span> <span className="language-link">हिन्दी</span> <span className="dot-separator">·</span> <span className="language-link">ગુજરાતી</span></span></div></div>
     <header className="site-header"><div className="container header-inner"><button className="logo-button" onClick={() => navigate("home")} aria-label="Enable Bharat home"><Logo /></button><nav className={`main-nav ${menuOpen ? "open" : ""}`} aria-label="Primary navigation">{navItems.map((item) => <button key={item.view} onClick={() => navigate(item.view)}>{item.label}</button>)}<div className="nav-more" ref={moreMenuRef}><button className="nav-more-trigger" onClick={() => setMoreOpen(!moreOpen)} aria-expanded={moreOpen} aria-haspopup="true">Explore <Icon name="chevron" size={14} /></button>{moreOpen && <div className="nav-more-menu" role="menu">{moreNavItems.map((item) => <button role="menuitem" key={item.view} onClick={() => navigate(item.view)}>{item.label}</button>)}</div>}</div><div className="mobile-nav-actions"><LanguageSelector mobile /><Button variant="secondary" onClick={() => navigate("login")}>Log in</Button><Button variant="orange" onClick={() => navigate("register")} icon="arrow">Get started</Button></div></nav><div className="header-actions"><LanguageSelector /><button className="header-access" onClick={() => setAccessibilityOpen(true)} aria-label="Accessibility settings"><Icon name="accessibility" size={20} /></button><button className="login-link" onClick={() => navigate("login")}>Log in</button><Button variant="orange" onClick={() => navigate("register")} icon="arrow">Get started</Button><button className="menu-toggle" onClick={() => setMenuOpen(!menuOpen)} aria-label={menuOpen ? "Close menu" : "Open menu"}><Icon name={menuOpen ? "close" : "menu"} size={23} /></button></div></div></header>
    <AccessibilityToolbar open={accessibilityOpen} setOpen={setAccessibilityOpen} />
  </>;
}

function Footer({ go }: { go: (view: View) => void }) {
   const links: { label: string; view: View }[] = [{ label: "Agla Kadam", view: "agla-kadam" }, { label: "For candidates", view: "candidates" }, { label: "For employers", view: "employers" }, { label: "Skill Gap Bridge", view: "skill-gap" }, { label: "Accessibility Passport", view: "passport" }, { label: "Proof of Work", view: "proof" }, { label: "Practical Hubs", view: "hubs" }, { label: "Impact", view: "impact" }];
  return <footer className="site-footer"><div className="container"><div className="footer-top"><div className="footer-brand"><Logo /><p>Verified Inclusive<br />Employment Ecosystem</p><div className="footer-socials"><button aria-label="LinkedIn"><span>LinkedIn</span></button><button aria-label="Instagram"><span>Instagram</span></button><button aria-label="YouTube"><span>YouTube</span></button></div></div><div className="footer-links"><div><h3>Explore</h3>{links.map((link) => <button key={link.label} onClick={() => go(link.view)}>{link.label}</button>)}</div><div><h3>Support</h3><button onClick={() => go("contact")}>Accessibility support</button><button onClick={() => go("resources")}>Help centre</button><button onClick={() => go("contact")}>Report an issue</button><button onClick={() => go("about")}>About Enable Bharat</button></div><div><h3>For organisations</h3><button onClick={() => go("employers")}>Become an employer</button><button onClick={() => go("hubs")}>Partner with us</button><button onClick={() => go("assessor-dashboard")}>Assessor workspace</button><button onClick={() => go("admin-dashboard")}>Platform overview</button></div></div></div><div className="footer-bottom"><span>© 2025 Enable Bharat. All rights reserved.</span><div><button onClick={() => go("about")}>Privacy policy</button><button onClick={() => go("about")}>Terms</button><button onClick={() => go("about")}>Accessibility statement</button><button onClick={() => go("about")}>Consent settings</button></div></div></div></footer>;
}

function AglaVideoPoster({ video, playing, onToggle }: { video: typeof aglaVideos[number]; playing: boolean; onToggle: () => void }) {
  return <button className={`agla-video-poster agla-poster-${video.tone} ${playing ? "is-playing" : ""}`} onClick={onToggle} aria-label={`${playing ? "Pause" : "Play"} ${video.title}`}>
    <span className="poster-grid" aria-hidden="true" />
    <span className="poster-mark">{video.initials}</span>
    <span className="poster-copy"><small>AGLA KADAM / {video.category.toUpperCase()}</small><strong>{video.title}</strong></span>
    <span className="poster-play"><Icon name={playing ? "pause" : "play"} size={21} /></span>
    <span className="poster-duration">{video.duration}</span>
    {playing && <span className="poster-caption">{video.transcript.split(".")[0]}.</span>}
    {playing && <span className="poster-live">Playing demo preview</span>}
  </button>;
}

function AglaVideoCard({ video, go }: { video: typeof aglaVideos[number]; go: (view: View) => void }) {
  const [playing, setPlaying] = useState(false);
  const [liked, setLiked] = useState(false);
  const [saved, setSaved] = useState(false);
  const [followed, setFollowed] = useState(false);
  const [transcriptOpen, setTranscriptOpen] = useState(false);
  const [shared, setShared] = useState(false);
  const [reported, setReported] = useState(false);
  const [comment, setComment] = useState("");
  const [comments, setComments] = useState<string[]>([]);

  return <article className="agla-video-card">
    <AglaVideoPoster video={video} playing={playing} onToggle={() => setPlaying(!playing)} />
    <div className="agla-video-content">
      <div className="agla-video-heading"><div><Badge tone="verified" icon="check">{video.creatorType.split(" · ")[0]}</Badge><h2>{video.title}</h2></div><button className={`agla-follow ${followed ? "active" : ""}`} onClick={() => setFollowed(!followed)} aria-pressed={followed}>{followed ? "Following" : "Follow"}</button></div>
      <div className="agla-creator"><span className="creator-avatar">{video.initials}</span><span><strong>{video.creator}</strong><small>{video.views} · {video.creatorType}</small></span></div>
      <div className="agla-tags">{video.tags.map((tag) => <span key={tag}>{tag}</span>)}</div>
      <div className="agla-access-row"><span><Icon name="check" size={14} />Captions</span><span><Icon name="file" size={14} />Transcript</span><span><Icon name="accessibility" size={14} />Readable format</span></div>
      {transcriptOpen && <div className="agla-transcript"><strong>Transcript</strong><p>{video.transcript}</p></div>}
      <div className="agla-card-actions">
        <button className={liked ? "selected" : ""} onClick={() => setLiked(!liked)} aria-pressed={liked}><Icon name="heart" size={17} />{liked ? "Liked" : "Like"} <small>{liked ? "48" : "47"}</small></button>
        <button className={saved ? "selected" : ""} onClick={() => setSaved(!saved)} aria-pressed={saved}><Icon name="bookmark" size={17} />{saved ? "Saved" : "Save"}</button>
        <button onClick={() => setShared(!shared)} aria-pressed={shared}><Icon name="share" size={17} />{shared ? "Link copied" : "Share"}</button>
        <button onClick={() => setReported(true)}><Icon name="flag" size={17} />Report</button>
      </div>
      <div className="agla-action-row"><Button variant="orange" onClick={() => go(video.destination)} icon="arrow">{video.action}</Button><button className="transcript-toggle" onClick={() => setTranscriptOpen(!transcriptOpen)} aria-expanded={transcriptOpen}>{transcriptOpen ? "Hide transcript" : "Read transcript"} <Icon name="chevron" size={14} /></button></div>
      <div className="agla-comment-box"><label htmlFor={`comment-${video.id}`}>Join the conversation</label><div className="agla-comment-input"><VoiceField id={`comment-${video.id}`} value={comment} onChange={setComment} placeholder="Share a useful thought" ariaLabel={`Comment on ${video.title}`} multiline /><button onClick={() => { if (comment.trim()) { setComments([...comments, comment.trim()]); setComment(""); } }} aria-label="Post comment"><Icon name="send" size={16} /></button></div>{comments.length > 0 && <div className="agla-comments" aria-live="polite">{comments.map((item, index) => <p key={`${item}-${index}`}><strong>You</strong>{item}</p>)}</div>}</div>
      {reported && <div className="agla-reported" role="status"><Icon name="check" size={15} />Thanks. This report is saved locally for review.</div>}
    </div>
  </article>;
}

function AglaKadamPage({ go }: { go: (view: View) => void }) {
  const [category, setCategory] = useState("All");
  const [query, setQuery] = useState("");
  const [featuredPlaying, setFeaturedPlaying] = useState(false);
  const filtered = aglaVideos.filter((video) => (category === "All" || video.category === category) && (!query || `${video.title} ${video.creator} ${video.tags.join(" ")}`.toLowerCase().includes(query.toLowerCase())));
  return <main id="main-content" className="agla-page">
     <section className="agla-hero"><div className="container agla-hero-grid"><div><Badge tone="orange" icon="play">AGLA KADAM</Badge><p className="eyebrow">YOUR NEXT STEP TOWARD OPPORTUNITY</p><h1>Watch. Learn.<br /><span>Take your next step.</span></h1><p>Useful, verified and accessible short videos about careers, skills, jobs and the people making work more inclusive.</p><div className="agla-loop"><span>Watch</span><Icon name="arrow" size={14} /><span>Learn</span><Icon name="arrow" size={14} /><span>Act</span><Icon name="arrow" size={14} /><span>Grow</span></div></div><div className="agla-hero-card"><div className="agla-hero-card-top"><span>FEATURED TODAY</span><Badge tone="verified" icon="check">Admin verified</Badge></div><AglaVideoPoster video={aglaVideos[0]} playing={featuredPlaying} onToggle={() => setFeaturedPlaying(!featuredPlaying)} /><div className="agla-hero-card-foot"><strong>Every useful video leads somewhere.</strong><span>Check your skill gap, learn what matters and move forward with context.</span></div></div></div></section>
    <section className="agla-feed-section section-padding"><div className="container"><div className="agla-feed-toolbar"><div><p className="eyebrow">EXPLORE THE FEED</p><h2>Small videos. Clear actions.</h2><p>Short-form guidance connected to the Enable Bharat journey.</p></div><div className="agla-search"><Icon name="search" size={18} /><input value={query} onChange={(event) => setQuery(event.target.value)} placeholder="Search videos, skills or roles" aria-label="Search Agla Kadam videos" /></div></div><div className="agla-category-scroll" role="tablist" aria-label="Browse Agla Kadam categories">{aglaCategories.map((item) => <button key={item} role="tab" aria-selected={category === item} className={category === item ? "active" : ""} onClick={() => setCategory(item)}>{item}</button>)}</div>{filtered.length > 0 ? <div className="agla-feed-grid">{filtered.map((video) => <AglaVideoCard key={video.id} video={video} go={go} />)}</div> : <div className="empty-state agla-empty"><Icon name="search" size={28} /><h3>No videos found yet</h3><p>Try another role, skill or category.</p><Button variant="secondary" onClick={() => { setQuery(""); setCategory("All"); }}>Clear search</Button></div>}</div></section>
    <section className="agla-trust-band"><div className="container agla-trust-grid"><div><Icon name="shield" size={23} /><div><strong>Verified creators</strong><span>Admin, employer and candidate badges make context clear.</span></div></div><div><Icon name="accessibility" size={23} /><div><strong>Access built in</strong><span>Captions, transcripts, readable layouts and keyboard-friendly controls.</span></div></div><div><Icon name="target" size={23} /><div><strong>Action, not distraction</strong><span>Each story points to a next step in your employment journey.</span></div></div></div></section>
  </main>;
}

function HomePage({ go }: { go: (view: View) => void }) {
  return <main id="main-content">
    <section className="hero-section"><div className="container hero-grid"><div className="hero-copy"><div className="pilot-pill"><span className="live-dot" /> Built for India · Pilot in Gujarat</div><p className="eyebrow">VERIFIED INCLUSIVE EMPLOYMENT ECOSYSTEM</p><h1>From skills to employment <span>— with proof.</span></h1><p className="hero-description">Enable Bharat connects Persons with Disabilities to inclusive employment through verification, personalized skill-gap training, practical proof of work and trusted employer matching.</p><div className="hero-actions"><Button variant="orange" onClick={() => go("jobs")} icon="arrow">Find opportunities</Button><Button variant="secondary" onClick={() => go("employers")} icon="briefcase">Hire inclusively</Button></div><button className="text-cta" onClick={() => go("register")}>I’m a candidate <Icon name="arrow" size={16} /></button><div className="hero-proof"><div className="avatar-stack"><span>R</span><span>A</span><span>M</span><span>+</span></div><div><strong>500+ paths designed around capability</strong><small>Trusted by candidates, partners & employers</small></div></div></div><HeroProductVisual go={go} /></div></section>
    <section className="trust-band"><div className="container trust-band-inner"><div><Icon name="shield" size={22} /><span><strong>Trust by design</strong><small>Workplace-relevant data only</small></span></div><div><Icon name="accessibility" size={22} /><span><strong>Access built in</strong><small>Formats that adapt to you</small></span></div><div><Icon name="target" size={22} /><span><strong>Proof over promises</strong><small>Practical tasks, real evidence</small></span></div><div><Icon name="users" size={22} /><span><strong>Human support</strong><small>Partners close to home</small></span></div></div></section>
    <JourneySection go={go} />
    <ProblemSection />
    <SolutionSection go={go} />
     <MarketplacePreview go={go} />
     <AglaPreview go={go} />
    <ImpactPreview go={go} />
    <PilotRoadmap />
    <FinalCta go={go} />
  </main>;
}

function HeroProductVisual({ go }: { go: (view: View) => void }) {
  return <div className="hero-product"><div className="hero-glow" /><div className="product-window"><div className="product-window-top"><div className="window-dots"><i /><i /><i /></div><span>candidate / journey</span><Icon name="grid" size={15} /></div><div className="product-window-body"><div className="product-sidebar"><div className="mini-mark">EB</div><span className="active"><Icon name="home" size={14} /></span><span><Icon name="user" size={14} /></span><span><Icon name="book" size={14} /></span><span><Icon name="briefcase" size={14} /></span></div><div className="product-content"><div className="product-heading"><div><span className="tiny-label">GOOD MORNING, RAVI</span><h3>Your capability, made visible.</h3></div><div className="mini-avatar">RM</div></div><div className="mini-stats"><div><small>Profile completion</small><strong>92%</strong><ProgressBar value={92} tone="green" /></div><div><small>Role match</small><strong>94%</strong><ProgressBar value={94} tone="orange" /></div></div><div className="passport-preview"><div className="passport-icon"><Icon name="shield" size={18} /></div><div><strong>Accessibility Passport</strong><small>Identity & skills verified</small></div><Badge tone="verified" icon="check">Verified</Badge></div><div className="journey-mini"><div className="journey-mini-top"><span>EMPLOYMENT JOURNEY</span><button onClick={() => go("candidate-dashboard")}>View journey <Icon name="arrow" size={12} /></button></div><div className="mini-steps">{["Verify", "Assess", "Learn", "Prove", "Match"].map((step, index) => <div key={step} className={`mini-step ${index < 3 ? "done" : index === 3 ? "current" : ""}`}><span>{index < 3 ? <Icon name="check" size={11} /> : index + 1}</span><small>{step}</small></div>)}</div></div><div className="product-job"><div className="company-avatar">AR</div><div><span>RECOMMENDED FOR YOU</span><strong>Store Associate · Aarohan Retail</strong><small>94% skill match · Ahmedabad</small></div><button onClick={() => go("job-detail")} aria-label="View recommended job"><Icon name="arrow" size={17} /></button></div></div></div></div><div className="floating-verified"><span><Icon name="check" size={13} /></span><div><strong>Profile verified</strong><small>2 min ago</small></div></div><div className="floating-proof"><Icon name="spark" size={18} /><div><strong>Skill proven</strong><small>Spreadsheet task · 92%</small></div></div></div>;
}

function JourneySection({ go }: { go: (view: View) => void }) {
  return <section className="journey-section section-padding"><div className="container"><SectionHeader eyebrow="THE ENABLE BHARAT MODEL" title="A better employment journey" description="Most platforms stop at a vacancy. We stay with a person from their first verification to their first day at work." align="center" /><div className="journey-track">{journey.map((item, index) => <div className="journey-item" key={item.title}><div className={`journey-node journey-${item.tone}`}><span>{item.no}</span><Icon name={item.icon} size={20} /></div><h3>{item.title}</h3><p>{item.text}</p>{index < journey.length - 1 && <span className="journey-connector" aria-hidden="true" />}</div>)}</div><div className="journey-footer"><span><span className="orange-line" /> A continuous pathway, not a disconnected checklist</span><button className="text-cta" onClick={() => go("how")}>See how it works <Icon name="arrow" size={16} /></button></div></div></section>;
}

function ProblemSection() {
  const problems = [{ number: "01", title: "Trust is hard to establish", text: "Candidates repeat their story. Employers cannot tell what has really been verified." }, { number: "02", title: "Training floats away from work", text: "Generic courses take time without answering what a specific role actually needs." }, { number: "03", title: "Accommodation stays unclear", text: "The right support gets lost between a candidate, a partner and a workplace." }, { number: "04", title: "Certificates do not show capability", text: "A multiple-choice score can never replace doing the task a job requires." }];
  return <section className="problem-section section-padding"><div className="container problem-grid"><div className="problem-copy"><p className="eyebrow">WHY THIS MATTERS</p><h2>The problem isn’t ability.<br /><span>It’s the broken journey.</span></h2><p>India has capable people, committed employers and strong community partners. What is missing is the connective layer that turns potential into workplace confidence.</p><div className="problem-callout"><Icon name="spark" size={18} /><strong>When skills, accessibility, verification and employer trust connect, employment becomes possible.</strong></div></div><div className="problem-cards">{problems.map((problem) => <article className="problem-card" key={problem.number}><span>{problem.number}</span><h3>{problem.title}</h3><p>{problem.text}</p></article>)}</div></div></section>;
}

function SolutionSection({ go }: { go: (view: View) => void }) {
  const pillars = [{ no: "01", icon: "shield" as IconName, title: "Accessibility Passport", text: "A reusable, privacy-led view of capabilities, preferences and support that helps people work well.", link: "passport" as View }, { no: "02", icon: "target" as IconName, title: "Skill Gap Bridge", text: "Compare capability to a real role and learn only the minimum missing skills.", link: "skill-gap" as View }, { no: "03", icon: "book" as IconName, title: "Accessible Learning", text: "Captions, audio narration, ISL, large text and pictorial guidance in one place.", link: "candidate-learning" as View }, { no: "04", icon: "spark" as IconName, title: "Proof of Work", text: "Show employers how you do the task — not just what a certificate says.", link: "proof" as View }, { no: "05", icon: "briefcase" as IconName, title: "Inclusive Job Matching", text: "Find verified employers and roles ranked by skills, support and fit.", link: "jobs" as View }];
  return <section className="solution-section section-padding"><div className="container"><div className="solution-heading"><SectionHeader eyebrow="THE SOLUTION" title="One ecosystem. Every step." description="A trusted operating layer for candidates, employers, NGOs, assessors and skill partners." /><Button variant="secondary" onClick={() => go("how")} icon="arrow">Explore the ecosystem</Button></div><div className="pillar-grid">{pillars.map((pillar, index) => <button className={`pillar-card pillar-${index + 1}`} key={pillar.no} onClick={() => go(pillar.link)}><div className="pillar-top"><span className="pillar-number">{pillar.no}</span><span className="pillar-icon"><Icon name={pillar.icon} size={21} /></span></div><h3>{pillar.title}</h3><p>{pillar.text}</p><span className="card-link">Explore <Icon name="arrow" size={14} /></span></button>)}</div></div></section>;
}

function MarketplacePreview({ go }: { go: (view: View) => void }) {
  return <section className="marketplace-preview section-padding"><div className="container"><div className="marketplace-heading"><SectionHeader eyebrow="OPPORTUNITY, WITH CONTEXT" title="Find work that fits you" description="Every role carries more than a title: a skill match, an accessibility view and a clear next step." /><button className="text-cta" onClick={() => go("jobs")}>Browse all opportunities <Icon name="arrow" size={16} /></button></div><div className="job-preview-grid">{jobs.slice(0, 3).map((job) => <JobCard key={job.id} job={job} go={go} />)}</div></div></section>;
}

function AglaPreview({ go }: { go: (view: View) => void }) {
  return <section className="agla-preview section-padding"><div className="container agla-preview-inner"><div><Badge tone="orange" icon="play">AGLA KADAM</Badge><p className="eyebrow">YOUR NEXT STEP TOWARD OPPORTUNITY</p><h2>Useful stories for the step you are ready to take.</h2><p>Watch verified short videos about skills, work and opportunity — then move directly into the Enable Bharat journey.</p><Button variant="orange" onClick={() => go("agla-kadam")} icon="arrow">Explore Agla Kadam</Button></div><div className="agla-preview-stack">{aglaVideos.slice(0, 3).map((video, index) => <div className={`agla-preview-tile tile-${index}`} key={video.id}><span className={`preview-tile-mark ${video.tone}`}>{video.initials}</span><div><small>{video.category}</small><strong>{video.title}</strong></div><Icon name="play" size={15} /></div>)}</div></div></section>;
}

function JobCard({ job, go, compact = false }: { job: typeof jobs[number]; go: (view: View) => void; compact?: boolean }) {
  return <article className={`job-card ${compact ? "job-card-compact" : ""}`}><div className="job-card-head"><div className="company-logo" style={{ background: job.color }}>{job.logo}</div><div><Badge tone="verified" icon="check">Verified employer</Badge><h3>{job.title}</h3><p>{job.company}</p></div><button className="more-button" aria-label="More job actions"><span>•••</span></button></div><div className="job-meta"><span><Icon name="location" size={15} />{job.location}</span><span><Icon name="briefcase" size={15} />{job.mode}</span><span><Icon name="clock" size={15} />{job.type}</span></div><div className="job-match"><div><small>YOUR SKILL MATCH</small><strong>{job.match}%</strong></div><div className="match-ring" style={{ "--match": `${job.match * 3.6}deg` } as React.CSSProperties}><span>{job.match}%</span></div></div><div className="job-features">{job.features.slice(0, compact ? 2 : 3).map((feature) => <span key={feature}><Icon name="check" size={13} />{feature}</span>)}</div><div className="job-footer"><strong>{job.salary}</strong><Button variant="secondary" onClick={() => go("job-detail")}>View job <Icon name="arrow" size={15} /></Button></div></article>;
}

function ImpactPreview({ go }: { go: (view: View) => void }) {
  const metrics = [{ value: "500", label: "PwD candidates", icon: "users" as IconName }, { value: "50", label: "inclusive employers", icon: "building" as IconName }, { value: "10", label: "NGO / skill partners", icon: "layers" as IconName }, { value: "2–3", label: "initial job roles", icon: "briefcase" as IconName }];
  return <section className="impact-preview section-padding"><div className="container impact-preview-inner"><div className="impact-copy"><p className="eyebrow eyebrow-light">MEASURE WHAT MOVES PEOPLE FORWARD</p><h2>Impact is a journey,<br /><span>not a registration count.</span></h2><p>We track the movement from registered → skill gap closed → skill proven → interviewed → employed — and what happens after day one.</p><Button variant="orange" onClick={() => go("impact")} icon="arrow">See our impact dashboard</Button></div><div className="impact-metrics">{metrics.map((metric, index) => <div className="impact-metric" key={metric.label}><span className="metric-icon"><Icon name={metric.icon} size={19} /></span><strong>{metric.value}{index < 3 && "+"}</strong><span>{metric.label}</span></div>)}</div></div></section>;
}

function PilotRoadmap() {
  const roadmap = [{ days: "DAYS 1–30", title: "MVP foundation", items: ["Registration & verification", "Accessibility Passport", "Role-based dashboards", "Initial skill-gap engine"] }, { days: "DAYS 31–60", title: "Skill gap + proof", items: ["Accessible learning modules", "Practical hubs", "Assessor workflows", "Employer matching"] }, { days: "DAYS 61–90", title: "Pilot in motion", items: ["Candidates & employers", "Real practical assessments", "NGO partner enablement", "Placement measurement"] }];
  return <section className="roadmap-section section-padding"><div className="container"><SectionHeader eyebrow="A 90-DAY PILOT" title="Build trust. Test the pathway. Measure the outcome." description="A focused rollout designed to learn with the people and organisations closest to the work." align="center" /><div className="roadmap-grid">{roadmap.map((step, index) => <article className={`roadmap-card ${index === 1 ? "featured" : ""}`} key={step.days}><div className="roadmap-number">0{index + 1}</div><p className="eyebrow">{step.days}</p><h3>{step.title}</h3><ul>{step.items.map((item) => <li key={item}><Icon name="check" size={15} />{item}</li>)}</ul></article>)}</div></div></section>;
}

function FinalCta({ go }: { go: (view: View) => void }) {
  return <section className="final-cta section-padding"><div className="container final-cta-inner"><div className="cta-symbol"><span>EB</span><i /><i /><i /></div><div><p className="eyebrow eyebrow-light">THE NEXT STEP IS YOURS</p><h2>Employment should begin<br />with <span>capability.</span></h2><p>Let’s build a workforce where accessibility, skills and opportunity connect.</p></div><div className="final-cta-actions"><Button variant="orange" onClick={() => go("jobs")} icon="arrow">Find opportunities</Button><Button variant="secondary" onClick={() => go("employers")} icon="briefcase">Hire inclusively</Button><button className="light-text-link" onClick={() => go("contact")}>Partner with Enable Bharat <Icon name="arrow" size={15} /></button></div></div></section>;
}

function PublicPageLayout({ title, eyebrow, description, children, go, dark = false }: { title: string; eyebrow: string; description: string; children: React.ReactNode; go: (view: View) => void; dark?: boolean }) {
  return <main id="main-content"><section className={`page-hero ${dark ? "page-hero-dark" : ""}`}><div className="container page-hero-inner"><p className="eyebrow">{eyebrow}</p><h1>{title}</h1><p>{description}</p></div></section>{children}</main>;
}

function HowItWorksPage({ go }: { go: (view: View) => void }) {
  return <PublicPageLayout eyebrow="THE CONTINUOUS JOURNEY" title="A clearer path from potential to employment." description="Enable Bharat gives every person and organisation the context to take the next right step — together." go={go}><JourneySection go={go} /><section className="deep-dive section-padding"><div className="container"><SectionHeader eyebrow="HOW IT CONNECTS" title="The system gets smarter at every step." description="Verification creates trust. Assessment creates clarity. Proof creates confidence. Matching creates movement." align="center" /><div className="deep-dive-list">{[{ title: "A verified starting point", text: "Identity, documents and profile signals are checked with consent. Employers see what helps them support success — never more than they need.", icon: "shield" as IconName }, { title: "Capability before credentials", text: "A candidate’s digital, communication and task-based strengths become visible through accessible assessment and a reusable Passport.", icon: "target" as IconName }, { title: "Learning with a destination", text: "Skill-gap recommendations connect to real job roles, micro-learning, and practical assessments at nearby hubs.", icon: "book" as IconName }, { title: "Evidence employers can act on", text: "Proof-of-work shows what has been demonstrated. Employers can make better matches and plan accommodations early.", icon: "spark" as IconName }].map((item, index) => <div className="deep-dive-row" key={item.title}><span className="deep-dive-index">0{index + 1}</span><span className="deep-dive-icon"><Icon name={item.icon} size={22} /></span><div><h3>{item.title}</h3><p>{item.text}</p></div><Icon name="arrow" size={19} /></div>)}</div></div></section><FinalCta go={go} /></PublicPageLayout>;
}

function JobsPage({ go }: { go: (view: View) => void }) {
  const [query, setQuery] = useState("");
  const [mode, setMode] = useState("All work modes");
  const [verifiedOnly, setVerifiedOnly] = useState(false);
  const filteredJobs = useMemo(() => jobs.filter((job) => (!query || `${job.title} ${job.company} ${job.location}`.toLowerCase().includes(query.toLowerCase())) && (mode === "All work modes" || job.mode === mode) && (!verifiedOnly || job.verified)), [mode, query, verifiedOnly]);
  return <PublicPageLayout eyebrow="THE OPPORTUNITY MARKETPLACE" title="Find work that fits you." description="Explore roles with the context you need to decide: match strength, workplace support and a practical next step." go={go}><section className="jobs-page section-padding"><div className="container"><div className="jobs-search"><div className="search-field"><Icon name="search" size={19} /><input value={query} onChange={(event) => setQuery(event.target.value)} placeholder="Job title, skill or company" aria-label="Search jobs" /></div><div className="select-field"><Icon name="location" size={18} /><select aria-label="Location"><option>All locations</option><option>Ahmedabad</option><option>Vadodara</option><option>Surat</option><option>Remote · India</option></select></div><Button variant="orange" onClick={() => undefined} icon="search">Search jobs</Button></div><div className="filter-row"><div className="filter-label"><Icon name="filter" size={17} /><strong>Filter by</strong></div>{["All work modes", "Remote", "Hybrid", "On-site"].map((filter) => <button key={filter} className={`filter-chip ${mode === filter ? "active" : ""}`} onClick={() => setMode(filter)}>{filter}</button>)}<button className={`filter-chip ${verifiedOnly ? "active" : ""}`} onClick={() => setVerifiedOnly(!verifiedOnly)}><Icon name="shield" size={14} />Verified employer</button><button className="filter-chip">Accessibility support</button><button className="filter-chip">Entry level</button><span className="results-count">{filteredJobs.length} opportunities</span></div><div className="jobs-layout"><aside className="jobs-side-filter"><div className="side-filter-head"><strong>Refine results</strong><button aria-label="Reset filters" onClick={() => { setMode("All work modes"); setVerifiedOnly(false); setQuery(""); }}>Reset</button></div><label>Employment type</label>{["Full time", "Part time", "Contract"].map((item) => <span className="checkbox-row" key={item}><input type="checkbox" defaultChecked={item === "Full time"} />{item}<small>{item === "Full time" ? 18 : item === "Part time" ? 7 : 4}</small></span>)}<label>Support available</label>{["Accessible workplace", "Flexible schedule", "Assistive technology", "Transport support"].map((item) => <span className="checkbox-row" key={item}><input type="checkbox" />{item}</span>)}<div className="filter-help"><Icon name="help" size={16} /><span>Not sure what support you need? <button onClick={() => go("contact")}>Talk to a guide</button></span></div></aside><div className="jobs-list"><div className="list-heading"><div><span className="eyebrow">MATCHED TO YOUR CAPABILITY</span><h2>{query ? `Results for “${query}”` : "Opportunities with a clearer fit"}</h2></div><select aria-label="Sort jobs"><option>Best match</option><option>Newest first</option><option>Salary: high to low</option></select></div>{filteredJobs.length ? filteredJobs.map((job) => <JobCard key={job.id} job={job} go={go} />) : <div className="empty-state"><Icon name="search" size={28} /><h3>No roles found yet</h3><p>Try a wider search. We add new opportunities every week.</p><Button variant="secondary" onClick={() => { setQuery(""); setMode("All work modes"); }}>Clear filters</Button></div>}</div></div></div></section><section className="jobs-trust"><div className="container jobs-trust-inner"><Icon name="shield" size={23} /><div><strong>Your job search, with more confidence.</strong><span>Every employer on this page has committed to inclusive hiring practices and a clear support conversation.</span></div><button onClick={() => go("employers")}>Our employer standard <Icon name="arrow" size={15} /></button></div></section></PublicPageLayout>;
}

function JobDetailPage({ go }: { go: (view: View) => void }) {
  const job = jobs[0];
  const [applied, setApplied] = useState(false);
  return <main id="main-content"><section className="job-detail-hero"><div className="container"><button className="back-link" onClick={() => go("jobs")}><Icon name="arrow" size={15} />Back to opportunities</button><div className="job-detail-heading"><div className="company-logo large" style={{ background: job.color }}>{job.logo}</div><div><Badge tone="verified" icon="check">Verified employer</Badge><h1>{job.title}</h1><p>{job.company} · Ahmedabad, Gujarat</p></div><div className="detail-match"><span>Your match</span><strong>{job.match}%</strong><small>Strong fit</small></div></div><div className="detail-meta-row"><span><Icon name="location" size={17} />Ahmedabad · Hybrid</span><span><Icon name="briefcase" size={17} />Full time</span><span><Icon name="clock" size={17} />Posted 4 days ago</span><strong>{job.salary}</strong></div></div></section><section className="job-detail-content section-padding"><div className="container detail-grid"><div className="detail-main"><div className="detail-section"><h2>About the role</h2><p>As a Customer Support Executive at Aarohan Retail, you will be the friendly first point of contact for customers across our retail network. You’ll help resolve questions, manage simple requests and make every interaction feel easy.</p><p>This is a structured, team-based role with clear workflows, a supportive manager and a flexible hybrid schedule. We care about how you work best and will discuss practical accommodations before you start.</p></div><div className="detail-section"><h2>What you’ll do</h2><ul className="feature-list"><li><Icon name="check" size={16} />Respond to customer questions over phone, chat and email</li><li><Icon name="check" size={16} />Record interactions clearly in our customer system</li><li><Icon name="check" size={16} />Work with the store team to close the loop</li><li><Icon name="check" size={16} />Learn from weekly coaching and feedback</li></ul></div><div className="detail-section"><h2>Accessibility at Aarohan Retail</h2><div className="access-feature-grid">{["Accessible workplace", "Flexible work schedule", "Assistive technology support", "Structured onboarding"].map((feature) => <div key={feature}><span><Icon name="check" size={15} /></span><strong>{feature}</strong><p>Discussed in your support conversation</p></div>)}</div></div><div className="detail-section"><h2>Required skills</h2><div className="skill-pills"><span>Communication</span><span>Computer basics</span><span>Customer interaction</span><span>Gujarati / Hindi preferred</span></div></div></div><aside className="detail-side"><div className="match-card"><div className="match-card-head"><div><p className="eyebrow">YOUR SKILL MATCH</p><h2>87% match</h2></div><div className="match-ring large-ring"><span>87%</span></div></div><p>Your strengths make this role a strong starting point. Bridge two skills to feel fully ready.</p><div className="match-strengths"><strong><Icon name="check" size={15} />Communication</strong><strong><Icon name="check" size={15} />Computer basics</strong><strong><Icon name="check" size={15} />Customer interaction</strong><span><Icon name="arrow" size={15} />CRM software</span><span><Icon name="arrow" size={15} />Email workflow</span></div><Button variant="orange" className="full-button" onClick={() => go("skill-gap")} icon="arrow">Bridge skill gap & apply</Button></div><div className="apply-card"><h3>Ready to take the next step?</h3><p>Applying starts a conversation. It does not share your private documents.</p><Button variant={applied ? "success" : "primary"} className="full-button" onClick={() => setApplied(true)} icon={applied ? "check" : "arrow"}>{applied ? "Application started" : "Apply for this role"}</Button><button className="save-job"><Icon name="share" size={16} />Share this role</button></div></aside></div></section></main>;
}

function CandidatesPage({ go }: { go: (view: View) => void }) {
  return <PublicPageLayout eyebrow="FOR CANDIDATES" title="Your capability deserves a clearer path." description="Build a profile around what you can do, learn what matters, prove it in practice and find a workplace ready to support you." go={go} dark><section className="candidate-value section-padding"><div className="container"><div className="candidate-value-grid"><div className="candidate-story"><p className="eyebrow">A STARTING POINT THAT RESPECTS YOU</p><h2>You don’t have to start from zero.</h2><p>Enable Bharat helps you carry your strengths forward. Your Accessibility Passport turns your preferences and proven capabilities into a profile employers can understand.</p><Button variant="orange" onClick={() => go("register")} icon="arrow">Create your free profile</Button><button className="text-cta" onClick={() => go("passport")}>See an example Passport <Icon name="arrow" size={16} /></button></div><div className="candidate-steps">{[{ n: "01", t: "Build your Passport", d: "Tell us how you work best. Choose what you share." }, { n: "02", t: "See your skill gap", d: "Pick a role and get a focused, personal pathway." }, { n: "03", t: "Prove your skills", d: "Complete a practical task with a trained assessor." }, { n: "04", t: "Find your fit", d: "Meet employers who are ready to hire inclusively." }].map((item) => <div key={item.n}><span>{item.n}</span><div><h3>{item.t}</h3><p>{item.d}</p></div><Icon name="check" size={17} /></div>)}</div></div></div></section><section className="candidate-quote section-padding"><div className="container quote-inner"><div className="quote-mark">“</div><blockquote>When my skills were shown clearly, the conversation changed from what I need to <em>can I do the work?</em> to how can we help me do it well?</blockquote><span>— A pilot candidate, Vadodara</span></div></section><FinalCta go={go} /></PublicPageLayout>;
}

function EmployersPage({ go }: { go: (view: View) => void }) {
  const values = [{ icon: "shield" as IconName, title: "Verified candidates", text: "Start with profiles grounded in consent and clear verification signals." }, { icon: "target" as IconName, title: "Skill-based matching", text: "See the real strengths behind every match, not just a keyword score." }, { icon: "spark" as IconName, title: "Proof-of-work", text: "Make confident decisions with practical evidence for the role." }, { icon: "accessibility" as IconName, title: "Accommodation insights", text: "Plan a successful first day with relevant workplace context." }];
  return <PublicPageLayout eyebrow="FOR EMPLOYERS" title="Hire capability. Build inclusion." description="Discover verified, job-ready candidates matched to the skills your business actually needs." go={go} dark><section className="employer-overview section-padding"><div className="container"><div className="employer-hero-grid"><div><p className="eyebrow">A BETTER WAY TO HIRE</p><h2>Inclusion becomes practical when the signal is clear.</h2><p>Enable Bharat helps your team move from good intent to a repeatable, skill-first hiring process — with less guesswork for everyone.</p><div className="hero-actions"><Button variant="orange" onClick={() => go("register")} icon="arrow">Become an inclusive employer</Button><Button variant="secondary" onClick={() => go("candidates")} icon="users">Explore candidates</Button></div></div><div className="employer-funnel"><div className="funnel-head"><span>HIRING PIPELINE</span><Badge tone="verified">This month</Badge></div>{[{ label: "Applicants", value: 184, width: 100, tone: "blue" }, { label: "Verified", value: 126, width: 78, tone: "blue" }, { label: "Matched", value: 58, width: 55, tone: "orange" }, { label: "Interviewed", value: 21, width: 36, tone: "orange" }, { label: "Hired", value: 8, width: 22, tone: "green" }].map((item) => <div className="funnel-row" key={item.label}><span>{item.label}</span><div><i className={`funnel-bar ${item.tone}`} style={{ width: `${item.width}%` }} /></div><strong>{item.value}</strong></div>)}<div className="funnel-note"><Icon name="spark" size={16} /><span><strong>+18%</strong> skill match rate this quarter</span></div></div></div><div className="employer-value-grid">{values.map((value) => <div className="employer-value" key={value.title}><span><Icon name={value.icon} size={20} /></span><h3>{value.title}</h3><p>{value.text}</p></div>)}</div></div></section><section className="employer-commitment section-padding"><div className="container commitment-grid"><div><p className="eyebrow">THE EMPLOYER STANDARD</p><h2>Inclusion is a way of working, not a checkbox.</h2><p>Every inclusive employer on Enable Bharat makes a simple commitment: make the role clear, discuss support openly, and measure the experience after the hire.</p><div className="commitment-list"><span><Icon name="check" size={15} />Accessible role descriptions</span><span><Icon name="check" size={15} />Prepared interview teams</span><span><Icon name="check" size={15} />90-day retention check-in</span></div></div><div className="commitment-card"><Badge tone="verified" icon="shield">Enable Bharat standard</Badge><h3>What your team gets</h3><div><span>Skill match rate</span><strong>+18%</strong></div><div><span>Average time to shortlist</span><strong>3.2 days</strong></div><div><span>Support conversations started</span><strong>94%</strong></div><Button variant="primary" onClick={() => go("employer-dashboard")} icon="arrow">See employer workspace</Button></div></div></section><FinalCta go={go} /></PublicPageLayout>;
}

function SkillGapPage({ go }: { go: (view: View) => void }) {
  const [role, setRole] = useState("Store Associate");
  const roleData: Record<string, { match: number; strengths: string[]; gaps: { title: string; modules: string; minutes: string }[] }> = { "Store Associate": { match: 78, strengths: ["Smartphone use", "Communication", "Customer interaction"], gaps: [{ title: "POS billing", modules: "4 modules", minutes: "68 min" }, { title: "Store hygiene", modules: "2 modules", minutes: "32 min" }] }, "Customer Support": { match: 87, strengths: ["Communication", "Computer basics", "Customer interaction"], gaps: [{ title: "CRM workflow", modules: "3 modules", minutes: "52 min" }, { title: "Email etiquette", modules: "2 modules", minutes: "28 min" }] }, "Data Entry Operator": { match: 91, strengths: ["Typing", "Spreadsheet skills", "Attention to detail"], gaps: [{ title: "Spreadsheet shortcuts", modules: "2 modules", minutes: "30 min" }, { title: "Data quality checks", modules: "2 modules", minutes: "36 min" }] } };
  const current = roleData[role];
  return <PublicPageLayout eyebrow="SKILL GAP BRIDGE" title="Don’t start from zero. Build from what you already know." description="Choose a target role and get the smallest, clearest pathway from today’s capability to job readiness." go={go}><section className="skill-gap-page section-padding"><div className="container"><div className="role-select-card"><div><p className="eyebrow">TRY THE ROLE MAPPER</p><h2>What role are you curious about?</h2><p>Change the role to see how the bridge adapts around existing strengths.</p></div><div className="role-select-wrap"><label htmlFor="target-role">Target role</label><select id="target-role" value={role} onChange={(event) => setRole(event.target.value)}>{Object.keys(roleData).map((item) => <option key={item}>{item}</option>)}</select></div></div><div className="gap-comparison"><div className="capability-panel"><div className="panel-eyebrow"><span>01</span><p>CANDIDATE CAPABILITY</p><Badge tone="verified" icon="check">Already strong</Badge></div><h3>What you bring with you</h3><ul>{current.strengths.map((strength) => <li key={strength}><Icon name="check" size={16} />{strength}</li>)}</ul><div className="capability-foot"><span>Based on your self-assessment</span><button onClick={() => go("register")}>Edit my skills <Icon name="arrow" size={14} /></button></div></div><div className="gap-connector"><span><Icon name="arrow" size={20} /></span><small>{100 - current.match}% to bridge</small></div><div className="target-panel"><div className="panel-eyebrow"><span>02</span><p>TARGET ROLE</p><Badge tone="orange">{role}</Badge></div><h3>What the role needs</h3><div className="target-requirement"><span>Required capability</span><strong>{current.match + 10}%</strong><ProgressBar value={current.match + 10} tone="navy" /></div><div className="target-list"><span><Icon name="check" size={15} />Customer interaction</span><span><Icon name="check" size={15} />Structured work</span><span><Icon name="arrow" size={15} />{current.gaps[0].title}</span><span><Icon name="arrow" size={15} />{current.gaps[1].title}</span></div></div></div><div className="gap-result"><div className="gap-result-score"><div className="match-ring big-ring"><span>{current.match}%</span></div><div><p className="eyebrow">CURRENT ROLE MATCH</p><h3>You are closer than you think.</h3><p>Your personalized bridge covers <strong>{current.gaps.length} skills</strong> — not an entire new course.</p></div></div><div className="gap-result-skills"><strong>SKILL GAP · {current.gaps.length} SKILLS</strong><div>{current.gaps.map((gap) => <span key={gap.title}><Icon name="arrow" size={14} />{gap.title}</span>)}</div></div></div><div className="personal-path"><div className="path-heading"><div><p className="eyebrow">YOUR PERSONALIZED PATH</p><h2>A short bridge to job-ready</h2></div><Button variant="orange" onClick={() => go("candidate-learning")} icon="arrow">Start skill gap bridge</Button></div><div className="path-grid">{current.gaps.map((gap, index) => <article key={gap.title}><div className="path-step">0{index + 1}</div><div><h3>{gap.title}</h3><p>{gap.modules} <span>·</span> {gap.minutes}</p></div><span className="path-status">{index === 0 ? "Start here" : "Next"}</span></article>)}<article className="path-assessment"><div className="path-step"><Icon name="spark" size={16} /></div><div><h3>Practical assessment</h3><p>Show the skill in context with an assessor</p></div><Badge tone="green">After learning</Badge></article></div></div></div></section><FinalCta go={go} /></PublicPageLayout>;
}

function PassportPage({ go, dashboard = false }: { go: (view: View) => void; dashboard?: boolean }) {
  const [shared, setShared] = useState(false);
  return <main id="main-content" className={dashboard ? "dashboard-view-area" : ""}><section className={dashboard ? "dashboard-page-header" : "page-hero passport-hero"}><div className="container page-hero-inner"><p className="eyebrow">{dashboard ? "MY PROFILE / ACCESSIBILITY PASSPORT" : "ACCESSIBILITY PASSPORT"}</p><h1>{dashboard ? "Your Passport, your privacy." : "Make the way you work visible."}</h1><p>{dashboard ? "You choose what employers see. We show only what helps a workplace support your success." : "A reusable, consent-led profile that captures capability, preferences and practical support — without exposing what is not relevant."}</p></div></section><section className="passport-page section-padding"><div className="container passport-layout"><div className="passport-document"><div className="passport-doc-top"><div><span className="passport-kicker">ENABLE BHARAT / CAPABILITY RECORD</span><h2>Accessibility Passport</h2></div><div className="passport-mini-mark">EB</div></div><div className="passport-person"><div className="profile-avatar">RM</div><div><h3>Ravi Mehta</h3><p>Customer Support Associate · Vadodara</p><div className="passport-badges"><Badge tone="verified" icon="check">Identity verified</Badge><Badge tone="verified" icon="check">Profile 92% complete</Badge></div></div></div><div className="passport-divider" /><div className="passport-block"><div className="passport-block-head"><h3>Work capabilities</h3><span>1 · developing &nbsp; 5 · strong</span></div><div className="capability-bars">{[{ l: "Communication", v: 4 }, { l: "Digital skills", v: 4 }, { l: "Problem solving", v: 4 }, { l: "Teamwork", v: 5 }].map((item) => <div key={item.l}><span>{item.l}</span><div className="dot-scale">{[1, 2, 3, 4, 5].map((dot) => <i className={dot <= item.v ? "filled" : ""} key={dot} />)}</div><small>{item.v}/5</small></div>)}</div></div><div className="passport-two-col"><div className="passport-block"><div className="passport-block-head"><h3>Work preferences</h3></div><p>Preferred roles</p><strong>Store Associate<br />Customer Support</strong><p>Environment</p><strong>Structured tasks<br />Accessible workplace</strong></div><div className="passport-block"><div className="passport-block-head"><h3>Support that helps</h3></div><p>Assistive technology</p><strong><Icon name="check" size={14} /> Screen reader</strong><p>Accommodation</p><strong><Icon name="check" size={14} /> Accessible workstation</strong></div></div><div className="passport-doc-foot"><span><Icon name="lock" size={14} /> Shared with consent · Updated 14 Aug 2025</span><span>EB–RM–2084</span></div></div><aside className="passport-sidebar"><div className="privacy-card"><span className="privacy-icon"><Icon name="lock" size={19} /></span><p className="eyebrow">PRIVACY, BY DEFAULT</p><h2>Relevant, not revealing.</h2><p>Employers see information relevant to successful workplace participation. Sensitive personal details stay private.</p><div className="privacy-points"><span><Icon name="check" size={14} />You choose what to share</span><span><Icon name="check" size={14} />Change access anytime</span><span><Icon name="check" size={14} />No documents in public URLs</span></div></div><div className="passport-actions"><Button variant="primary" onClick={() => setShared(true)} icon={shared ? "check" : "share"}>{shared ? "Share link copied" : "Share Passport"}</Button><Button variant="secondary" onClick={() => undefined} icon="download">Download Passport</Button><button className="edit-passport" onClick={() => go("candidate-settings")}><Icon name="settings" size={16} />Edit Passport & privacy</button></div></aside></div></section></main>;
}

function ProofPage({ go, dashboard = false }: { go: (view: View) => void; dashboard?: boolean }) {
  return <main id="main-content" className={dashboard ? "dashboard-view-area" : ""}><section className={dashboard ? "dashboard-page-header" : "page-hero proof-hero"}><div className="container page-hero-inner"><p className="eyebrow">PROOF OF WORK</p><h1>Skills are stronger when they are demonstrated.</h1><p>Practical tasks turn learning into evidence. Evidence turns a profile into a confident conversation.</p></div></section><section className="proof-page section-padding"><div className="container"><div className="proof-intro"><div><p className="eyebrow">YOUR PRACTICAL RECORD</p><h2>Show what you can do.</h2><p>These are not exams designed to catch you out. They are familiar workplace tasks, supported by an assessor and accessible by design.</p></div><Button variant="orange" onClick={() => go("candidate-assessments")} icon="arrow">View assessments</Button></div><div className="proof-grid"><div className="assessment-card"><div className="assessment-top"><Badge tone="verified" icon="check">Assessment complete</Badge><span>POW–2025–1842</span></div><h2>Data Entry Operator</h2><p>Spreadsheet accuracy task</p><div className="assessment-status"><div className="status-line"><span className="status-dot done"><Icon name="check" size={11} /></span><div><strong>Not started</strong><small>Profile created</small></div></div><div className="status-connector done" /><div className="status-line"><span className="status-dot done"><Icon name="check" size={11} /></span><div><strong>In progress</strong><small>Practice submitted</small></div></div><div className="status-connector done" /><div className="status-line"><span className="status-dot done"><Icon name="check" size={11} /></span><div><strong>Assessment complete</strong><small>Reviewed 12 Aug</small></div></div></div><div className="assessment-score"><div><span>RESULT</span><strong>JOB-READY</strong><small>Assessor confidence: high</small></div><div className="score-ring"><span>92<small>/100</small></span></div></div><div className="assessor-note"><div className="assessor-avatar">SK</div><p><strong>Shreya Kulkarni · Enable Bharat Assessor</strong><br />“Accurate, calm and consistent. Ravi used the shortcut guide independently.”</p></div></div><div className="certificate-card"><div className="certificate-paper"><div className="certificate-seal"><Icon name="shield" size={22} /><span>EB</span></div><span className="certificate-label">ENABLE BHARAT</span><h3>Proof-of-Work<br /><em>Certificate</em></h3><p>This certifies that</p><strong>Ravi Mehta</strong><p>has demonstrated job readiness for</p><b>Data Entry Operator</b><div className="certificate-score">92 <span>/ 100</span></div><small>Verified by Enable Bharat · 12 Aug 2025</small><div className="certificate-lines"><i /><i /><i /></div></div><Button variant="secondary" onClick={() => undefined} icon="download">Download certificate</Button></div></div><div className="proof-principles">{[{ icon: "clipboard" as IconName, title: "Task-based", text: "Spreadsheet tasks, POS transactions and workplace simulations." }, { icon: "accessibility" as IconName, title: "Accessible", text: "Extra time, assistive tools and instructions in your format." }, { icon: "users" as IconName, title: "Human-reviewed", text: "An assessor adds context a score alone never could." }].map((item) => <div key={item.title}><span><Icon name={item.icon} size={20} /></span><div><h3>{item.title}</h3><p>{item.text}</p></div></div>)}</div></div></section></main>;
}

function HubsPage({ go }: { go: (view: View) => void }) {
  const [city, setCity] = useState("Vadodara");
  const filtered = hubs.filter((hub) => city === "All cities" || hub.city === city);
  return <PublicPageLayout eyebrow="PRACTICAL HUBS" title="Practical training. Close to home." description="Use the spaces that already exist — ITIs, colleges, community halls and labs — to turn learning into local proof." go={go}><section className="hubs-page section-padding"><div className="container"><div className="hubs-search"><div><p className="eyebrow">FIND A HUB</p><h2>Where would you like to practice?</h2></div><div className="hub-search-input"><Icon name="search" size={18} /><select value={city} onChange={(event) => setCity(event.target.value)} aria-label="Choose hub city"><option>Vadodara</option><option>Ahmedabad</option><option>Surat</option><option>All cities</option></select></div></div><div className="hub-explorer"><div className="hub-map"><div className="map-grid" /><span className="map-pin pin-one">EB</span><span className="map-pin pin-two">+</span><span className="map-pin pin-three">+</span><div className="map-label"><Icon name="location" size={15} /><span>Gujarat pilot region</span></div></div><div className="hub-list">{filtered.map((hub) => <article className="hub-card" key={hub.name}><div className="hub-card-top"><div className="hub-symbol"><Icon name="building" size={20} /></div><div><Badge tone="verified" icon="check">Ready for practice</Badge><h3>{hub.name}</h3><p><Icon name="location" size={14} />{hub.city} · {hub.distance}</p></div></div><div className="hub-details"><span><strong>Equipment</strong>{hub.equipment}</span><span><strong>Next session</strong>{hub.session}</span></div><div className="hub-tags">{hub.features.map((feature) => <span key={feature}><Icon name="check" size={12} />{feature}</span>)}</div><div className="hub-card-foot"><span>{hub.assessor ? <><Icon name="check" size={14} />Assessor available</> : <><Icon name="clock" size={14} />Assessor on request</>}</span><button onClick={() => go("contact")}>View hub <Icon name="arrow" size={14} /></button></div></article>)}</div></div><div className="hub-partner-banner"><div><span className="hub-banner-icon"><Icon name="plus" size={21} /></span><div><h3>Have an accessible space?</h3><p>Partner with us to bring practical proof closer to more candidates.</p></div></div><Button variant="secondary" onClick={() => go("contact")} icon="arrow">Become a hub partner</Button></div></div></section></PublicPageLayout>;
}

function ImpactPage({ go }: { go: (view: View) => void }) {
  const stats = [{ value: "500", label: "PwD candidates", sub: "pilot target" }, { value: "50", label: "inclusive employers", sub: "pilot target" }, { value: "10", label: "NGO / skill partners", sub: "pilot target" }, { value: "2–3", label: "initial job roles", sub: "pilot focus" }];
  return <PublicPageLayout eyebrow="IMPACT DASHBOARD" title="Measure the movement, not just the moment." description="The Enable Bharat pilot is designed around meaningful progress: from registration to skill confidence, employment and retention." go={go} dark><section className="impact-dashboard section-padding"><div className="container"><div className="impact-stat-grid">{stats.map((stat) => <div className="impact-stat" key={stat.label}><span className="stat-top"><Icon name="chart" size={18} />{stat.sub}</span><strong>{stat.value}</strong><span>{stat.label}</span></div>)}</div><div className="impact-analysis"><div className="analysis-card large"><div className="analysis-heading"><div><p className="eyebrow">PILOT PROGRESSION</p><h2>Every step tells us something.</h2></div><Badge tone="verified">Illustrative pilot view</Badge></div><div className="progress-funnel">{[{ name: "Registered", value: 500, percent: 100, color: "navy" }, { name: "Skill gap closed", value: 348, percent: 70, color: "blue" }, { name: "Skill proven", value: 241, percent: 48, color: "orange" }, { name: "Interviewed", value: 126, percent: 25, color: "gold" }, { name: "Employed", value: 72, percent: 14, color: "green" }].map((item) => <div className="funnel-progress-row" key={item.name}><div><span>{item.name}</span><strong>{item.value}</strong></div><div className="wide-track"><i className={item.color} style={{ width: `${item.percent}%` }} /></div></div>)}</div></div><div className="analysis-card"><div className="analysis-heading"><div><p className="eyebrow">OUTCOME SIGNALS</p><h2>What good looks like</h2></div><Icon name="spark" size={20} /></div><div className="outcome-list">{[{ l: "Skill gap closure rate", v: "70%", trend: "+12%" }, { l: "Proof-of-work pass rate", v: "84%", trend: "+8%" }, { l: "Interview rate", v: "52%", trend: "+16%" }, { l: "90-day retention", v: "91%", trend: "On track" }].map((item) => <div key={item.l}><span>{item.l}</span><strong>{item.v}</strong><Badge tone="verified">{item.trend}</Badge></div>)}</div></div></div><div className="impact-note"><Icon name="shield" size={18} /><p><strong>We report with care.</strong> Numbers are used to improve the pathway, not to reduce people to a score. Candidate stories and consent stay at the centre.</p></div></div></section><FinalCta go={go} /></PublicPageLayout>;
}

function ResourcesPage({ go }: { go: (view: View) => void }) {
  const resources = [{ tag: "For candidates", title: "How to talk about workplace support", text: "A simple guide to starting the accommodation conversation with confidence.", color: "orange" }, { tag: "For employers", title: "The inclusive hiring playbook", text: "Practical steps from writing a clearer role to your 90-day check-in.", color: "green" }, { tag: "For partners", title: "Designing accessible learning", text: "A checklist for captions, ISL, audio and pictorial instruction.", color: "navy" }];
  return <PublicPageLayout eyebrow="RESOURCE CENTRE" title="Useful context for the next step." description="Simple guides for candidates, employers and partners building more inclusive work together." go={go}><section className="resources-page section-padding"><div className="container"><div className="resource-grid">{resources.map((resource) => <article className={`resource-card ${resource.color}`} key={resource.title}><span className="resource-icon"><Icon name={resource.color === "orange" ? "user" : resource.color === "green" ? "building" : "book"} size={21} /></span><Badge tone={resource.color === "orange" ? "orange" : resource.color === "green" ? "verified" : "navy"}>{resource.tag}</Badge><h2>{resource.title}</h2><p>{resource.text}</p><button onClick={() => go("contact")}>Read guide <Icon name="arrow" size={15} /></button></article>)}</div><div className="resource-bottom"><div><p className="eyebrow">NEED A HAND?</p><h2>Talk to a person, not a help article.</h2><p>Our support team and community partners can help you understand the journey in the language and format that works for you.</p></div><Button variant="primary" onClick={() => go("contact")} icon="message">Contact support</Button></div></div></section></PublicPageLayout>;
}

function AboutPage({ go }: { go: (view: View) => void }) {
  return <PublicPageLayout eyebrow="ABOUT ENABLE BHARAT" title="A connective layer for capability and opportunity." description="We are building the trusted infrastructure that lets people, workplaces and partners move forward together." go={go}><section className="about-page section-padding"><div className="container about-grid"><div><p className="eyebrow">OUR BELIEF</p><h2>Accessibility is not a side feature. It is how better systems are built.</h2></div><div><p>Enable Bharat brings together the pieces that are too often separated: a person’s strengths, the skills a job needs, the support a workplace can provide and evidence that shows readiness.</p><p>Our first pilot is rooted in Vadodara and Gujarat, with a model designed to grow through existing community spaces, employers, colleges and skill partners — not around a new network of expensive centres.</p><div className="about-values"><span><Icon name="shield" size={18} /><strong>Trust is earned</strong></span><span><Icon name="accessibility" size={18} /><strong>Design for dignity</strong></span><span><Icon name="spark" size={18} /><strong>Progress over perfection</strong></span></div></div><div className="about-quote"><div className="quote-mark">“</div><h2>Verify capability.<br />Build skills.<br /><span>Prove capability.<br />Get hired.</span></h2><p>A different kind of employment ecosystem for India.</p></div><div className="about-policies"><div><Icon name="lock" size={20} /><h3>Privacy policy</h3><p>Relevant workplace context, never unnecessary personal detail.</p></div><div><Icon name="accessibility" size={20} /><h3>Accessibility statement</h3><p>Keyboard-friendly, screen-reader-aware and made to adapt.</p></div><div><Icon name="shield" size={20} /><h3>Data protection</h3><p>Consent, secure storage and clear control over sharing.</p></div></div></div></section><FinalCta go={go} /></PublicPageLayout>;
}

function ContactPage({ go }: { go: (view: View) => void }) {
  const [sent, setSent] = useState(false);
  return <PublicPageLayout eyebrow="CONTACT ENABLE BHARAT" title="Let’s make the next step clearer." description="Whether you are a candidate, employer, partner or assessor, we would like to hear what would make inclusive employment work better." go={go}><section className="contact-page section-padding"><div className="container contact-grid"><div className="contact-info"><div className="contact-info-card"><span className="contact-icon"><Icon name="message" size={21} /></span><h2>Start a conversation</h2><p>Tell us what you are trying to do and a member of the Enable Bharat team will get back to you.</p><div><strong>Email</strong><span>hello@enablebharat.org</span></div><div><strong>Support hours</strong><span>Mon–Fri · 10:00 AM–6:00 PM IST</span></div></div><div className="contact-support-note"><Icon name="accessibility" size={20} /><p><strong>Need an accessible format?</strong><br />Mention your preference in the message. We can support text, audio and assisted conversations.</p></div></div><form className="contact-form" onSubmit={(event) => { event.preventDefault(); setSent(true); }}><div className="form-heading"><p className="eyebrow">SEND A MESSAGE</p><h2>{sent ? "Thanks — we’ll be in touch." : "How can we help?"}</h2></div>{sent ? <div className="sent-state"><span><Icon name="check" size={25} /></span><p>Your message has been received. We’ll respond within two working days.</p><Button variant="secondary" onClick={() => setSent(false)}>Send another message</Button></div> : <><div className="form-row"><label>First name<input required placeholder="Your first name" /></label><label>Last name<input required placeholder="Your last name" /></label></div><label>Email or mobile<input required placeholder="you@example.com" /></label><label>I am a...<select><option>Candidate</option><option>Employer</option><option>NGO / skill partner</option><option>Assessor</option></select></label><label>Your message<textarea required rows={5} placeholder="Tell us a little about what you need..." /></label><label className="checkbox-row consent"><input required type="checkbox" />I consent to Enable Bharat using this information to respond to me.</label><Button type="submit" variant="orange" icon="send">Send message</Button></>}</form></div></section></PublicPageLayout>;
}

function LoginPage({ go, onAuthenticated }: { go: (view: View) => void; onAuthenticated: (user: AuthUser) => void }) {
  const [showPassword, setShowPassword] = useState(false);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const submit = async (event: React.FormEvent) => {
    event.preventDefault();
    setSubmitting(true);
    setError("");
    const result = await apiLogin(email, password);
    setSubmitting(false);
    if (result.user) {
      onAuthenticated(result.user);
      go(dashboardForRole(result.user.role));
    } else {
      setError(result.error || "Incorrect email or password.");
    }
  };
  return <main id="main-content" className="auth-page"><div className="auth-brand"><button onClick={() => go("home")}><Logo /></button><span>Inclusive employment, with proof.</span><LanguageSelector /></div><div className="auth-grid"><div className="auth-aside"><p className="eyebrow eyebrow-light">WELCOME BACK</p><h1>Your next step<br />is waiting.</h1><p>Continue your journey from wherever you left off — a learning module, a proof-of-work task or a new opportunity.</p><div className="auth-aside-journey">{["Verify", "Assess", "Build", "Prove", "Get hired"].map((item, index) => <span key={item} className={index < 3 ? "done" : ""}>{index < 3 ? <Icon name="check" size={12} /> : index + 1}<small>{item}</small></span>)}</div></div><div className="auth-card"><div className="auth-card-head"><p className="eyebrow">SECURE SIGN IN</p><h2>Welcome back.</h2><p>Use your email or mobile to continue.</p></div><form onSubmit={submit}><label>Email or mobile<input required type="text" value={email} onChange={(event) => setEmail(event.target.value)} placeholder="you@example.com" autoComplete="username" /></label><label>Password<div className="password-input"><input required type={showPassword ? "text" : "password"} value={password} onChange={(event) => setPassword(event.target.value)} placeholder="Enter your password" autoComplete="current-password" /><button type="button" onClick={() => setShowPassword(!showPassword)} aria-label={showPassword ? "Hide password" : "Show password"}><Icon name="eye" size={17} /></button></div></label>{error && <p className="auth-error" role="alert"><Icon name="shield" size={14} />{error}</p>}<div className="form-options"><label className="checkbox-row"><input type="checkbox" />Remember me</label><button type="button" onClick={() => undefined}>Forgot password?</button></div><Button type="submit" variant="primary" className="full-button">{submitting ? "Signing in…" : "Log in"}</Button></form><p className="auth-demo-hint"><Icon name="mic" size={13} />Try the voice assistant, or sign in with the demo account <strong>ravi@enablebharat.in</strong> / <strong>ravi1234</strong>.</p><div className="auth-or"><span>or</span></div><Button variant="secondary" className="full-button" onClick={() => go("candidate-dashboard")} icon="message">Continue with OTP</Button><p className="auth-register">New to Enable Bharat? <button onClick={() => go("register")}>Create an account <Icon name="arrow" size={14} /></button></p><div className="auth-security"><Icon name="lock" size={14} />Your personal information is protected and never shared without consent.</div></div></div></main>;
}

function RegisterPage({ go }: { go: (view: View) => void }) {
  const [step, setStep] = useState(1);
  const [role, setRole] = useState("candidate");
  const steps = ["Who you are", "Basic profile", "Your focus", "Preferences", "Verification", "Complete"];
  const next = () => step < 6 ? setStep(step + 1) : go(role === "employer" ? "employer-dashboard" : "candidate-dashboard");
  return <main id="main-content" className="onboarding-page"><div className="onboarding-top"><button onClick={() => go("home")}><Logo /></button><LanguageSelector /><button className="onboarding-exit" onClick={() => go("home")}>Exit setup <Icon name="close" size={15} /></button></div><div className="onboarding-shell"><div className="onboarding-progress"><span>PROFILE SETUP</span><strong>Step {step} of 6</strong><div className="step-line"><i style={{ width: `${(step / 6) * 100}%` }} /></div>{steps.map((item, index) => <div className={`onboarding-step ${index + 1 === step ? "active" : ""} ${index + 1 < step ? "done" : ""}`} key={item}><span>{index + 1 < step ? <Icon name="check" size={13} /> : index + 1}</span><small>{item}</small></div>)}</div><div className="onboarding-content">{step === 1 && <><p className="eyebrow">LET’S START WITH YOU</p><h1>Who are you joining as?</h1><p className="onboarding-copy">Choose the path that matches your role today. You can add more roles later.</p><div className="role-choice-grid">{[{ value: "candidate", icon: "user" as IconName, title: "I’m a candidate", text: "I want to build my skills, prove my capability and find work." }, { value: "employer", icon: "building" as IconName, title: "I’m an employer", text: "I want to discover capability and hire more inclusively." }, { value: "partner", icon: "layers" as IconName, title: "I’m an NGO / skill partner", text: "I support candidates through learning and opportunity." }, { value: "assessor", icon: "target" as IconName, title: "I’m an assessor", text: "I review practical tasks and help prove job readiness." }].map((item) => <button className={`role-choice ${role === item.value ? "selected" : ""}`} key={item.value} onClick={() => setRole(item.value)}><span><Icon name={item.icon} size={22} /></span><div><h3>{item.title}</h3><p>{item.text}</p></div>{role === item.value && <b><Icon name="check" size={14} /></b>}</button>)}</div></>}{step === 2 && <OnboardingForm title="Tell us a little about yourself" fields={role === "employer" ? ["Your name", "Company name", "Work email", "City / state"] : ["Your full name", "Email or mobile", "City / state", "Preferred language"]} />}{step === 3 && <OnboardingForm title={role === "employer" ? "What are you building?" : "What would you like to do?"} fields={role === "employer" ? ["Industry", "Company size", "Hiring roles", "Website (optional)"] : ["Roles you are curious about", "What do you already know?", "Work mode preference", "Years of experience"]} />}{step === 4 && <div><p className="eyebrow">DESIGN YOUR EXPERIENCE</p><h1>What helps you participate fully?</h1><p className="onboarding-copy">These preferences make the platform easier to use. You can change them any time.</p><div className="preference-list">{["I prefer larger text", "I use a screen reader", "I prefer captions or ISL", "I learn best with audio", "I prefer structured instructions", "I would like an accessibility guide"].map((item, index) => <label key={item}><input type="checkbox" defaultChecked={index === 0 || index === 4} /><span><Icon name={index === 1 ? "eye" : index === 2 ? "users" : index === 3 ? "mic" : "accessibility"} size={17} /></span>{item}</label>)}</div></div>}{step === 5 && <div className="verification-step"><div className="verification-illustration"><Icon name="shield" size={37} /></div><p className="eyebrow">VERIFICATION WITH CARE</p><h1>We build trust together.</h1><p className="onboarding-copy">Verification helps employers and partners trust the ecosystem. You choose what to share, and private documents stay protected.</p><div className="verification-options"><label><input type="checkbox" defaultChecked /><span><Icon name="check" size={15} /></span><div><strong>Identity verification</strong><small>Confirm your name and contact details</small></div><Badge tone="verified">Required</Badge></label><label><input type="checkbox" /><span><Icon name="upload" size={15} /></span><div><strong>Supporting documentation</strong><small>Optional · securely reviewed by our team</small></div><Badge tone="neutral">Optional</Badge></label></div><div className="privacy-inline"><Icon name="lock" size={15} />Your documents are encrypted and never visible in public profile views.</div></div>}{step === 6 && <div className="complete-step"><div className="complete-check"><Icon name="check" size={31} /></div><p className="eyebrow">YOU’RE READY TO BEGIN</p><h1>Welcome to Enable Bharat.</h1><p className="onboarding-copy">Your starting workspace is ready. We’ll guide you through the next step, one clear action at a time.</p><div className="complete-card"><div><Icon name="spark" size={20} /><div><strong>First recommendation</strong><span>{role === "employer" ? "Create your first inclusive job" : "Complete your capability snapshot"}</span></div></div><Icon name="arrow" size={18} /></div></div>}<div className="onboarding-actions"><button className="back-action" onClick={() => step > 1 ? setStep(step - 1) : go("home")}><Icon name="arrow" size={15} />{step > 1 ? "Back" : "Save & exit"}</button><Button variant="orange" onClick={next} icon={step === 6 ? "arrow" : "arrow"}>{step === 6 ? "Enter my workspace" : "Continue"}</Button></div></div></div></main>;
}

function OnboardingForm({ title, fields }: { title: string; fields: string[] }) {
  return <div><p className="eyebrow">A FEW DETAILS</p><h1>{title}</h1><p className="onboarding-copy">This helps us make your first recommendations more relevant.</p><div className="onboarding-form-grid">{fields.map((field) => <label key={field}>{field}{field.includes("language") ? <select><option>English</option><option>Hindi</option><option>Gujarati</option></select> : field.includes("preference") || field.includes("mode") ? <select><option>Hybrid</option><option>Remote</option><option>On-site</option></select> : <input placeholder={`Enter ${field.toLowerCase()}`} />}</label>)}</div></div>;
}

const candidateNav: { label: string; view: View; icon: IconName }[] = [{ label: "Overview", view: "candidate-dashboard", icon: "home" }, { label: "Agla Kadam", view: "agla-kadam", icon: "play" }, { label: "My profile", view: "candidate-passport", icon: "user" }, { label: "My skills", view: "candidate-skills", icon: "target" }, { label: "Skill gap", view: "skill-gap", icon: "spark" }, { label: "Learning", view: "candidate-learning", icon: "book" }, { label: "Assessments", view: "candidate-assessments", icon: "clipboard" }, { label: "Proof of work", view: "candidate-proof", icon: "shield" }, { label: "Recommended jobs", view: "jobs", icon: "briefcase" }, { label: "Applications", view: "candidate-applications", icon: "file" }, { label: "Messages", view: "contact", icon: "message" }, { label: "Settings", view: "candidate-settings", icon: "settings" }];
const employerNav: { label: string; view: View; icon: IconName }[] = [{ label: "Overview", view: "employer-dashboard", icon: "home" }, { label: "Jobs", view: "employer-jobs", icon: "briefcase" }, { label: "Candidates", view: "employer-candidates", icon: "users" }, { label: "Shortlisted", view: "employer-shortlisted", icon: "spark" }, { label: "Interviews", view: "employer-interviews", icon: "calendar" }, { label: "Hiring", view: "employer-dashboard", icon: "target" }, { label: "Analytics", view: "employer-analytics", icon: "chart" }, { label: "Company profile", view: "employer-company", icon: "building" }];

function DashboardShell({ go, role, children }: { go: (view: View) => void; role: "candidate" | "employer" | "assessor" | "admin"; children: React.ReactNode }) {
  const [mobileNav, setMobileNav] = useState(false);
  const nav = role === "candidate" ? candidateNav : employerNav;
  const activeView = typeof window !== "undefined" ? new URLSearchParams(window.location.search).get("view") : "";
   return <div className={`dashboard-shell dashboard-${role}`}><aside className={`dashboard-sidebar ${mobileNav ? "mobile-open" : ""}`}><div className="dashboard-sidebar-head"><button onClick={() => go("home")} aria-label="Enable Bharat home"><Logo compact /></button><button className="sidebar-close" onClick={() => setMobileNav(false)} aria-label="Close navigation"><Icon name="close" size={19} /></button></div><div className="workspace-switcher"><span className="workspace-avatar">{role === "candidate" ? "RM" : role === "employer" ? "AR" : role === "assessor" ? "SK" : "AD"}</span><div><strong>{role === "candidate" ? "Ravi Mehta" : role === "employer" ? "Aarohan Retail" : role === "assessor" ? "Shreya Kulkarni" : "Enable Bharat"}</strong><small>{role === "candidate" ? "Candidate workspace" : role === "employer" ? "Employer workspace" : `${role[0].toUpperCase()}${role.slice(1)} workspace`}</small></div><Icon name="chevron" size={15} /></div><nav className="dashboard-nav" aria-label="Workspace navigation"><span className="nav-section-label">WORKSPACE</span>{nav.map((item) => <button key={item.label} className={activeView === item.view || (!activeView && item.view === `${role}-dashboard`) ? "active" : ""} onClick={() => { setMobileNav(false); go(item.view); }}><Icon name={item.icon} size={18} /><span>{item.label}</span>{item.label === "Messages" && <b>2</b>}</button>)}<span className="nav-section-label">SUPPORT</span><button onClick={() => go("resources")}><Icon name="help" size={18} />Help centre</button><button onClick={() => go("contact")}><Icon name="message" size={18} />Contact support</button></nav><div className="sidebar-footer"><div><Icon name="shield" size={17} /><span><strong>Privacy protected</strong><small>Your data is in your control</small></span></div><button onClick={() => go("home")}>Sign out <Icon name="arrow" size={14} /></button></div></aside><div className="dashboard-main"><header className="dashboard-header"><button className="dashboard-menu" onClick={() => setMobileNav(true)} aria-label="Open workspace navigation"><Icon name="menu" size={21} /></button><div className="dashboard-breadcrumb"><span>Workspace</span><Icon name="chevron" size={13} /><strong>{role === "candidate" ? "Overview" : role === "employer" ? "Employer overview" : "Dashboard"}</strong></div><div className="dashboard-header-actions"><LanguageSelector /><button className="dashboard-search"><Icon name="search" size={17} /><span>Search workspace</span><kbd>⌘ K</kbd></button><button aria-label="Notifications" className="header-icon"><Icon name="bell" size={19} /><i /></button><button aria-label="Messages" className="header-icon"><Icon name="message" size={19} /></button><span className="header-avatar">{role === "candidate" ? "RM" : role === "employer" ? "AR" : role === "assessor" ? "SK" : "AD"}</span></div></header>{children}</div></div>;
}

function DashboardStat({ label, value, detail, icon, tone = "navy" }: { label: string; value: string; detail: string; icon: IconName; tone?: string }) {
  return <div className="dashboard-stat-card"><div className={`stat-icon ${tone}`}><Icon name={icon} size={19} /></div><span>{label}</span><strong>{value}</strong><small className={detail.startsWith("+") || detail.includes("track") ? "positive" : ""}>{detail}</small></div>;
}

function CandidateDashboard({ go }: { go: (view: View) => void }) {
  return <DashboardShell go={go} role="candidate"><main className="dashboard-content" id="main-content"><div className="dashboard-welcome"><div><p className="eyebrow">TUESDAY, 20 AUGUST 2025</p><h1>Good morning, Ravi.</h1><p>You are making steady progress. Here’s the clearest next step.</p></div><Button variant="orange" onClick={() => go("jobs")} icon="search">Explore opportunities</Button></div><section className="journey-progress-card"><div className="journey-progress-head"><div><span className="eyebrow">YOUR EMPLOYMENT JOURNEY</span><h2>Keep moving forward.</h2></div><div className="journey-progress-total"><strong>65%</strong><span>journey complete</span></div></div><div className="dashboard-journey"><div className="journey-progress-line"><i style={{ width: "57%" }} /></div>{[{ t: "Verify", status: "done", sub: "Complete" }, { t: "Assess", status: "done", sub: "Complete" }, { t: "Skill gap", status: "done", sub: "2 skills" }, { t: "Learn", status: "current", sub: "65%" }, { t: "Prove", status: "next", sub: "Next" }, { t: "Match", status: "next", sub: "Locked" }, { t: "Hire", status: "next", sub: "Locked" }].map((item) => <div className={`dashboard-journey-step ${item.status}`} key={item.t}><span>{item.status === "done" ? <Icon name="check" size={13} /> : item.status === "current" ? <Icon name="play" size={11} /> : ""}</span><strong>{item.t}</strong><small>{item.sub}</small></div>)}</div></section><div className="candidate-dashboard-grid"><div className="dashboard-main-column"><section className="next-action-card"><div className="next-action-copy"><Badge tone="orange" icon="spark">RECOMMENDED NEXT STEP</Badge><h2>Complete POS Billing Module</h2><p>One focused module brings you closer to the Store Associate role you chose.</p><div className="module-progress"><ProgressBar value={65} tone="orange" /><span>65% · 14 min remaining</span></div><Button variant="orange" onClick={() => go("candidate-learning")} icon="play">Continue learning</Button></div><div className="next-action-visual"><div className="course-mini-icon"><Icon name="briefcase" size={30} /></div><div className="mini-video-card"><span><Icon name="play" size={11} /></span><small>POS Billing Fundamentals</small></div><div className="mini-caption">CC &nbsp; Aa &nbsp; <Icon name="accessibility" size={12} /></div></div></section><section className="dashboard-section-block"><div className="block-heading"><div><span className="eyebrow">RECOMMENDED FOR YOU</span><h2>Roles that fit your progress</h2></div><button onClick={() => go("jobs")}>View all <Icon name="arrow" size={14} /></button></div><div className="recommended-row">{jobs.slice(0, 2).map((job) => <JobCard key={job.id} job={job} go={go} compact />)}</div></section></div><aside className="dashboard-side-column"><div className="profile-progress-card"><div className="profile-head"><div><span className="eyebrow">YOUR PROFILE</span><h3>Ravi Mehta</h3></div><div className="profile-score">92%</div></div><ProgressBar value={92} tone="green" /><p>Strong profile. Add one Proof of Work to stand out.</p><button onClick={() => go("candidate-passport")}>View Accessibility Passport <Icon name="arrow" size={14} /></button></div><div className="dashboard-side-card"><div className="side-card-heading"><h3>Skill gap</h3><Badge tone="orange">2 remaining</Badge></div><p>For your Store Associate pathway</p><div className="gap-mini-item"><span><Icon name="arrow" size={14} /></span><div><strong>POS Billing</strong><small>4 modules · 65% complete</small></div><Icon name="chevron" size={14} /></div><div className="gap-mini-item"><span className="muted"><Icon name="arrow" size={14} /></span><div><strong>Store Hygiene</strong><small>2 modules · Not started</small></div><Icon name="chevron" size={14} /></div><button onClick={() => go("skill-gap")}>Open Skill Gap Bridge <Icon name="arrow" size={14} /></button></div><div className="dashboard-side-card upcoming-card"><div className="side-card-heading"><h3>Coming up</h3><button onClick={() => go("candidate-assessments")}><Icon name="arrow" size={15} /></button></div><div className="upcoming-event"><span className="calendar-tile">24<small>AUG</small></span><div><strong>Practical hub visit</strong><small>Enable Lab · Vadodara</small><Badge tone="neutral">In 4 days</Badge></div></div></div></aside></div></main><CandidateBottomNav go={go} /></DashboardShell>;
}

function CandidateBottomNav({ go }: { go: (view: View) => void }) {
  return <nav className="candidate-bottom-nav" aria-label="Mobile navigation">{[{ l: "Home", v: "candidate-dashboard" as View, i: "home" as IconName }, { l: "Jobs", v: "jobs" as View, i: "briefcase" as IconName }, { l: "Learn", v: "candidate-learning" as View, i: "book" as IconName }, { l: "Applications", v: "candidate-applications" as View, i: "file" as IconName }, { l: "Profile", v: "candidate-passport" as View, i: "user" as IconName }].map((item) => <button key={item.l} onClick={() => go(item.v)}><Icon name={item.i} size={19} /><span>{item.l}</span></button>)}</nav>;
}

function CandidateSkillsPage({ go }: { go: (view: View) => void }) {
  const mySkills = [{ title: "Communication", level: 4, source: "Self-assessed · Verified", tone: "green" }, { title: "Computer basics", level: 4, source: "Assessment · Verified", tone: "green" }, { title: "Customer interaction", level: 4, source: "Self-assessed", tone: "orange" }, { title: "Spreadsheet skills", level: 3, source: "Proof of work", tone: "orange" }, { title: "Typing", level: 5, source: "Assessment · Verified", tone: "green" }, { title: "Problem solving", level: 4, source: "Self-assessed", tone: "navy" }];
  return <DashboardShell go={go} role="candidate"><main className="dashboard-content dashboard-view-area" id="main-content"><DashboardTitle eyebrow="MY SKILLS" title="A capability profile that grows with you." description="Your skills become stronger signals when they are practiced, assessed and proven." action={<Button variant="orange" onClick={() => go("candidate-assessments")} icon="target">Prove a skill</Button>} /><div className="skills-summary"><div><span className="summary-icon"><Icon name="target" size={20} /></span><div><strong>6 skills tracked</strong><span>4 verified through assessment or proof</span></div></div><div><span className="summary-icon orange"><Icon name="spark" size={20} /></span><div><strong>2 skills growing</strong><span>Connected to your current pathway</span></div></div><div><span className="summary-icon green"><Icon name="briefcase" size={20} /></span><div><strong>3 roles matched</strong><span>Based on your capability</span></div></div></div><div className="skills-toolbar"><div className="tabs"><button className="active">All skills</button><button>Verified</button><button>In progress</button></div><button className="sort-button"><Icon name="sliders" size={16} />Sort by <strong>Relevance</strong><Icon name="chevron" size={14} /></button></div><div className="skills-card-grid">{mySkills.map((skill) => <article className="my-skill-card" key={skill.title}><div className="my-skill-top"><span className={`skill-icon ${skill.tone}`}><Icon name={skill.tone === "green" ? "check" : "target"} size={17} /></span><Badge tone={skill.tone === "green" ? "verified" : skill.tone === "orange" ? "orange" : "navy"}>{skill.source.includes("Verified") ? "Verified" : "Developing"}</Badge></div><h3>{skill.title}</h3><div className="skill-level"><div className="dot-scale">{[1, 2, 3, 4, 5].map((dot) => <i className={dot <= skill.level ? "filled" : ""} key={dot} />)}</div><span>{skill.level}/5</span></div><p>{skill.source}</p><button onClick={() => go("candidate-assessments")}>{skill.source.includes("Verified") ? "View evidence" : "Build this skill"} <Icon name="arrow" size={14} /></button></article>)}</div></main></DashboardShell>;
}

function LearningPage({ go }: { go: (view: View) => void }) {
  const [activeModule, setActiveModule] = useState(2);
  return <DashboardShell go={go} role="candidate"><main className="dashboard-content dashboard-view-area" id="main-content"><DashboardTitle eyebrow="LEARNING / POS BILLING FUNDAMENTALS" title="Learn in the way that works for you." description="Short, accessible modules designed around the role you want next." action={<Button variant="secondary" onClick={() => go("skill-gap")} icon="arrow">Back to Skill Gap</Button>} /><div className="learning-layout"><div className="learning-player"><div className="video-stage"><div className="video-decoration"><span className="video-pill">POS BILLING</span><div className="video-terminal"><div className="terminal-top"><span>SALE / NEW TRANSACTION</span><span>● LIVE PRACTICE</span></div><div className="terminal-lines"><i /><i /><i /><b>₹ 1,240.00</b></div><div className="terminal-button">COMPLETE SALE <Icon name="arrow" size={12} /></div></div></div><div className="video-controls"><button aria-label="Play lesson"><Icon name="play" size={14} /></button><div className="video-line"><i /></div><span>08:42 / 18:00</span><span><Icon name="mic" size={15} /> CC</span><span>Aa</span><button aria-label="Full screen"><Icon name="grid" size={15} /></button></div></div><div className="learning-player-toolbar"><div><Badge tone="verified" icon="check">Captions available</Badge><Badge tone="navy" icon="users">ISL available</Badge><Badge tone="orange" icon="mic">Audio narration</Badge></div><button onClick={() => document.body.classList.toggle("high-contrast")}><Icon name="accessibility" size={15} />Accessibility options</button></div><div className="lesson-copy"><p className="eyebrow">MODULE 03 / BILLING WORKFLOW</p><h2>Making a sale from start to finish</h2><p>In this lesson, you’ll practice the four steps of a standard POS transaction. You can pause, replay or switch format at any time.</p></div></div><aside className="module-list-card"><div className="module-list-head"><div><p className="eyebrow">YOUR COURSE</p><h2>POS Billing Fundamentals</h2></div><strong>65%</strong></div><ProgressBar value={65} tone="orange" /><div className="module-list">{modules.map((module, index) => <button key={module.title} className={`module-row ${activeModule === index ? "active" : ""}`} onClick={() => setActiveModule(index)}><span className={`module-status ${module.status}`}>{module.status === "done" ? <Icon name="check" size={13} /> : module.status === "current" ? <Icon name="play" size={10} /> : index + 1}</span><div><strong>{module.title}</strong><small>{module.duration}</small></div><Icon name="chevron" size={14} /></button>)}</div><div className="learning-help"><Icon name="help" size={16} /><span>Need help with a lesson? <button onClick={() => go("contact")}>Ask a guide</button></span></div></aside></div></main></DashboardShell>;
}

function CandidateAssessmentsPage({ go }: { go: (view: View) => void }) {
  return <DashboardShell go={go} role="candidate"><main className="dashboard-content dashboard-view-area" id="main-content"><DashboardTitle eyebrow="ASSESSMENTS" title="Practice with purpose." description="Your assessments are built around familiar workplace tasks and supported by a human assessor." action={<Button variant="orange" onClick={() => go("hubs")} icon="location">Find a hub</Button>} /><div className="assessment-banner"><div><Badge tone="orange" icon="spark">NEXT UP</Badge><h2>POS transaction practical</h2><p>Show the billing workflow you just learned at Enable Lab · Vadodara.</p><div className="assessment-banner-meta"><span><Icon name="calendar" size={15} />24 Aug 2025</span><span><Icon name="clock" size={15} />30 minutes</span><span><Icon name="users" size={15} />Assessor: Shreya K.</span></div></div><div className="assessment-banner-action"><span className="assessment-date">24<small>AUG</small></span><Button variant="orange" onClick={() => go("hubs")}>View preparation <Icon name="arrow" size={15} /></Button></div></div><div className="dashboard-section-block"><div className="block-heading"><div><span className="eyebrow">YOUR ASSESSMENT RECORD</span><h2>Progress you can point to</h2></div></div><div className="record-table"><div className="record-table-head"><span>Assessment</span><span>Format</span><span>Assessor</span><span>Status</span><span /></div>{[{ title: "Spreadsheet accuracy task", role: "Data Entry Operator", format: "Practical · 25 min", assessor: "Shreya Kulkarni", status: "Completed", tone: "verified", score: "92%" }, { title: "POS transaction practical", role: "Store Associate", format: "Hub visit · 30 min", assessor: "Shreya Kulkarni", status: "Scheduled", tone: "orange", score: "24 Aug" }, { title: "Customer conversation", role: "Customer Support", format: "Live simulation · 20 min", assessor: "To be assigned", status: "Not started", tone: "neutral", score: "—" }].map((assessment) => <div className="record-row" key={assessment.title}><div><span className="record-icon"><Icon name="clipboard" size={17} /></span><strong>{assessment.title}</strong><small>{assessment.role}</small></div><span>{assessment.format}</span><span>{assessment.assessor}</span><Badge tone={assessment.tone as "verified" | "orange" | "neutral"}>{assessment.status}</Badge><strong>{assessment.score}</strong></div>)}</div></div></main></DashboardShell>;
}

function ApplicationsPage({ go }: { go: (view: View) => void }) {
  const apps = [{ title: "Store Associate", company: "Aarohan Retail", location: "Ahmedabad · Hybrid", status: "Bridge in progress", tone: "orange", match: "94%" }, { title: "Data Entry Operator", company: "Nirmaan Services", location: "Vadodara · On-site", status: "Interview scheduled", tone: "verified", match: "87%" }, { title: "Customer Support Executive", company: "Udaan Digital", location: "Remote · India", status: "Application received", tone: "navy", match: "76%" }];
  return <DashboardShell go={go} role="candidate"><main className="dashboard-content dashboard-view-area" id="main-content"><DashboardTitle eyebrow="APPLICATIONS" title="Keep every conversation in view." description="A clear record of where you are, what happens next and who is supporting you." action={<Button variant="orange" onClick={() => go("jobs")} icon="search">Find more roles</Button>} /><div className="application-summary"><DashboardStat label="Active applications" value="3" detail="+1 this week" icon="file" tone="navy" /><DashboardStat label="Interviews" value="1" detail="Next: 28 Aug" icon="calendar" tone="orange" /><DashboardStat label="Average match" value="86%" detail="Strong fit" icon="target" tone="green" /></div><div className="applications-list"><div className="block-heading"><div><span className="eyebrow">YOUR APPLICATIONS</span><h2>Where things stand</h2></div><div className="tabs small-tabs"><button className="active">All (3)</button><button>In progress</button><button>Closed</button></div></div>{apps.map((app) => <article className="application-card" key={app.title}><div className="company-logo" style={{ background: app.tone === "orange" ? "#fff3e5" : app.tone === "verified" ? "#e9f8ef" : "#e9f0ff" }}>{app.company.slice(0, 2).toUpperCase()}</div><div className="application-info"><h3>{app.title}</h3><p>{app.company} · {app.location}</p><span><Icon name="target" size={14} />{app.match} skill match</span></div><Badge tone={app.tone as "orange" | "verified" | "navy"}>{app.status}</Badge><button onClick={() => go("job-detail")}><Icon name="chevron" size={17} /></button></article>)}</div></main></DashboardShell>;
}

function CandidateSettingsPage({ go }: { go: (view: View) => void }) {
  return <DashboardShell go={go} role="candidate"><main className="dashboard-content dashboard-view-area" id="main-content"><DashboardTitle eyebrow="SETTINGS" title="Your account, your choices." description="Control how Enable Bharat communicates with you and what employers can see." /><div className="settings-grid"><div className="settings-card"><div className="settings-card-head"><span><Icon name="user" size={18} /></span><div><h2>Personal information</h2><p>Basic details used for your profile and communication.</p></div><button>Edit <Icon name="arrow" size={14} /></button></div><div className="settings-fields"><div><span>Full name</span><strong>Ravi Mehta</strong></div><div><span>Email</span><strong>ravi.mehta@email.com</strong></div><div><span>Mobile</span><strong>+91 98••• ••210</strong></div><div><span>Location</span><strong>Vadodara, Gujarat</strong></div></div></div><div className="settings-card"><div className="settings-card-head"><span><Icon name="lock" size={18} /></span><div><h2>Passport privacy</h2><p>Choose what is relevant when employers view your profile.</p></div></div><div className="settings-options"><label><div><strong>Relevant workplace context</strong><small>Recommended · skills, preferences and support</small></div><input type="radio" name="privacy" defaultChecked /></label><label><div><strong>Only verified skills</strong><small>Show proof-backed capabilities only</small></div><input type="radio" name="privacy" /></label><label><div><strong>Private</strong><small>Only share when you choose to apply</small></div><input type="radio" name="privacy" /></label></div></div><div className="settings-card"><div className="settings-card-head"><span><Icon name="bell" size={18} /></span><div><h2>Notifications</h2><p>Choose where we send updates.</p></div></div>{["New role matches", "Learning reminders", "Application updates", "Partner messages"].map((item, index) => <label className="toggle-row" key={item}><span>{item}</span><input type="checkbox" defaultChecked={index < 3} /><i /></label>)}</div><div className="settings-card danger-card"><div className="settings-card-head"><span><Icon name="help" size={18} /></span><div><h2>Need help?</h2><p>Our support team can help you change any preference.</p></div></div><Button variant="secondary" onClick={() => go("contact")} icon="message">Contact support</Button></div></div></main></DashboardShell>;
}

function DashboardTitle({ eyebrow, title, description, action }: { eyebrow: string; title: string; description: string; action?: React.ReactNode }) {
  return <div className="dashboard-view-title"><div><p className="eyebrow">{eyebrow}</p><h1>{title}</h1><p>{description}</p></div>{action && <div>{action}</div>}</div>;
}

function EmployerDashboard({ go, subView = "overview" }: { go: (view: View) => void; subView?: string }) {
  if (subView !== "overview") return <EmployerWorkspacePage go={go} view={subView} />;
  return <DashboardShell go={go} role="employer"><main className="dashboard-content dashboard-view-area" id="main-content"><div className="dashboard-welcome"><div><p className="eyebrow">EMPLOYER WORKSPACE / TUESDAY, 20 AUGUST 2025</p><h1>Good morning, Aarohan Retail.</h1><p>Here’s how your inclusive hiring pipeline is moving.</p></div><Button variant="orange" onClick={() => go("employer-jobs")} icon="plus">Post a new job</Button></div><div className="employer-stat-grid"><DashboardStat label="Active jobs" value="12" detail="+3 this month" icon="briefcase" tone="navy" /><DashboardStat label="Candidates" value="184" detail="42 new this week" icon="users" tone="blue" /><DashboardStat label="Shortlisted" value="32" detail="18% of applicants" icon="spark" tone="orange" /><DashboardStat label="Interviews" value="8" detail="2 this week" icon="calendar" tone="purple" /><DashboardStat label="Hired" value="4" detail="+2 this quarter" icon="check" tone="green" /></div><div className="employer-dashboard-grid"><div className="analysis-card dashboard-funnel-card"><div className="analysis-heading"><div><p className="eyebrow">HIRING FUNNEL</p><h2>Progress by candidate stage</h2></div><select aria-label="Hiring funnel period"><option>Last 30 days</option><option>Last 90 days</option></select></div><div className="dashboard-chart"><div className="chart-y"><span>200</span><span>150</span><span>100</span><span>50</span><span>0</span></div><div className="chart-plot"><div className="chart-grid-lines"><i /><i /><i /><i /><i /></div><div className="bar-chart">{[{ l: "Applicants", v: 184, h: 92, color: "navy" }, { l: "Verified", v: 126, h: 64, color: "blue" }, { l: "Matched", v: 58, h: 30, color: "orange" }, { l: "Interviewed", v: 21, h: 13, color: "gold" }, { l: "Hired", v: 8, h: 7, color: "green" }].map((bar) => <div className="bar-group" key={bar.l}><strong>{bar.v}</strong><i className={bar.color} style={{ height: `${bar.h}%` }} /><span>{bar.l}</span></div>)}</div></div></div><div className="chart-foot"><span><i className="chart-legend blue" />Candidate movement</span><span><Icon name="spark" size={14} /> <strong>+18%</strong> match rate vs last month</span></div></div><div className="analysis-card employer-actions-card"><div className="analysis-heading"><div><p className="eyebrow">QUICK ACTIONS</p><h2>Keep the momentum</h2></div></div><button onClick={() => go("employer-candidates")}><span className="quick-icon blue"><Icon name="users" size={18} /></span><div><strong>Review matched candidates</strong><small>12 profiles have a 85%+ role match</small></div><Icon name="arrow" size={16} /></button><button onClick={() => go("employer-jobs")}><span className="quick-icon orange"><Icon name="briefcase" size={18} /></span><div><strong>Add accessibility context</strong><small>8 of your roles need more detail</small></div><Icon name="arrow" size={16} /></button><button onClick={() => go("employer-interviews")}><span className="quick-icon green"><Icon name="calendar" size={18} /></span><div><strong>Prepare for interviews</strong><small>2 conversations this week</small></div><Icon name="arrow" size={16} /></button></div></div><div className="dashboard-section-block"><div className="block-heading"><div><span className="eyebrow">RECENT CANDIDATES</span><h2>People worth meeting</h2></div><button onClick={() => go("employer-candidates")}>View all candidates <Icon name="arrow" size={14} /></button></div><div className="candidate-mini-grid">{candidates.map((candidate) => <CandidateCard candidate={candidate} go={go} key={candidate.name} />)}</div></div></main></DashboardShell>;
}

function CandidateCard({ candidate, go, compact = false }: { candidate: typeof candidates[number]; go: (view: View) => void; compact?: boolean }) {
  return <article className={`candidate-card ${compact ? "compact" : ""}`}><div className="candidate-card-head"><div className="candidate-avatar">{candidate.initials}</div><div><Badge tone="verified" icon="check">Verified</Badge><h3>{candidate.name}</h3><p>{candidate.role}</p></div><button><span>•••</span></button></div><div className="candidate-match-row"><div><small>ROLE MATCH</small><strong>{candidate.match}%</strong></div><ProgressBar value={candidate.match} tone="green" /></div><div className="candidate-skills">{candidate.skills.map((skill) => <span key={skill}><Icon name="check" size={12} />{skill}</span>)}</div><div className="candidate-card-foot"><span><Icon name="shield" size={13} />{candidate.proof}</span><button onClick={() => go("employer-candidates")}>View profile <Icon name="arrow" size={14} /></button></div></article>;
}

function EmployerWorkspacePage({ go, view }: { go: (view: View) => void; view: string }) {
  const titles: Record<string, { eyebrow: string; title: string; description: string }> = { jobs: { eyebrow: "EMPLOYER WORKSPACE / JOBS", title: "Roles that invite capability.", description: "Create clear jobs with the support context candidates need." }, candidates: { eyebrow: "EMPLOYER WORKSPACE / CANDIDATES", title: "Discover capability, not assumptions.", description: "Search verified profiles by skills, proof and workplace fit." }, shortlisted: { eyebrow: "EMPLOYER WORKSPACE / SHORTLISTED", title: "Your shortlist, with context.", description: "Keep the people worth meeting close and move them forward." }, interviews: { eyebrow: "EMPLOYER WORKSPACE / INTERVIEWS", title: "Make every conversation count.", description: "Prepare interview teams with the context to create a fair, useful conversation." }, analytics: { eyebrow: "EMPLOYER WORKSPACE / ANALYTICS", title: "See where inclusion is moving.", description: "Measure hiring progress without exposing sensitive candidate information." }, company: { eyebrow: "EMPLOYER WORKSPACE / COMPANY PROFILE", title: "Make your workplace legible.", description: "Show candidates what support looks like before they apply." } };
  const config = titles[view] || titles.jobs;
  return <DashboardShell go={go} role="employer"><main className="dashboard-content dashboard-view-area" id="main-content"><DashboardTitle eyebrow={config.eyebrow} title={config.title} description={config.description} action={<Button variant="orange" onClick={() => view === "candidates" ? go("employer-candidates") : go("employer-jobs")} icon={view === "jobs" ? "plus" : "arrow"}>{view === "jobs" ? "Post a new job" : view === "candidates" ? "Discover candidates" : "Take action"}</Button>} />{view === "candidates" || view === "shortlisted" ? <><div className="candidate-search-toolbar"><div className="search-field"><Icon name="search" size={17} /><input placeholder="Search by role, skill or name" /></div><button className="filter-button"><Icon name="filter" size={16} />Filters <Badge tone="orange">3</Badge></button><select><option>Best role match</option><option>Recently updated</option><option>Proof-of-work first</option></select></div><div className="candidate-discovery-grid">{candidates.map((candidate) => <CandidateCard candidate={candidate} go={go} key={candidate.name} />)}</div></> : view === "jobs" ? <EmployerJobsContent go={go} /> : view === "interviews" ? <InterviewsContent /> : view === "analytics" ? <AnalyticsContent /> : view === "company" ? <CompanyContent /> : <EmployerJobsContent go={go} />}</main></DashboardShell>;
}

function EmployerJobsContent({ go }: { go: (view: View) => void }) {
  return <div className="employer-jobs-content"><div className="employer-job-list"><div className="block-heading"><div><span className="eyebrow">12 ACTIVE ROLES</span><h2>Your open opportunities</h2></div><div className="tabs small-tabs"><button className="active">Active</button><button>Drafts (3)</button><button>Closed</button></div></div>{jobs.map((job, index) => <article className="employer-job-row" key={job.id}><div className="company-logo" style={{ background: job.color }}>{job.logo}</div><div><h3>{job.title}</h3><p>{job.location} · {job.mode} · {job.type}</p><span><Icon name="target" size={13} />{job.match}% average match · Posted {index + 2} days ago</span></div><div><strong>{[24, 18, 11, 8][index] || 6}</strong><small>applicants</small></div><Badge tone={index === 1 ? "orange" : "verified"}>{index === 1 ? "Needs context" : "Active"}</Badge><button onClick={() => go("employer-candidates")}><Icon name="chevron" size={16} /></button></article>)}</div><div className="job-tip-card"><span><Icon name="spark" size={20} /></span><p className="eyebrow">HIRING TIP</p><h3>Clear support attracts better matches.</h3><p>Add the tools, flexibility and structure your team can offer to help candidates make a confident decision.</p><button onClick={() => go("employer-company")}>Improve your role context <Icon name="arrow" size={14} /></button></div></div>;
}

function InterviewsContent() {
  return <div className="interviews-layout"><div className="calendar-card"><div className="calendar-head"><button><Icon name="chevron" size={16} /></button><h2>August 2025</h2><button><Icon name="chevron" size={16} /></button></div><div className="calendar-week">{["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"].map((day) => <span key={day}>{day}</span>)}</div><div className="calendar-days">{Array.from({ length: 35 }, (_, index) => <button className={index === 19 ? "selected" : index === 21 ? "has-event" : ""} key={index}>{index < 3 ? "" : index - 2}</button>)}</div></div><div className="interview-list"><div className="block-heading"><div><p className="eyebrow">THIS WEEK</p><h2>Upcoming conversations</h2></div></div>{[{ date: "24", time: "11:00 AM", candidate: "Ravi Mehta", role: "Customer Support Executive", type: "First conversation" }, { date: "28", time: "03:30 PM", candidate: "Asha Patel", role: "Data Entry Operator", type: "Team interview" }].map((item) => <div className="interview-row" key={item.candidate}><span className="interview-date">{item.date}<small>AUG</small></span><div><strong>{item.candidate}</strong><p>{item.role}</p><Badge tone="neutral">{item.type}</Badge></div><span className="interview-time"><Icon name="clock" size={14} />{item.time}</span><button><Icon name="chevron" size={16} /></button></div>)}</div></div>;
}

function AnalyticsContent() {
  return <div className="analytics-content"><div className="analytics-highlight"><div><p className="eyebrow">INCLUSION SIGNAL</p><h2>Skill match rate is moving up.</h2><p>Your roles are becoming clearer, and the right candidates are finding them faster.</p></div><strong>84%<small>+18% this quarter</small></strong></div><div className="analytics-grid"><div className="analysis-card"><div className="analysis-heading"><div><p className="eyebrow">MATCH QUALITY</p><h2>Average match by role</h2></div></div><div className="horizontal-bars">{[{ l: "Customer support", v: 92 }, { l: "Data entry", v: 87 }, { l: "Inventory", v: 81 }, { l: "Content review", v: 76 }].map((item) => <div key={item.l}><span>{item.l}</span><div><i style={{ width: `${item.v}%` }} /></div><strong>{item.v}%</strong></div>)}</div></div><div className="analysis-card"><div className="analysis-heading"><div><p className="eyebrow">CANDIDATE EXPERIENCE</p><h2>Support conversations</h2></div></div><div className="donut-summary"><div className="donut"><span>94<small>%</small></span></div><div><strong>Support context viewed</strong><p>of candidates who reached shortlist</p><Badge tone="verified">On track</Badge></div></div></div></div></div>;
}

function CompanyContent() {
  return <div className="company-profile-editor"><div className="settings-card"><div className="settings-card-head"><span><Icon name="building" size={18} /></span><div><h2>Public company profile</h2><p>This is the first context a candidate sees when they explore your role.</p></div><Button variant="secondary">Save changes</Button></div><div className="onboarding-form-grid"><label>Company name<input defaultValue="Aarohan Retail" /></label><label>Industry<select defaultValue="Retail"><option>Retail</option><option>Technology</option><option>Services</option></select></label><label>About your workplace<textarea defaultValue="Aarohan Retail is a growing retail network making everyday shopping more welcoming and accessible." rows={4} /></label><label>Website<input defaultValue="https://aarohanretail.in" /></label></div></div><div className="settings-card"><div className="settings-card-head"><span><Icon name="accessibility" size={18} /></span><div><h2>Support you can offer</h2><p>Help candidates understand what inclusion looks like in practice.</p></div></div>{["Accessible workplace", "Flexible work schedule", "Assistive technology", "Structured onboarding", "Mentor or buddy support"].map((item, index) => <label className="toggle-row" key={item}><span>{item}</span><input type="checkbox" defaultChecked={index !== 4} /><i /></label>)}</div></div>;
}

function AssessorDashboard({ go }: { go: (view: View) => void }) {
  return <DashboardShell go={go} role="assessor"><main className="dashboard-content dashboard-view-area" id="main-content"><div className="dashboard-welcome"><div><p className="eyebrow">ASSESSOR WORKSPACE / TUESDAY, 20 AUGUST 2025</p><h1>Good morning, Shreya.</h1><p>Your reviews help turn practice into trusted proof.</p></div><Button variant="orange" onClick={() => go("hubs")} icon="calendar">View hub schedule</Button></div><div className="employer-stat-grid"><DashboardStat label="Assigned candidates" value="28" detail="6 new this week" icon="users" tone="navy" /><DashboardStat label="To review" value="7" detail="Needs attention" icon="clipboard" tone="orange" /><DashboardStat label="Proof approved" value="21" detail="84% pass rate" icon="check" tone="green" /><DashboardStat label="Active hubs" value="4" detail="Across Gujarat" icon="building" tone="purple" /></div><div className="assessor-grid"><div className="analysis-card"><div className="analysis-heading"><div><p className="eyebrow">REVIEW QUEUE</p><h2>Practical work waiting for you</h2></div><Badge tone="orange">7 to review</Badge></div>{[{ n: "Ravi Mehta", task: "Spreadsheet accuracy task", time: "Submitted 2h ago", score: "Pending" }, { n: "Meera Shah", task: "Inventory counting simulation", time: "Submitted yesterday", score: "Pending" }, { n: "Asha Patel", task: "POS transaction practical", time: "Scheduled · 24 Aug", score: "Upcoming" }].map((item) => <div className="review-row" key={item.n}><span className="candidate-avatar">{item.n.split(" ").map((n) => n[0]).join("")}</span><div><strong>{item.n}</strong><p>{item.task}</p><small>{item.time}</small></div><Badge tone={item.score === "Pending" ? "orange" : "neutral"}>{item.score}</Badge><button><Icon name="chevron" size={16} /></button></div>)}</div><div className="analysis-card assessor-calendar"><div className="analysis-heading"><div><p className="eyebrow">TODAY’S HUB</p><h2>Enable Lab · Vadodara</h2></div><Badge tone="verified">Ready</Badge></div><div className="hub-session"><span className="calendar-tile">20<small>AUG</small></span><div><strong>Assessment block</strong><p>10:00 AM – 1:00 PM · 4 candidates</p><span><Icon name="accessibility" size={14} />Quiet room · Screen reader available</span></div></div><Button variant="secondary" onClick={() => go("hubs")} className="full-button" icon="arrow">Open hub schedule</Button></div></div></main></DashboardShell>;
}

function AdminDashboard({ go }: { go: (view: View) => void }) {
  return <DashboardShell go={go} role="admin"><main className="dashboard-content dashboard-view-area" id="main-content"><div className="dashboard-welcome"><div><p className="eyebrow">PLATFORM OPERATIONS / ADMIN</p><h1>Good morning, Enable Bharat.</h1><p>Here’s the health of the inclusive employment ecosystem.</p></div><Button variant="secondary" onClick={() => go("impact")} icon="chart">Open impact report</Button></div><div className="employer-stat-grid"><DashboardStat label="Total candidates" value="1,284" detail="+18% this month" icon="users" tone="navy" /><DashboardStat label="Verified profiles" value="968" detail="75% of candidates" icon="shield" tone="green" /><DashboardStat label="Active employers" value="84" detail="12 in review" icon="building" tone="orange" /><DashboardStat label="Open roles" value="146" detail="28 new this week" icon="briefcase" tone="purple" /></div><div className="admin-grid"><div className="analysis-card"><div className="analysis-heading"><div><p className="eyebrow">VERIFICATION QUEUE</p><h2>Keep trust moving</h2></div><Badge tone="orange">18 pending</Badge></div>{[{ label: "Identity documents", value: 8, tone: "orange" }, { label: "Employer verification", value: 5, tone: "navy" }, { label: "Proof-of-work review", value: 3, tone: "green" }, { label: "Partner onboarding", value: 2, tone: "purple" }].map((item) => <div className="admin-queue-row" key={item.label}><span className={`queue-icon ${item.tone}`}><Icon name="clipboard" size={16} /></span><strong>{item.label}</strong><Badge tone={item.tone === "green" ? "verified" : item.tone === "orange" ? "orange" : "navy"}>{item.value} pending</Badge><button><Icon name="arrow" size={14} /></button></div>)}</div><div className="analysis-card"><div className="analysis-heading"><div><p className="eyebrow">ECOSYSTEM PULSE</p><h2>Today’s activity</h2></div><Icon name="chart" size={20} /></div><div className="pulse-graph"><div className="pulse-area" /><div className="pulse-line" /><span className="pulse-point p1" /><span className="pulse-point p2" /><span className="pulse-point p3" /><span className="pulse-point p4" /></div><div className="pulse-legend"><span>Mon</span><span>Tue</span><span>Wed</span><span>Thu</span><span>Fri</span></div><div className="pulse-total"><strong>248</strong><span>meaningful actions this week</span><Badge tone="verified">+24%</Badge></div></div></div><div className="admin-quick-links"><button onClick={() => go("impact")}><Icon name="chart" size={19} /><span><strong>Impact dashboard</strong><small>Outcome movement across pilots</small></span><Icon name="arrow" size={16} /></button><button onClick={() => go("hubs")}><Icon name="building" size={19} /><span><strong>Practical hubs</strong><small>4 active · 2 onboarding</small></span><Icon name="arrow" size={16} /></button><button onClick={() => go("employers")}><Icon name="users" size={19} /><span><strong>Partner network</strong><small>10 NGOs · 6 skill centres</small></span><Icon name="arrow" size={16} /></button></div></main></DashboardShell>;
}

function AppRouter() {
  const [view, setView] = useState<View>("home");
  const [user, setUser] = useState<AuthUser | null>(null);
  useEffect(() => {
    const current = new URLSearchParams(window.location.search).get("view") as View | null;
    if (current) setView(current);
    const onPop = () => setView((new URLSearchParams(window.location.search).get("view") as View | null) || "home");
    window.addEventListener("popstate", onPop);
    fetchCurrentUser().then(setUser);
    return () => window.removeEventListener("popstate", onPop);
  }, []);
  const go = (next: View) => { setView(next as View); window.history.pushState({}, "", next === "home" ? "/" : `/?view=${next}`); window.scrollTo({ top: 0, behavior: document.body.classList.contains("reduce-motion") ? "auto" : "smooth" }); };
  const isDashboard = view.startsWith("candidate-") || view.startsWith("employer-") || view === "assessor-dashboard" || view === "admin-dashboard";

  const renderDashboard = () => {
    if (view === "candidate-dashboard") return <CandidateDashboard go={go} />;
    if (view === "candidate-passport") return <PassportPage go={go} dashboard />;
    if (view === "candidate-skills") return <CandidateSkillsPage go={go} />;
    if (view === "candidate-learning") return <LearningPage go={go} />;
    if (view === "candidate-assessments") return <CandidateAssessmentsPage go={go} />;
    if (view === "candidate-proof") return <ProofPage go={go} dashboard />;
    if (view === "candidate-applications") return <ApplicationsPage go={go} />;
    if (view === "candidate-settings") return <CandidateSettingsPage go={go} />;
    if (view === "employer-dashboard") return <EmployerDashboard go={go} />;
    if (view === "employer-jobs") return <EmployerDashboard go={go} subView="jobs" />;
    if (view === "employer-candidates") return <EmployerDashboard go={go} subView="candidates" />;
    if (view === "employer-shortlisted") return <EmployerDashboard go={go} subView="shortlisted" />;
    if (view === "employer-interviews") return <EmployerDashboard go={go} subView="interviews" />;
    if (view === "employer-analytics") return <EmployerDashboard go={go} subView="analytics" />;
    if (view === "employer-company") return <EmployerDashboard go={go} subView="company" />;
    if (view === "assessor-dashboard") return <AssessorDashboard go={go} />;
    return <AdminDashboard go={go} />;
  };

  let page: React.ReactNode;
  if (view === "login") {
    page = <LoginPage go={go} onAuthenticated={setUser} />;
  } else if (view === "register") {
    page = <RegisterPage go={go} />;
  } else if (isDashboard) {
    page = renderDashboard();
  } else {
    const content = view === "home" ? <HomePage go={go} /> : view === "how" ? <HowItWorksPage go={go} /> : view === "jobs" ? <JobsPage go={go} /> : view === "job-detail" ? <JobDetailPage go={go} /> : view === "candidates" ? <CandidatesPage go={go} /> : view === "employers" ? <EmployersPage go={go} /> : view === "skill-gap" ? <SkillGapPage go={go} /> : view === "passport" ? <PassportPage go={go} /> : view === "proof" ? <ProofPage go={go} /> : view === "hubs" ? <HubsPage go={go} /> : view === "impact" ? <ImpactPage go={go} /> : view === "resources" ? <ResourcesPage go={go} /> : view === "agla-kadam" ? <AglaKadamPage go={go} /> : view === "about" ? <AboutPage go={go} /> : <ContactPage go={go} />;
    page = <><Header go={go} />{content}<Footer go={go} /></>;
  }

  return <>{page}<VoiceAssistant go={go as (view: string) => void} user={user} onAuthChange={setUser} /></>;
}

export default function EnableBharatApp() {
  return <><GoogleTranslate /><VoiceTextAssist /><AppRouter /></>;
}
