// Thin client for the SQLite-backed auth API (artifacts/api-server).
// Requests go through the Vite dev proxy at /api and carry the session cookie.

export type Role = "candidate" | "employer" | "assessor" | "admin";

export type AuthUser = {
  id: number;
  name: string;
  email: string;
  role: Role;
};

export type AuthView =
  | "candidate-dashboard"
  | "employer-dashboard"
  | "assessor-dashboard"
  | "admin-dashboard";

export function dashboardForRole(role: Role): AuthView {
  switch (role) {
    case "employer":
      return "employer-dashboard";
    case "assessor":
      return "assessor-dashboard";
    case "admin":
      return "admin-dashboard";
    default:
      return "candidate-dashboard";
  }
}

async function parse(response: Response): Promise<{ user?: AuthUser; error?: string }> {
  let body: any = {};
  try {
    body = await response.json();
  } catch {
    /* ignore non-JSON responses */
  }
  if (!response.ok) {
    return { error: body?.error || "Something went wrong. Please try again." };
  }
  return { user: body?.user };
}

export async function login(email: string, password: string) {
  const response = await fetch("/api/auth/login", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    credentials: "include",
    body: JSON.stringify({ email, password }),
  });
  return parse(response);
}

export async function register(input: {
  name: string;
  email: string;
  password: string;
  role: Role;
}) {
  const response = await fetch("/api/auth/register", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    credentials: "include",
    body: JSON.stringify(input),
  });
  return parse(response);
}

export async function fetchCurrentUser(): Promise<AuthUser | null> {
  try {
    const response = await fetch("/api/auth/me", { credentials: "include" });
    if (!response.ok) return null;
    const body = await response.json();
    return body?.user ?? null;
  } catch {
    return null;
  }
}

export async function logout() {
  try {
    await fetch("/api/auth/logout", { method: "POST", credentials: "include" });
  } catch {
    /* ignore network errors on logout */
  }
}
