"use client";

import { useEffect, useMemo, useState } from "react";
import Link from "next/link";
import {
  BookOpenCheck,
  ClipboardCheck,
  FileSpreadsheet,
  GraduationCap,
  ListChecks,
  Megaphone,
  MessageSquare,
  Paperclip,
  Plus,
  Presentation,
  Send,
  Smartphone,
  Users,
} from "lucide-react";
import { KpiCard, PageHeader, ProgressBar, StatusBadge, btn, cn } from "@/components/ui";
import { api, useApp } from "@/lib/store";
import type { ClassMaterial, Subject } from "@/lib/data";
import { timeAgo } from "@/lib/data";

const QUICK_ACTIONS = [
  { href: "#attendance", label: "Mark Attendance", icon: ClipboardCheck },
  { href: "#material", label: "Post Material", icon: Paperclip },
  { href: "#marks", label: "Enter Marks", icon: FileSpreadsheet },
  { href: "#parents", label: "SMS Parents", icon: Smartphone },
  { href: "/classroom", label: "Open Classroom", icon: BookOpenCheck },
];

const KIND_META: Record<string, { label: string; icon: typeof Paperclip; cls: string }> = {
  note: { label: "Notes", icon: Paperclip, cls: "bg-navy-50 text-navy-700" },
  ppt: { label: "PPT", icon: Presentation, cls: "bg-kp-red-50 text-kp-red-700" },
  assignment: { label: "Assignment", icon: ListChecks, cls: "bg-gold-100 text-gold-700" },
  announcement: { label: "Announcement", icon: Megaphone, cls: "bg-emerald-50 text-emerald-700" },
  marksheet: { label: "Marksheet", icon: FileSpreadsheet, cls: "bg-kp-green-50 text-kp-green-700" },
};

export default function FacultyPortalPage() {
  const { user, data, toast, refresh } = useApp();
  const isFaculty = user?.role === "department" || user?.role === "coordinator" || user?.role === "admin";

  // Faculty only sees subjects they teach; for simplicity use Computer Engineering
  // for department role, all for coordinators/admins.
  const myDept = data.departments.find((d) => d.name === (user?.department ?? "Computer Engineering"));
  const mySubjects = useMemo<Subject[]>(() => {
    if (!user) return [];
    if (user.role === "department" && myDept) return data.subjects.filter((s) => s.departmentId === myDept.id);
    return data.subjects;
  }, [data.subjects, myDept, user]);

  const myMaterials = useMemo<ClassMaterial[]>(() => {
    const ids = new Set(mySubjects.map((s) => s.id));
    return data.classMaterials.filter((m) => ids.has(m.subjectId)).sort((a, b) => +new Date(b.createdAt) - +new Date(a.createdAt));
  }, [data.classMaterials, mySubjects]);

  const pendingReviews = useMemo(
    () =>
      data.submissions.filter((s) => {
        if (user?.role !== "coordinator" && user?.role !== "admin") return false;
        return s.status === "submitted" || s.status === "under_review";
      }).length,
    [data.submissions, user]
  );

  // Aggregate KPIs across "my subjects"
  const kpis = useMemo(() => {
    const n = mySubjects.length;
    const avg = (k: keyof Subject) =>
      n ? Math.round(mySubjects.reduce((a, s) => a + (s[k] as number), 0) / n) : 0;
    return {
      subjects: n,
      students: mySubjects.reduce((a, s) => a + s.enrolled, 0),
      avgSyllabus: avg("syllabusCompletion"),
      avgAttendance: avg("attendanceAvg"),
      avgPass: avg("passPercentage"),
      pendingPosts: myMaterials.filter((m) => m.kind === "assignment" && new Date(m.dueDate ?? 0) > new Date()).length,
    };
  }, [mySubjects, myMaterials]);

  // Attendance demo state
  const [selectedSubject, setSelectedSubject] = useState<number | null>(mySubjects[0]?.id ?? null);
  const activeSubject = mySubjects.find((s) => s.id === selectedSubject) ?? mySubjects[0];
  const demoEnrolled = activeSubject?.enrolled ?? 0;
  const [present, setPresent] = useState<number>(Math.round(demoEnrolled * 0.88));
  useEffect(() => {
    setPresent(Math.round(demoEnrolled * 0.88));
  }, [demoEnrolled]);

  // Material compose
  const [kind, setKind] = useState<ClassMaterial["kind"]>("note");
  const [title, setTitle] = useState("");
  const [desc, setDesc] = useState("");
  const [posting, setPosting] = useState(false);

  // Marks
  const [marksFile, setMarksFile] = useState<string>("");

  // Parent SMS
  const [smsMsg, setSmsMsg] = useState("");
  const [sendingSms, setSendingSms] = useState(false);
  const [smsResult, setSmsResult] = useState<string | null>(null);

  async function postMaterial(e: React.FormEvent) {
    e.preventDefault();
    if (!activeSubject) return;
    if (!title.trim()) return toast("Title required", "Add a clear title for students.", "error");
    setPosting(true);
    const res = await api("/api/classroom/post", {
      method: "POST",
      body: JSON.stringify({ subjectId: activeSubject.id, kind, title: title.trim(), description: desc.trim(), attachmentName: marksFile || null }),
    });
    const json = await res.json();
    setPosting(false);
    if (!res.ok) return toast("Could not post", json.error ?? "Please try again.", "error");
    setTitle(""); setDesc(""); setMarksFile("");
    toast("Posted to classroom", `${json.post.title} shared with ${activeSubject.name}.`, "success");
    refresh();
  }

  async function sendSms() {
    if (!activeSubject) return;
    if (!smsMsg.trim()) return;
    setSendingSms(true);
    const res = await api("/api/sms/send", {
      method: "POST",
      body: JSON.stringify({ subjectId: activeSubject.id, message: smsMsg.trim() }),
    });
    const json = await res.json();
    setSendingSms(false);
    if (!res.ok) return toast("SMS failed", json.error ?? "Try again.", "error");
    setSmsResult(`Sent to ${json.recipients} parents for ${activeSubject.code}.`);
    setSmsMsg("");
    toast("SMS queued", `${json.recipients} parents notified for ${activeSubject.code}.`, "success");
  }

  if (!isFaculty) {
    return (
      <div className="card flex flex-col items-center justify-center gap-3 p-10 text-center">
        <GraduationCap className="h-10 w-10 text-slate-300" aria-hidden />
        <h2 className="font-display text-xl font-bold text-navy-900">Faculty Portal</h2>
        <p className="max-w-md text-sm text-slate-500">
          Sign in with a faculty, coordinator or administrator account to manage attendance, material, marks and parent communication for your subjects.
        </p>
        <Link href="/login" className={btn.primary}>Sign in as Faculty</Link>
      </div>
    );
  }

  return (
    <div>
      <PageHeader
        title={
          <span>
            Faculty Portal <span className="text-kp-red-600">·</span>{" "}
            <span className="text-slate-500">{user?.department ?? "All Departments"}</span>
          </span>
        }
        subtitle={`Welcome back, ${user?.name}. Manage your subjects, attendance, classroom material and parent communications in one place.`}
        actions={
          <>
            {pendingReviews > 0 && (
              <Link href="/approvals" className={btn.secondary}>
                <MessageSquare className="h-4 w-4" aria-hidden /> {pendingReviews} pending reviews
              </Link>
            )}
            <Link href="/classroom" className={btn.primary}>
              <BookOpenCheck className="h-4 w-4" aria-hidden /> Open Classroom
            </Link>
          </>
        }
      />

      {/* Quick actions */}
      <div className="card animate-fade-up mb-6 overflow-x-auto p-2">
        <nav aria-label="Quick actions" className="flex min-w-max gap-1">
          {QUICK_ACTIONS.map((a) => (
            <a
              key={a.label}
              href={a.href}
              className="inline-flex items-center gap-2 rounded-xl px-3.5 py-2 text-sm font-bold text-slate-600 transition hover:bg-slate-100 hover:text-navy-800"
            >
              <a.icon className="h-4 w-4" aria-hidden /> {a.label}
            </a>
          ))}
        </nav>
      </div>

      {/* KPIs */}
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-5">
        <KpiCard label="My Subjects" value={String(kpis.subjects)} icon={<BookOpenCheck className="h-5 w-5" />} accent="navy" />
        <KpiCard label="Total Students" value={String(kpis.students)} icon={<Users className="h-5 w-5" />} accent="blue" delay={70} />
        <KpiCard label="Syllabus Coverage" value={`${kpis.avgSyllabus}%`} icon={<GraduationCap className="h-5 w-5" />} accent="emerald" sub={<ProgressBar value={kpis.avgSyllabus} className="h-1.5" label="Syllabus coverage" />} delay={140} />
        <KpiCard label="Avg Attendance" value={`${kpis.avgAttendance}%`} icon={<ClipboardCheck className="h-5 w-5" />} accent="amber" sub={`${Math.round(kpis.students * (1 - kpis.avgAttendance / 100))} below 75%`} delay={210} />
        <KpiCard label="Pass %" value={`${kpis.avgPass}%`} icon={<FileSpreadsheet className="h-5 w-5" />} accent="navy" delay={280} />
      </div>

      {/* My subjects list */}
      <div className="card mt-6 overflow-hidden">
        <div className="flex items-center justify-between border-b border-slate-100 px-6 py-4">
          <h2 className="font-display text-lg font-bold text-navy-900">My Subjects</h2>
          <span className="text-xs font-semibold text-slate-400">{mySubjects.length} active this semester</span>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full min-w-[720px] text-left text-sm">
            <thead>
              <tr className="border-b border-slate-100 text-[11px] font-bold uppercase tracking-wider text-slate-400">
                <th className="px-6 py-3">Subject</th>
                <th className="px-4 py-3">Sem</th>
                <th className="px-4 py-3">Students</th>
                <th className="px-4 py-3">Syllabus</th>
                <th className="px-4 py-3">Attendance</th>
                <th className="px-4 py-3">Pass</th>
                <th className="px-4 py-3">Status</th>
              </tr>
            </thead>
            <tbody>
              {mySubjects.map((s) => {
                const lagging = s.attendanceAvg < 75 || s.syllabusCompletion < 80;
                return (
                  <tr
                    key={s.id}
                    onClick={() => setSelectedSubject(s.id)}
                    className={cn(
                      "cursor-pointer border-b border-slate-50 transition hover:bg-navy-50/40",
                      selectedSubject === s.id && "bg-navy-50/60"
                    )}
                  >
                    <td className="px-6 py-3">
                      <p className="font-mono text-[11px] font-bold text-navy-500">{s.code}</p>
                      <p className="font-semibold text-navy-900">{s.name}</p>
                      <p className="text-xs text-slate-400">{s.faculty}</p>
                    </td>
                    <td className="px-4 py-3 text-xs font-semibold text-slate-600">{s.semester}</td>
                    <td className="px-4 py-3 text-xs font-semibold text-slate-700">{s.enrolled}</td>
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-2">
                        <ProgressBar value={s.syllabusCompletion} className="h-1.5 w-20" animate={false} barClassName={s.syllabusCompletion < 80 ? "bg-amber-500" : undefined} label={`${s.name} syllabus ${s.syllabusCompletion}%`} />
                        <span className="text-xs font-bold text-slate-600">{s.syllabusCompletion}%</span>
                      </div>
                    </td>
                    <td className="px-4 py-3">
                      <span className={cn("inline-block rounded-md border px-2 py-0.5 text-xs font-bold", s.attendanceAvg < 75 ? "border-rose-200 bg-rose-50 text-rose-700" : s.attendanceAvg < 85 ? "border-amber-200 bg-amber-50 text-amber-700" : "border-emerald-200 bg-emerald-50 text-emerald-700")}>
                        {s.attendanceAvg}%
                      </span>
                    </td>
                    <td className="px-4 py-3 text-xs font-bold text-navy-700">{s.passPercentage}%</td>
                    <td className="px-4 py-3">
                      <StatusBadge status={lagging ? "changes_requested" : s.marksheetUploaded ? "approved" : "submitted"} />
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      <div className="mt-6 grid gap-6 lg:grid-cols-2">
        {/* Attendance */}
        <section id="attendance" className="card p-6">
          <h2 className="font-display text-lg font-bold text-navy-900">Mark Today's Attendance</h2>
          <p className="mt-1 text-xs text-slate-500">{activeSubject ? `${activeSubject.code} · ${activeSubject.name}` : "Select a subject above."}</p>
          <div className="mt-4 grid grid-cols-3 gap-3 text-center">
            <label className="cursor-pointer rounded-xl border border-slate-200 p-3">
              <input
                type="number"
                min="0"
                max={demoEnrolled}
                value={present}
                onChange={(e) => setPresent(Math.max(0, Math.min(demoEnrolled, Number(e.target.value))))}
                className="w-full bg-transparent text-center font-display text-2xl font-extrabold text-navy-900 focus:outline-none"
                aria-label="Present"
              />
              <p className="text-[10px] font-bold uppercase tracking-wide text-emerald-600">Present</p>
            </label>
            <label className="rounded-xl border border-slate-200 p-3">
              <p className="font-display text-2xl font-extrabold text-kp-red-600">{Math.max(0, demoEnrolled - present)}</p>
              <p className="text-[10px] font-bold uppercase tracking-wide text-kp-red-600">Absent</p>
            </label>
            <div className="rounded-xl bg-slate-50 p-3">
              <p className="font-display text-2xl font-extrabold text-slate-500">{demoEnrolled}</p>
              <p className="text-[10px] font-bold uppercase tracking-wide text-slate-400">Total</p>
            </div>
          </div>
          <div className="mt-4">
            <div className="flex items-center justify-between text-xs font-bold">
              <span className="text-slate-500">Today's attendance</span>
              <span className="text-navy-700">{Math.round((present / Math.max(demoEnrolled, 1)) * 100)}%</span>
            </div>
            <ProgressBar value={Math.round((present / Math.max(demoEnrolled, 1)) * 100)} className="mt-1.5 h-2.5" label="Today's attendance" />
          </div>
          <button
            onClick={() => {
              toast("Attendance saved", `${present} present · ${demoEnrolled - present} absent for ${activeSubject?.code}.`, "success");
              setSmsMsg((prev) => prev || `Dear Parent, today's attendance for ${activeSubject?.code} has been recorded. - KPGU Faculty Portal`);
            }}
            className={cn(btn.primary, "mt-5 w-full")}
          >
            <ClipboardCheck className="h-4 w-4" aria-hidden /> Save Attendance
          </button>
          <p className="mt-2 text-[11px] text-slate-400">Auto-drafts an SMS for absent students. Parents of students below 75% receive an additional alert.</p>
        </section>

        {/* Material composer */}
        <section id="material" className="card p-6">
          <h2 className="font-display text-lg font-bold text-navy-900">Post to Classroom</h2>
          <p className="mt-1 text-xs text-slate-500">Students of {activeSubject?.code ?? "your subject"} see this instantly.</p>
          <form onSubmit={postMaterial} className="mt-4 space-y-3">
            <div className="flex flex-wrap gap-1.5">
              {(Object.keys(KIND_META) as Array<keyof typeof KIND_META>).map((k) => {
                const m = KIND_META[k];
                return (
                  <button
                    type="button"
                    key={k}
                    onClick={() => setKind(k as ClassMaterial["kind"])}
                    aria-pressed={kind === k}
                    className={cn(
                      "inline-flex items-center gap-1.5 rounded-full border px-3 py-1 text-[11px] font-bold transition",
                      kind === k ? "border-navy-800 bg-navy-900 text-white" : "border-slate-200 bg-white text-slate-600 hover:border-slate-300"
                    )}
                  >
                    <m.icon className="h-3.5 w-3.5" aria-hidden /> {m.label}
                  </button>
                );
              })}
            </div>
            <input
              aria-label="Title"
              placeholder="Title (e.g. Unit 4 — Normalisation)"
              className={cn(
                "w-full rounded-xl border border-slate-200 bg-white px-3.5 py-2.5 text-sm focus:border-navy-400 focus:outline-none focus:ring-2 focus:ring-navy-100"
              )}
              value={title}
              onChange={(e) => setTitle(e.target.value)}
            />
            <textarea
              aria-label="Description"
              rows={2}
              placeholder="Optional description or instructions…"
              className={cn(
                "w-full rounded-xl border border-slate-200 bg-white px-3.5 py-2.5 text-sm focus:border-navy-400 focus:outline-none focus:ring-2 focus:ring-navy-100"
              )}
              value={desc}
              onChange={(e) => setDesc(e.target.value)}
            />
            <label className="flex items-center gap-2 rounded-xl border border-dashed border-slate-200 bg-slate-50/60 px-3 py-2 text-xs font-semibold text-slate-600">
              <Paperclip className="h-4 w-4 text-navy-500" aria-hidden />
              <span className="flex-1">
                {marksFile ? <span className="text-navy-700">{marksFile}</span> : "Attach PDF / PPTX / DOCX (demo)"}
              </span>
              <button type="button" onClick={() => setMarksFile(marksFile ? "" : `${title ? title.replace(/\s+/g, "-") : "attachment"}.pdf`)} className={cn(btn.secondary, "!px-3 !py-1 text-[11px]")}>
                {marksFile ? "Remove" : "Choose file"}
              </button>
            </label>
            <button type="submit" disabled={posting} className={cn(btn.primary, "w-full")}>
              {posting ? <span className="h-4 w-4 animate-spin rounded-full border-2 border-white/60 border-t-white" /> : <Plus className="h-4 w-4" aria-hidden />}
              Post to {activeSubject?.code ?? "classroom"}
            </button>
          </form>
        </section>

        {/* Marks upload */}
        <section id="marks" className="card p-6">
          <h2 className="font-display text-lg font-bold text-navy-900">Upload Marks</h2>
          <p className="mt-1 text-xs text-slate-500">Upload an Excel or PDF marksheet; students see results under their classroom feed.</p>
          <label className="mt-4 flex cursor-pointer flex-col items-center justify-center rounded-2xl border-2 border-dashed border-slate-200 bg-slate-50/60 px-6 py-10 text-center transition hover:border-navy-300 hover:bg-navy-50/40">
            <FileSpreadsheet className="h-8 w-8 text-navy-500" aria-hidden />
            <p className="mt-3 text-sm font-bold text-navy-900">Drop marksheets or click to browse</p>
            <p className="mt-1 text-xs text-slate-400">XLSX, PDF · Max 25 MB · auto-published to {activeSubject?.code ?? "students"}</p>
            <input
              type="file"
              className="sr-only"
              accept=".xlsx,.xls,.pdf"
              onChange={(e) => {
                const name = e.target.files?.[0]?.name;
                if (name) {
                  toast("Marksheet queued", `${name} will be published after coordinator review.`, "info");
                }
              }}
            />
          </label>
          <div className="mt-4 flex items-center justify-between rounded-xl border border-emerald-100 bg-emerald-50/70 px-4 py-3 text-sm font-semibold text-emerald-700">
            <span>Approved marksheets: {activeSubject?.marksheetUploaded ? 1 : 0}</span>
            <span className="text-[11px]">Verified against CO/PO mapping</span>
          </div>
        </section>

        {/* Parent SMS */}
        <section id="parents" className="card p-6">
          <h2 className="font-display text-lg font-bold text-navy-900">SMS Parents</h2>
          <p className="mt-1 text-xs text-slate-500">
            Send a short SMS to the parents/guardians of all {demoEnrolled} students in {activeSubject?.code ?? "this subject"}. Delivery is logged for audit.
          </p>
          <textarea
            aria-label="SMS message"
            rows={3}
            maxLength={320}
            className="mt-4 w-full rounded-xl border border-slate-200 bg-white px-3.5 py-2.5 text-sm focus:border-navy-400 focus:outline-none focus:ring-2 focus:ring-navy-100"
            placeholder="Dear Parent, Unit Test 2 marks for CE301 are uploaded. Kindly review. - KPGU"
            value={smsMsg}
            onChange={(e) => setSmsMsg(e.target.value)}
          />
          <div className="mt-2 flex items-center justify-between">
            <span className="text-[11px] font-semibold text-slate-400">{smsMsg.length}/320 characters</span>
            <button onClick={sendSms} disabled={sendingSms || !smsMsg.trim()} className={cn(btn.secondary, "!bg-kp-red-600 !text-white hover:!bg-kp-red-700")}>
              {sendingSms ? <span className="h-4 w-4 animate-spin rounded-full border-2 border-white/60 border-t-white" /> : <Smartphone className="h-4 w-4" aria-hidden />}
              Send SMS
            </button>
          </div>
          {smsResult && (
            <p className="mt-3 rounded-xl border border-emerald-100 bg-emerald-50 px-4 py-2.5 text-xs font-semibold text-emerald-700">
              ✓ {smsResult}
            </p>
          )}
          <p className="mt-3 text-[11px] text-slate-400">
            For absences below 75% use the pre-drafted message from the attendance panel.
          </p>
        </section>
      </div>

      {/* Recent classroom posts */}
      <section className="card mt-6 p-6">
        <div className="flex items-center justify-between">
          <h2 className="font-display text-lg font-bold text-navy-900">Recent Posts to My Subjects</h2>
          <Link href="/classroom" className="text-xs font-bold text-navy-600 hover:underline">Open Classroom →</Link>
        </div>
        {myMaterials.length === 0 ? (
          <p className="mt-4 rounded-xl bg-slate-50 px-4 py-6 text-center text-sm text-slate-400">
            Nothing posted yet. Your first note, announcement or assignment shows up here.
          </p>
        ) : (
          <ul className="mt-4 grid gap-3 md:grid-cols-2">
            {myMaterials.slice(0, 6).map((m) => {
              const sj = data.subjects.find((s) => s.id === m.subjectId);
              const meta = KIND_META[m.kind];
              const Icon = meta.icon;
              return (
                <li key={m.id} className="rounded-xl border border-slate-100 p-4 transition hover:border-slate-200 hover:shadow-sm">
                  <div className="flex items-center gap-2">
                    <span className={cn("inline-flex items-center gap-1 rounded-md px-1.5 py-0.5 text-[10px] font-bold uppercase tracking-wide", meta.cls)}>
                      <Icon className="h-3 w-3" aria-hidden /> {meta.label}
                    </span>
                    <span className="font-mono text-[10px] font-bold text-slate-400">{sj?.code}</span>
                    <span className="ml-auto text-[10px] font-semibold text-slate-400">{timeAgo(m.createdAt)}</span>
                  </div>
                  <p className="mt-2 text-sm font-bold text-navy-900">{m.title}</p>
                  {m.description && <p className="mt-0.5 line-clamp-2 text-xs text-slate-500">{m.description}</p>}
                  {m.attachmentName && (
                    <p className="mt-2 inline-flex items-center gap-1 rounded-md bg-slate-50 px-2 py-1 text-[11px] font-semibold text-navy-700">
                      <Paperclip className="h-3 w-3" aria-hidden /> {m.attachmentName}
                    </p>
                  )}
                </li>
              );
            })}
          </ul>
        )}
      </section>
    </div>
  );
}

