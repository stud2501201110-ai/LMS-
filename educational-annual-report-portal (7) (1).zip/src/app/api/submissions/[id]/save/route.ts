import { NextResponse } from "next/server";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { activities, submissions } from "@/db/schema";
import { ensureSeeded } from "@/db/seed";
import { getSession } from "@/lib/session";

/**
 * Persists the section content / summary to Postgres. Used by the submission
 * wizard so drafts survive across devices, not just in localStorage.
 * Body: { summary?: string, completion?: number }
 */
export async function PATCH(
  req: Request,
  ctx: { params: Promise<{ id: string }> }
) {
  await ensureSeeded();
  const user = await getSession();
  if (!user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const { id } = await ctx.params;
  const subId = Number(id);

  const [existing] = await db
    .select()
    .from(submissions)
    .where(eq(submissions.id, subId))
    .limit(1);
  if (!existing) return NextResponse.json({ error: "Submission not found." }, { status: 404 });

  // Departments can only save their own sections; reviewers can only review.
  const body = (await req.json().catch(() => ({}))) as { summary?: string; completion?: number };
  if (user.role === "student") {
    return NextResponse.json({ error: "Students cannot edit submissions." }, { status: 403 });
  }
  if (user.role === "department") {
    const departments = await import("@/db/schema").then((m) => m.departments);
    const [dept] = await db.select().from(departments).where(eq(departments.id, existing.departmentId)).limit(1);
    if (!dept || dept.head !== user.name && dept.name !== user.department) {
      return NextResponse.json({ error: "You can only edit your own department's sections." }, { status: 403 });
    }
  }

  const next = await db
    .update(submissions)
    .set({
      summary: body.summary !== undefined ? String(body.summary).slice(0, 8000) : existing.summary,
      completion:
        typeof body.completion === "number"
          ? Math.max(0, Math.min(100, Math.round(body.completion)))
          : existing.completion,
      updatedAt: new Date(),
    })
    .where(eq(submissions.id, subId))
    .returning();

  await db.insert(activities).values({
    actor: user.name,
    role: user.role,
    action: "saved section content",
    target: `Section #${subId}`,
    status: "success",
  });

  return NextResponse.json({ submission: next[0] });
}
