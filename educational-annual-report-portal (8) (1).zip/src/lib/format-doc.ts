/**
 * Subject-wise Academic Record Format — document generation.
 *
 * Faculty fill the on-screen form (one page, numbered sections) and download
 * the completed format as PDF (print) or Word (.doc). Both exports render the
 * SAME standalone HTML document, so what you see in the preview is what you
 * get in the file: every section of the format, with the faculty's data.
 */
import { INSTITUTE } from "./data";

export interface RecordFile {
  id: number;
  name: string;
  caption: string;
}

export interface AcademicRecord {
  // 1 — General information
  department: string;
  program: string;
  hod: string;
  academicYear: string;
  // 2 — Subject details
  subjectCode: string;
  subjectName: string;
  semester: string;
  credits: string;
  faculty: string;
  batch: string;
  // 3 — Student records
  totalStudents: string;
  maleStudents: string;
  femaleStudents: string;
  // 4 — Attendance
  lecturesPlanned: string;
  lecturesTaken: string;
  attendanceRemark: string;
  // 5 — Syllabus completion
  unitsPlanned: string;
  unitsCovered: string;
  syllabusRemark: string;
  // 6 — Teaching material
  notesCount: string;
  pptCount: string;
  labManuals: string;
  assignmentsIssued: string;
  assignmentsSubmitted: string;
  // 7 — Assessment & results
  examPapers: string;
  studentsAppeared: string;
  studentsPassed: string;
  vivaStatus: string; // Completed | Partially completed | Not conducted
  resultRemark: string;
  // 8 — Uploaded records
  files: RecordFile[];
  // 9 — Declaration & signatures
  declarationDate: string; // yyyy-mm-dd
  facultySignName: string;
  hodSignName: string;
  coordinatorSignName: string;
}

export const EMPTY_RECORD: AcademicRecord = {
  department: "",
  program: "B.E. (4 Years)",
  hod: "",
  academicYear: INSTITUTE.year,
  subjectCode: "",
  subjectName: "",
  semester: "",
  credits: "4",
  faculty: "",
  batch: "",
  totalStudents: "",
  maleStudents: "",
  femaleStudents: "",
  lecturesPlanned: "",
  lecturesTaken: "",
  attendanceRemark: "",
  unitsPlanned: "5",
  unitsCovered: "",
  syllabusRemark: "",
  notesCount: "",
  pptCount: "",
  labManuals: "",
  assignmentsIssued: "",
  assignmentsSubmitted: "",
  examPapers: "",
  studentsAppeared: "",
  studentsPassed: "",
  vivaStatus: "Completed",
  resultRemark: "",
  files: [],
  declarationDate: new Date().toISOString().slice(0, 10),
  facultySignName: "",
  hodSignName: "",
  coordinatorSignName: "",
};

/* ----------------------------- computed values ----------------------------- */

const num = (v: string): number => {
  const n = parseFloat(v);
  return Number.isFinite(n) ? n : 0;
};

export function recordDerived(r: AcademicRecord) {
  const total = num(r.totalStudents);
  const present = num(r.lecturesTaken),
    planned = num(r.lecturesPlanned);
  const covered = num(r.unitsCovered),
    units = num(r.unitsPlanned);
  const passed = num(r.studentsPassed),
    appeared = num(r.studentsAppeared);
  const submitted = num(r.assignmentsSubmitted);
  const pct = (a: number, b: number) => (b > 0 ? Math.min(100, Math.round((a / b) * 100)) : null);
  return {
    malePct: pct(num(r.maleStudents), total),
    femalePct: pct(num(r.femaleStudents), total),
    lecturePct: pct(present, planned),
    syllabusPct: pct(covered, units),
    passPct: pct(passed, appeared),
    submissionPct: pct(submitted, total),
    genderMatch:
      total > 0 && num(r.maleStudents) + num(r.femaleStudents) === total,
  };
}

/** Human date: 2026-09-01 → 01 Sep 2026 */
function prettyDate(iso: string): string {
  if (!iso) return "____ ____ ____";
  const d = new Date(iso);
  if (isNaN(+d)) return iso;
  return d.toLocaleDateString("en-IN", { day: "2-digit", month: "short", year: "numeric" });
}

const esc = (v: string) =>
  (v || "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");

const dash = (v: string | number | null | undefined, suffix = "") =>
  v === null || v === undefined || v === "" ? "—" : `${v}${suffix}`;

/* ------------------------------ HTML document ------------------------------ */

function kv(label: string, value: string, suffix = ""): string {
  return `<td class="lbl">${label}</td><td class="val">${esc(value) || "&nbsp;"}${suffix ? `<span class="suf">${suffix}</span>` : ""}</td>`;
}

/**
 * Builds the standalone A4 document for the completed format.
 * Pure tables + inline-ish CSS so it renders identically in the browser
 * (PDF via print) and in MS Word (via the .doc export).
 */
export function recordToDocumentHTML(r: AcademicRecord): string {
  const d = recordDerived(r);
  const fileRows = r.files.length
    ? r.files
        .map(
          (f, i) =>
            `<tr><td class="ctr">${i + 1}</td><td>${esc(f.name)}</td><td>${esc(f.caption) || "&nbsp;"}</td></tr>`
        )
        .join("")
    : `<tr><td colspan="3" class="ctr">No files attached</td></tr>`;

  const signBlock = (role: string, name: string, designation: string) => `
    <td class="sign">
      <div class="signline"></div>
      <p class="signame">${esc(name) || "________________"}</p>
      <p class="sigrole">${role}</p>
      <p class="sigdesg">${designation}</p>
    </td>`;

  return `<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8" />
<title>${esc(r.subjectCode || "Subject")} Academic Record Format — ${esc(INSTITUTE.short)}</title>
<style>
  @page { size: A4; margin: 14mm 12mm; }
  * { box-sizing: border-box; }
  body { font-family: "Times New Roman", Georgia, serif; font-size: 11.5px; color: #111; margin: 0; }
  table { border-collapse: collapse; width: 100%; }
  .head { display: block; }
  .head table { width: 100%; }
  .crest { width: 52px; height: 52px; border-radius: 50%; background: #0B2B76; color: #fff; font-family: Arial, sans-serif; font-weight: 800; font-size: 13px; text-align: center; line-height: 52px; border: 2px solid #C8102E; }
  .institute { font-size: 17px; font-weight: 700; color: #0B2B76; letter-spacing: .3px; }
  .instsub { font-size: 10.5px; color: #444; }
  .stripe { height: 4px; background: #C8102E; margin: 6px 0 10px; }
  h1 { font-family: Arial, sans-serif; font-size: 15px; text-align: center; margin: 2px 0 0; text-transform: uppercase; letter-spacing: 1px; color: #0B2B76; }
  h2 { font-family: Arial, sans-serif; font-size: 15px; text-align: center; margin: 0 0 12px; font-size: 12px; color: #333; text-transform: none; letter-spacing: 0; }
  .section { margin-bottom: 12px; page-break-inside: avoid; }
  .sec-title { background: #0B2B76; color: #fff; font-family: Arial, sans-serif; font-size: 10.5px; font-weight: 700; letter-spacing: .6px; text-transform: uppercase; padding: 4px 8px; }
  .grid td, .grid th { border: 1px solid #555; padding: 5px 8px; vertical-align: top; }
  .lbl { width: 26%; background: #F4F6FB; font-family: Arial, sans-serif; font-size: 10px; font-weight: 700; color: #333; text-transform: uppercase; letter-spacing: .3px; }
  .val { font-size: 11.5px; }
  .suf { color: #666; font-size: 10px; }
  .ctr { text-align: center; }
  .files td, .files th { border: 1px solid #555; padding: 5px 8px; }
  .files th { background: #F4F6FB; font-family: Arial, sans-serif; font-size: 10px; text-transform: uppercase; letter-spacing: .3px; }
  .decl { border: 1px solid #555; padding: 8px 10px; font-size: 11px; line-height: 1.45; }
  .sign { width: 25%; text-align: center; padding: 10px 6px 0; vertical-align: top; }
  .signline { border-bottom: 1px solid #333; height: 30px; }
  .signame { font-weight: 700; margin: 4px 0 0; font-size: 11.5px; }
  .sigrole { font-family: Arial, sans-serif; font-size: 9.5px; text-transform: uppercase; letter-spacing: .4px; color: #444; margin: 2px 0 0; }
  .sigdesg { font-size: 10px; color: #666; margin: 1px 0 0; }
  .foot { margin-top: 14px; border-top: 1px solid #999; padding-top: 6px; font-family: Arial, sans-serif; font-size: 9px; color: #777; text-align: center; }
  .calc { background: #FFF8E6; }
  @media print { .noprint { display: none; } }
</style>
</head>
<body>
  <div class="head">
    <table>
      <tr>
        <td class="crest">KPGU</td>
        <td style="padding-left:10px; vertical-align:middle;">
          <div class="institute">${esc(INSTITUTE.name)}</div>
          <div class="instsub">${esc(INSTITUTE.address)} · ${esc(INSTITUTE.website)}</div>
        </td>
        <td style="text-align:right; vertical-align:middle; font-family:Arial,sans-serif; font-size:10px; color:#444;">
          <b>Academic Year</b><br/>${esc(r.academicYear)}
        </td>
      </tr>
    </table>
    <div class="stripe"></div>
    <h1>Subject-wise Academic Record Format</h1>
    <h2>For Annual Report ${esc(INSTITUTE.year)} — to be filled by the subject faculty in-charge</h2>
  </div>

  <div class="section">
    <div class="sec-title">1 &nbsp;·&nbsp; General Information</div>
    <table class="grid">
      <tr>
        ${kv("Department", r.department)}
        ${kv("Programme", r.program)}
      </tr>
      <tr>
        ${kv("Head of Department", r.hod)}
        ${kv("Place", "Vadodara, Gujarat")}
      </tr>
    </table>
  </div>

  <div class="section">
    <div class="sec-title">2 &nbsp;·&nbsp; Subject Details</div>
    <table class="grid">
      <tr>
        ${kv("Subject Code", r.subjectCode)}
        ${kv("Subject Name", r.subjectName)}
      </tr>
      <tr>
        ${kv("Semester", r.semester)}
        ${kv("Credits", r.credits)}
      </tr>
      <tr>
        ${kv("Faculty In-charge", r.faculty)}
        ${kv("Batch / Section", r.batch)}
      </tr>
    </table>
  </div>

  <div class="section">
    <div class="sec-title">3 &nbsp;·&nbsp; Student Records</div>
    <table class="grid">
      <tr>
        ${kv("Total Students", r.totalStudents)}
        ${kv("Male", r.maleStudents, d.malePct !== null ? ` (${d.malePct}%)` : "")}
      </tr>
      <tr>
        ${kv("Female", r.femaleStudents, d.femalePct !== null ? ` (${d.femalePct}%)` : "")}
        ${kv("Roll list verified", d.genderMatch ? "Yes — totals consistent" : "Pending verification")}
      </tr>
    </table>
  </div>

  <div class="section">
    <div class="sec-title">4 &nbsp;·&nbsp; Attendance</div>
    <table class="grid">
      <tr>
        ${kv("Lectures Planned", r.lecturesPlanned)}
        ${kv("Lectures Conducted", r.lecturesTaken, d.lecturePct !== null ? ` (${d.lecturePct}%)` : "")}
      </tr>
      <tr>
        ${kv("Remarks / deviations", r.attendanceRemark)}
      </tr>
    </table>
  </div>

  <div class="section">
    <div class="sec-title">5 &nbsp;·&nbsp; Syllabus Completion</div>
    <table class="grid">
      <tr>
        ${kv("Units Planned", r.unitsPlanned)}
        ${kv("Units Covered", r.unitsCovered, d.syllabusPct !== null ? ` (${d.syllabusPct}%)` : "")}
      </tr>
      <tr>
        ${kv("Deviation / Remarks", r.syllabusRemark)}
      </tr>
    </table>
  </div>

  <div class="section">
    <div class="sec-title">6 &nbsp;·&nbsp; Teaching Material</div>
    <table class="grid">
      <tr>
        ${kv("Unit-wise Notes", r.notesCount, " set(s)")}
        ${kv("Lecture PPTs", r.pptCount, " set(s)")}
      </tr>
      <tr>
        ${kv("Lab Manuals", r.labManuals, " set(s)")}
        ${kv("Assignments", r.assignmentsIssued ? `${r.assignmentsIssued} issued · ${dash(r.assignmentsSubmitted, " received")}` : "—")}
      </tr>
    </table>
  </div>

  <div class="section">
    <div class="sec-title">7 &nbsp;·&nbsp; Assessment &amp; Results</div>
    <table class="grid">
      <tr>
        ${kv("Question Papers Set", r.examPapers)}
        ${kv("Students Appeared", r.studentsAppeared)}
      </tr>
      <tr>
        ${kv("Students Passed", r.studentsPassed, d.passPct !== null ? ` (Pass ${d.passPct}%)` : "")}
        ${kv("Viva / Practical", r.vivaStatus)}
      </tr>
      <tr>
        ${kv("Result Remarks", r.resultRemark)}
      </tr>
    </table>
  </div>

  <div class="section">
    <div class="sec-title">8 &nbsp;·&nbsp; Uploaded Records</div>
    <table class="files">
      <tr><th style="width:8%;" class="ctr">Sl.</th><th style="width:42%;">File Name</th><th>Description / Caption</th></tr>
      ${fileRows}
    </table>
  </div>

  <div class="section">
    <div class="sec-title">9 &nbsp;·&nbsp; Declaration &amp; Signatures</div>
    <div class="decl">
      <b>Declaration:</b> I hereby declare that the information furnished in this academic record format for the subject
      <b>${esc(r.subjectCode || "—")}</b> (${esc(r.subjectName || "—")}) for the academic year <b>${esc(r.academicYear)}</b> is true and
      complete to the best of my knowledge, and is submitted for the Annual Report of ${esc(INSTITUTE.short)}.
    </div>
    <table style="margin-top:4px;">
      <tr>
        ${signBlock("Date &amp; Place", prettyDate(r.declarationDate), "Vadodara")}
        ${signBlock("Faculty In-charge", r.facultySignName || r.faculty, "Signature &amp; Name")}
        ${signBlock("Head of Department", r.hodSignName || r.hod, "Verification &amp; Approval")}
        ${signBlock("Report Coordinator", r.coordinatorSignName, "Final review")}
      </tr>
    </table>
  </div>

  <div class="foot">
    Generated via the ${esc(INSTITUTE.short)} Annual Report Portal · ${esc(INSTITUTE.name)} · www.kpgu.edu.in
  </div>
</body>
</html>`;
}

/* -------------------------------- downloads -------------------------------- */

function safeName(r: AcademicRecord): string {
  const base = (r.subjectCode || "subject").replace(/[^A-Za-z0-9_-]/g, "");
  return `KPGU_Academic_Record_${base}_${r.academicYear || INSTITUTE.year}`.replace(/–/g, "-");
}

/**
 * PDF — opens the browser print dialog with the finished format document.
 * The user chooses "Save as PDF" (A4, no headers) to get the file.
 * Uses a same-origin iframe so it works inside iframes/previews too.
 */
export function downloadRecordAsPDF(r: AcademicRecord): void {
  const html = recordToDocumentHTML(r);
  const frame = document.createElement("iframe");
  frame.setAttribute("aria-hidden", "true");
  frame.style.position = "fixed";
  frame.style.right = "0";
  frame.style.bottom = "0";
  frame.style.width = "0";
  frame.style.height = "0";
  frame.style.border = "0";
  document.body.appendChild(frame);
  const win = frame.contentWindow;
  const doc = frame.contentDocument ?? win?.document;
  if (!win || !doc) {
    frame.remove();
    return;
  }
  doc.open();
  doc.write(html);
  doc.close();
  const cleanup = () => setTimeout(() => frame.remove(), 4000);
  const doPrint = () => {
    try {
      win.focus();
      win.print();
    } finally {
      cleanup();
    }
  };
  if (doc.readyState === "complete") setTimeout(doPrint, 150);
  else win.addEventListener("load", doPrint, { once: true });
}

/**
 * Word — downloads the format as a .doc (Word opens HTML-based .doc natively;
 * faculty can then edit/save as .docx in Word).
 */
export function downloadRecordAsWord(r: AcademicRecord): void {
  const html = recordToDocumentHTML(r);
  const wordHtml = `<!DOCTYPE html>
<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:w="urn:schemas-microsoft-com:office:word">
<head><meta charset="utf-8" />
<!--[if gte mso 9]><xml><w:WordDocument><w:View>Print</w:View><w:Zoom>100</w:Zoom></w:WordDocument></xml><![endif]-->
<style>
  @page Section1 { size: A4; margin: 14mm 12mm; mso-page-orientation: portrait; }
  div.Section1 { page: Section1; }
  body { font-family: "Times New Roman", serif; font-size: 11pt; }
  table { border-collapse: collapse; }
  td, th { mso-padding-alt: 4pt 6pt; }
</style>
</head><body><div class="Section1">${html
    .replace(/^<!DOCTYPE html>[\s\S]*?<body>/, "")
    .replace(/<\/body>[\s\S]*$/, "")}</div></body></html>`;
  const blob = new Blob(["\ufeff", wordHtml], { type: "application/msword" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = `${safeName(r)}.doc`;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 4000);
}
