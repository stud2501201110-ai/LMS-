"use client";

import { useEffect, useMemo, useRef, useState } from "react";
import {
  CheckCircle2,
  Download,
  FilePlus2,
  FileSpreadsheet,
  FileText,
  Save,
  Trash2,
  UploadCloud,
} from "lucide-react";
import { Field, PageHeader, btn, cn, inputCls } from "@/components/ui";
import { useApp } from "@/lib/store";
import { INSTITUTE, type Subject } from "@/lib/data";
import {
  EMPTY_RECORD,
  downloadRecordAsPDF,
  downloadRecordAsWord,
  recordDerived,
  type AcademicRecord,
  type RecordFile,
} from "@/lib/format-doc";

const STORAGE_KEY = "kpgu_record_format_v1";

let fileSeq = 100;

function fromSubject(s: Subject, hod: string): Partial<AcademicRecord> {
  return {
    department: "",
    subjectCode: s.code,
    subjectName: s.name,
    semester: String(s.semester),
    credits: String(s.credits),
    faculty: s.faculty,
    totalStudents: String(s.enrolled),
    lecturesPlanned: String(s.lecturesPlanned),
    lecturesTaken: String(s.lecturesTaken),
    unitsPlanned: String(s.unitsPlanned),
    unitsCovered: String(s.unitsCovered),
    notesCount: String(s.notesCount),
    pptCount: String(s.pptCount),
    assignmentsIssued: String(s.assignmentsCount),
    examPapers: String(s.examPapersCount),
    studentsAppeared: String(s.enrolled),
    studentsPassed: String(Math.round((s.enrolled * s.passPercentage) / 100)),
    vivaStatus: s.vivaCompleted ? "Completed" : "Not conducted",
    hod,
  };
}

export default function RecordFormatPage() {
  const { user, data, toast } = useApp();
  const [r, setR] = useState<AcademicRecord>(EMPTY_RECORD);
  const [subjectId, setSubjectId] = useState<string>("");
  const [busy, setBusy] = useState<"pdf" | "word" | null>(null);
  const idRef = useRef(fileSeq);

  const isFaculty = user?.role === "department" || user?.role === "coordinator" || user?.role === "admin";
  const myDept = data.departments.find((d) => d.name === (user?.department ?? "Computer Engineering"));
  const visibleSubjects = useMemo(
    () => (user?.role === "department" && myDept ? data.subjects.filter((s) => s.departmentId === myDept.id) : data.subjects),
    [data.subjects, user?.role, myDept]
  );

  // restore saved draft
  useEffect(() => {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (raw) {
        const saved = JSON.parse(raw) as AcademicRecord;
        setR({ ...EMPTY_RECORD, ...saved });
      } else if (myDept) {
        setR((prev) => ({ ...prev, department: myDept.name, hod: myDept.head }));
      }
    } catch {
      /* ignore */
    }
  }, [myDept]);

  const set =
    (k: keyof AcademicRecord) =>
    (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) =>
      setR((prev) => ({ ...prev, [k]: e.target.value }));

  const derived = useMemo(() => recordDerived(r), [r]);

  function pickSubject(v: string) {
    setSubjectId(v);
    if (!v) return;
    const s = visibleSubjects.find((x) => String(x.id) === v);
    if (!s) return;
    const dept = data.departments.find((d) => d.id === s.departmentId);
    setR((prev) => ({ ...prev, ...fromSubject(s, dept?.head ?? prev.hod), department: dept?.name ?? prev.department }));
    toast("Prefilled from records", `${s.code} — ${s.name} loaded. Verify and adjust before downloading.`, "info");
  }

  function addFiles(names: string[]) {
    const items: RecordFile[] = names
      .filter(Boolean)
      .map((name) => ({ id: idRef.current++, name, caption: "" }));
    if (items.length) setR((prev) => ({ ...prev, files: [...prev.files, ...items] }));
  }

  function setFile(id: number, patch: Partial<RecordFile>) {
    setR((prev) => ({ ...prev, files: prev.files.map((f) => (f.id === id ? { ...f, ...patch } : f)) }));
  }

  function saveDraft() {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(r));
      toast("Draft saved", "Your data is saved on this device — pick it up anytime.", "success");
    } catch {
      toast("Could not save draft", "Local storage is unavailable.", "error");
    }
  }

  function validateForDownload(): boolean {
    const missing: string[] = [];
    if (!r.subjectCode.trim()) missing.push("Subject Code");
    if (!r.subjectName.trim()) missing.push("Subject Name");
    if (!r.faculty.trim()) missing.push("Faculty In-charge");
    if (missing.length) {
      toast("A few fields are empty", `Please fill: ${missing.join(", ")}.`, "error");
      return false;
    }
    if (derived.genderMatch === false) {
      toast("Check student totals", "Male + Female does not equal Total students.", "info");
    }
    return true;
  }

  function onPDF() {
    if (!validateForDownload()) return;
    setBusy("pdf");
    setTimeout(() => {
      downloadRecordAsPDF(r);
      setBusy(null);
      toast("Print dialog opened", "Choose “Save as PDF” (A4) to download the format file.", "info");
    }, 100);
  }

  function onWord() {
    if (!validateForDownload()) return;
    setBusy("word");
    setTimeout(() => {
      downloadRecordAsWord(r);
      setBusy(null);
      toast("Word file downloaded", "Open it in MS Word and save as .docx if you like.", "success");
    }, 100);
  }

  if (!isFaculty) {
    return (
      <div className="card mx-auto max-w-lg p-10 text-center">
        <FileText className="mx-auto h-10 w-10 text-slate-300" aria-hidden />
        <h1 className="font-display mt-3 text-xl font-bold text-navy-900">Academic Record Format</h1>
        <p className="mt-2 text-sm text-slate-500">
          This form is for faculty, coordinators and administrators. Sign in with a faculty account to fill and download
          the format in PDF or Word.
        </p>
      </div>
    );
  }

  return (
    <div>
      <PageHeader
        title="Academic Record Format"
        subtitle={`Fill the standard subject-wise format below — every section of the ${INSTITUTE.year} report — and download it as PDF or Word.`}
        actions={
          <>
            <button onClick={onPDF} disabled={busy !== null} className={btn.primary}>
              {busy === "pdf" ? <span className="h-4 w-4 animate-spin rounded-full border-2 border-white/60 border-t-white" /> : <Download className="h-4 w-4" aria-hidden />}
              Download PDF
            </button>
            <button onClick={onWord} disabled={busy !== null} className={cn(btn.secondary, "!bg-kp-green-600 !text-white hover:!bg-kp-green-700")}>
              {busy === "word" ? <span className="h-4 w-4 animate-spin rounded-full border-2 border-white/60 border-t-white" /> : <FileSpreadsheet className="h-4 w-4" aria-hidden />}
              Download Word
            </button>
          </>
        }
      />

      {/* Prefill + save bar */}
      <div className="card mb-6 flex flex-col gap-3 p-4 sm:flex-row sm:items-end">
        <div className="flex-1">
          <label htmlFor="prefillSubject" className="mb-1.5 block text-[13px] font-semibold text-slate-700">
            Start from a subject record <span className="font-normal text-slate-400">(optional — prefills most fields)</span>
          </label>
          <select id="prefillSubject" className={inputCls} value={subjectId} onChange={(e) => pickSubject(e.target.value)}>
            <option value="">— Choose a subject to prefill —</option>
            {visibleSubjects.map((s) => (
              <option key={s.id} value={s.id}>
                {s.code} · {s.name} (Sem {s.semester} · {s.faculty})
              </option>
            ))}
          </select>
        </div>
        <div className="flex gap-2">
          <button onClick={saveDraft} className={btn.secondary}>
            <Save className="h-4 w-4" aria-hidden /> Save Draft
          </button>
        </div>
      </div>

      <div className="grid gap-6 lg:grid-cols-[1fr_300px]">
        {/* ------------------------------- the format ------------------------------- */}
        <div className="space-y-5">
          <Section title="1 · General Information">
            <div className="grid gap-4 sm:grid-cols-2">
              <Field label="Department" htmlFor="department">
                <input id="department" className={inputCls} value={r.department} onChange={set("department")} />
              </Field>
              <Field label="Programme" htmlFor="program">
                <input id="program" className={inputCls} value={r.program} onChange={set("program")} />
              </Field>
              <Field label="Head of Department" htmlFor="hod">
                <input id="hod" className={inputCls} value={r.hod} onChange={set("hod")} />
              </Field>
              <Field label="Academic Year" htmlFor="academicYear">
                <input id="academicYear" className={inputCls} value={r.academicYear} onChange={set("academicYear")} />
              </Field>
            </div>
          </Section>

          <Section title="2 · Subject Details">
            <div className="grid gap-4 sm:grid-cols-2">
              <Field label="Subject Code" htmlFor="subjectCode">
                <input id="subjectCode" className={inputCls} placeholder="e.g. CE301" value={r.subjectCode} onChange={set("subjectCode")} />
              </Field>
              <Field label="Subject Name" htmlFor="subjectName">
                <input id="subjectName" className={inputCls} placeholder="e.g. Data Structures & Algorithms" value={r.subjectName} onChange={set("subjectName")} />
              </Field>
              <Field label="Semester" htmlFor="semester">
                <input id="semester" inputMode="numeric" className={inputCls} value={r.semester} onChange={set("semester")} />
              </Field>
              <Field label="Credits" htmlFor="credits">
                <input id="credits" inputMode="numeric" className={inputCls} value={r.credits} onChange={set("credits")} />
              </Field>
              <Field label="Faculty In-charge" htmlFor="faculty">
                <input id="faculty" className={inputCls} value={r.faculty} onChange={set("faculty")} />
              </Field>
              <Field label="Batch / Section" htmlFor="batch">
                <input id="batch" className={inputCls} placeholder="e.g. Sem 3 — Batch A/B" value={r.batch} onChange={set("batch")} />
              </Field>
            </div>
          </Section>

          <Section title="3 · Student Records">
            <div className="grid gap-4 sm:grid-cols-3">
              <Field label="Total Students" htmlFor="totalStudents">
                <input id="totalStudents" inputMode="numeric" className={inputCls} value={r.totalStudents} onChange={set("totalStudents")} />
              </Field>
              <Field label="Male Students" htmlFor="maleStudents">
                <input id="maleStudents" inputMode="numeric" className={inputCls} value={r.maleStudents} onChange={set("maleStudents")} />
              </Field>
              <Field label="Female Students" htmlFor="femaleStudents">
                <input id="femaleStudents" inputMode="numeric" className={inputCls} value={r.femaleStudents} onChange={set("femaleStudents")} />
              </Field>
            </div>
            {derived.genderMatch === false && (
              <p role="alert" className="mt-3 rounded-xl border border-amber-200 bg-amber-50 px-4 py-2.5 text-sm font-medium text-amber-800">
                Male + Female ≠ Total students — verify against the roll list.
              </p>
            )}
            {derived.genderMatch === true && (
              <p className="mt-3 flex items-center gap-2 rounded-xl border border-emerald-100 bg-emerald-50 px-4 py-2.5 text-sm font-medium text-emerald-700">
                <CheckCircle2 className="h-4 w-4" aria-hidden /> Roll totals are consistent.
              </p>
            )}
          </Section>

          <Section title="4 · Attendance">
            <div className="grid gap-4 sm:grid-cols-2">
              <Field label="Lectures Planned" htmlFor="lecturesPlanned">
                <input id="lecturesPlanned" inputMode="numeric" className={inputCls} value={r.lecturesPlanned} onChange={set("lecturesPlanned")} />
              </Field>
              <Field label="Lectures Conducted" htmlFor="lecturesTaken">
                <input id="lecturesTaken" inputMode="numeric" className={inputCls} value={r.lecturesTaken} onChange={set("lecturesTaken")} />
              </Field>
            </div>
            <Field label="Remarks / deviations (optional)" htmlFor="attendanceRemark">
              <textarea id="attendanceRemark" rows={2} className={cn(inputCls, "mt-4")} value={r.attendanceRemark} onChange={set("attendanceRemark")} />
            </Field>
          </Section>

          <Section title="5 · Syllabus Completion">
            <div className="grid gap-4 sm:grid-cols-2">
              <Field label="Units Planned" htmlFor="unitsPlanned">
                <input id="unitsPlanned" inputMode="numeric" className={inputCls} value={r.unitsPlanned} onChange={set("unitsPlanned")} />
              </Field>
              <Field label="Units Covered" htmlFor="unitsCovered">
                <input id="unitsCovered" inputMode="numeric" className={inputCls} value={r.unitsCovered} onChange={set("unitsCovered")} />
              </Field>
            </div>
            <Field label="Deviation / Remarks (required if below 100%)" htmlFor="syllabusRemark">
              <textarea id="syllabusRemark" rows={2} className={cn(inputCls, "mt-4")} value={r.syllabusRemark} onChange={set("syllabusRemark")} />
            </Field>
          </Section>

          <Section title="6 · Teaching Material">
            <div className="grid gap-4 sm:grid-cols-3">
              <Field label="Unit-wise Notes (sets)" htmlFor="notesCount">
                <input id="notesCount" inputMode="numeric" className={inputCls} value={r.notesCount} onChange={set("notesCount")} />
              </Field>
              <Field label="Lecture PPTs (sets)" htmlFor="pptCount">
                <input id="pptCount" inputMode="numeric" className={inputCls} value={r.pptCount} onChange={set("pptCount")} />
              </Field>
              <Field label="Lab Manuals (sets)" htmlFor="labManuals">
                <input id="labManuals" inputMode="numeric" className={inputCls} value={r.labManuals} onChange={set("labManuals")} />
              </Field>
              <Field label="Assignments Issued" htmlFor="assignmentsIssued">
                <input id="assignmentsIssued" inputMode="numeric" className={inputCls} value={r.assignmentsIssued} onChange={set("assignmentsIssued")} />
              </Field>
              <Field label="Assignments Received" htmlFor="assignmentsSubmitted">
                <input id="assignmentsSubmitted" inputMode="numeric" className={inputCls} value={r.assignmentsSubmitted} onChange={set("assignmentsSubmitted")} />
              </Field>
            </div>
          </Section>

          <Section title="7 · Assessment & Results">
            <div className="grid gap-4 sm:grid-cols-3">
              <Field label="Question Papers Set" htmlFor="examPapers">
                <input id="examPapers" inputMode="numeric" className={inputCls} value={r.examPapers} onChange={set("examPapers")} />
              </Field>
              <Field label="Students Appeared" htmlFor="studentsAppeared">
                <input id="studentsAppeared" inputMode="numeric" className={inputCls} value={r.studentsAppeared} onChange={set("studentsAppeared")} />
              </Field>
              <Field label="Students Passed" htmlFor="studentsPassed">
                <input id="studentsPassed" inputMode="numeric" className={inputCls} value={r.studentsPassed} onChange={set("studentsPassed")} />
              </Field>
            </div>
            <div className="mt-4">
              <Field label="Viva / Practical" htmlFor="vivaStatus">
                <select id="vivaStatus" className={inputCls} value={r.vivaStatus} onChange={set("vivaStatus")}>
                  <option>Completed</option>
                  <option>Partially completed</option>
                  <option>Not conducted</option>
                </select>
              </Field>
            </div>
            <Field label="Result Remarks" htmlFor="resultRemark">
              <textarea id="resultRemark" rows={2} className={cn(inputCls, "mt-4")} value={r.resultRemark} onChange={set("resultRemark")} />
            </Field>
          </Section>

          <Section title="8 · Uploaded Records">
            <p className="-mt-2 mb-3 text-xs text-slate-500">
              List the records attached to this subject (question papers, marksheets, attendance registers, notes, PPTs, lab manuals).
            </p>
            <label
              className="flex cursor-pointer items-center justify-center gap-2 rounded-xl border-2 border-dashed border-slate-200 bg-slate-50/60 px-4 py-3 text-sm font-semibold text-slate-600 transition hover:border-navy-300 hover:bg-navy-50/40"
            >
              <UploadCloud className="h-4 w-4 text-navy-500" aria-hidden /> Add files (names are listed in the document)
              <input
                type="file"
                multiple
                className="sr-only"
                onChange={(e) => {
                  addFiles(Array.from(e.target.files ?? []).map((f) => f.name));
                  e.target.value = "";
                }}
              />
            </label>
            {r.files.length > 0 && (
              <ul className="mt-3 space-y-2">
                {r.files.map((f, i) => (
                  <li key={f.id} className="flex items-center gap-2 rounded-xl border border-slate-200 bg-white p-2.5">
                    <span className="w-5 text-center font-mono text-xs font-bold text-slate-400">{i + 1}</span>
                    <input
                      aria-label={`File name ${i + 1}`}
                      className="min-w-0 flex-1 rounded-lg border border-slate-200 px-2.5 py-1.5 text-xs font-semibold focus:border-navy-300 focus:outline-none"
                      value={f.name}
                      onChange={(e) => setFile(f.id, { name: e.target.value })}
                    />
                    <input
                      aria-label={`Caption for ${f.name}`}
                      placeholder="Caption (optional)"
                      className="min-w-0 flex-[1.2] rounded-lg border border-slate-200 px-2.5 py-1.5 text-xs focus:border-navy-300 focus:outline-none"
                      value={f.caption}
                      onChange={(e) => setFile(f.id, { caption: e.target.value })}
                    />
                    <button
                      aria-label={`Remove ${f.name}`}
                      onClick={() => setR((prev) => ({ ...prev, files: prev.files.filter((x) => x.id !== f.id) }))}
                      className="rounded-lg p-1.5 text-slate-400 transition hover:bg-rose-50 hover:text-rose-600"
                    >
                      <Trash2 className="h-4 w-4" aria-hidden />
                    </button>
                  </li>
                ))}
              </ul>
            )}
          </Section>

          <Section title="9 · Declaration & Signatures">
            <div className="rounded-xl bg-navy-50/70 px-4 py-3 text-xs leading-relaxed text-navy-800">
              <b>Declaration:</b> The information in this academic record format for <b>{r.subjectCode || "—"}</b> (
              {r.subjectName || "—"}) for the academic year <b>{r.academicYear}</b> is true and complete, submitted for
              the Annual Report of {INSTITUTE.short}.
            </div>
            <div className="mt-4 grid gap-4 sm:grid-cols-3">
              <Field label="Date" htmlFor="declarationDate">
                <input id="declarationDate" type="date" className={inputCls} value={r.declarationDate} onChange={set("declarationDate")} />
              </Field>
              <Field label="Faculty Signature (name)" htmlFor="facultySignName">
                <input id="facultySignName" className={inputCls} placeholder="Type name for the signature line" value={r.facultySignName} onChange={set("facultySignName")} />
              </Field>
              <Field label="HOD Signature (name)" htmlFor="hodSignName">
                <input id="hodSignName" className={inputCls} placeholder="Type name for the signature line" value={r.hodSignName} onChange={set("hodSignName")} />
              </Field>
            </div>
          </Section>

          {/* footer actions */}
          <div className="flex flex-wrap items-center justify-between gap-3 rounded-2xl border border-slate-200 bg-white p-4 shadow-sm">
            <p className="flex items-center gap-2 text-xs font-semibold text-slate-400">
              <FilePlus2 className="h-4 w-4 text-navy-500" aria-hidden />
          The downloaded file contains all 9 sections above with your data.
            </p>
            <div className="flex gap-2">
              <button onClick={onPDF} className={btn.primary}>
                <Download className="h-4 w-4" aria-hidden /> PDF
              </button>
              <button onClick={onWord} className={cn(btn.secondary, "!bg-kp-green-600 !text-white hover:!bg-kp-green-700")}>
                <FileSpreadsheet className="h-4 w-4" aria-hidden /> Word
              </button>
            </div>
          </div>
        </div>

        {/* ------------------------------- live summary ------------------------------- */}
        <aside className="space-y-4 lg:sticky lg:top-24 lg:h-fit">
          <div className="card p-5">
            <h2 className="font-display text-sm font-bold text-navy-900">Live Summary</h2>
            <p className="mt-0.5 text-[11px] text-slate-400">Auto-calculated from your entries</p>
            <dl className="mt-4 space-y-3">
              <SummaryRow label="Lectures delivered" value={derived.lecturePct} detail={`${r.lecturesTaken || "—"} of ${r.lecturesPlanned || "—"}`} />
              <SummaryRow label="Syllabus completed" value={derived.syllabusPct} detail={`${r.unitsCovered || "—"} of ${r.unitsPlanned || "—"} units`} />
              <SummaryRow label="Pass percentage" value={derived.passPct} detail={`${r.studentsPassed || "—"} of ${r.studentsAppeared || "—"} students`} />
              <SummaryRow label="Assignment submissions" value={derived.submissionPct} detail={`${r.assignmentsSubmitted || "—"} of ${r.totalStudents || "—"} students`} />
            </dl>
          </div>
          <div className="card p-5">
            <h2 className="font-display text-sm font-bold text-navy-900">How to download</h2>
            <ol className="mt-3 list-decimal space-y-2 pl-4 text-xs leading-relaxed text-slate-500">
              <li>
                <b>PDF:</b> click <b>Download PDF</b>, then choose <i>Save as PDF</i> (A4) in the print dialog.
              </li>
              <li>
                <b>Word:</b> click <b>Download Word</b> — the .doc opens directly in MS Word; save as .docx if needed.
              </li>
              <li>Both files carry all 9 sections, the declaration and signature blocks.</li>
            </ol>
          </div>
        </aside>
      </div>
    </div>
  );
}

function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <section className="card animate-fade-up overflow-hidden">
      <div className="bg-navy-900 px-5 py-2.5">
        <h2 className="font-mono text-[11px] font-extrabold uppercase tracking-[0.14em] text-white">{title}</h2>
      </div>
      <div className="p-5">{children}</div>
    </section>
  );
}

function SummaryRow({ label, value, detail }: { label: string; value: number | null; detail: string }) {
  return (
    <div className="flex items-center justify-between gap-3">
      <div className="min-w-0">
        <p className="text-xs font-bold text-slate-600">{label}</p>
        <p className="truncate text-[11px] text-slate-400">{detail}</p>
      </div>
      <span
        className={cn(
          "shrink-0 rounded-lg px-2.5 py-1 font-display text-sm font-extrabold",
          value === null ? "bg-slate-100 text-slate-300" : value >= 85 ? "bg-emerald-50 text-emerald-700" : value >= 75 ? "bg-amber-50 text-amber-700" : "bg-rose-50 text-rose-700"
        )}
      >
        {value === null ? "—" : `${value}%`}
      </span>
    </div>
  );
}
